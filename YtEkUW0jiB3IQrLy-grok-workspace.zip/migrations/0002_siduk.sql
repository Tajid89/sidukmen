create table if not exists siduk_dokumen (
  id text primary key,
  payload jsonb not null,
  revisi integer not null default 1,
  updated_at timestamptz not null default now()
);
