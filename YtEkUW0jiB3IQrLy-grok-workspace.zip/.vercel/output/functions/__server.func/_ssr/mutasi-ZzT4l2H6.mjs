import { o as __toESM } from "../_runtime.mjs";
import { c as MUTASI_LABEL, h as can, i as AGAMA, u as STATUS_KAWIN, v as formatTanggal } from "./seed-DSw-2F5v.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Route$8, o as useSessionUser, s as useSiduk } from "./router-DBFAyprg.mjs";
import { i as Field, l as control, n as Btn, o as Notice, s as Panel } from "./bits-DokRK5cV.mjs";
import { t as Shell } from "./shell-BOWreftS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mutasi-ZzT4l2H6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MutasiPage({ presetNik = "", presetJenis = "" }) {
	const user = useSessionUser();
	const penduduk = useSiduk((s) => s.penduduk);
	const keluarga = useSiduk((s) => s.keluarga);
	const pekerjaan = useSiduk((s) => s.pekerjaan);
	const pendidikan = useSiduk((s) => s.pendidikan);
	const statusKeluarga = useSiduk((s) => s.statusKeluarga);
	const mutasi = useSiduk((s) => s.mutasi);
	const catatMeninggal = useSiduk((s) => s.catatMeninggal);
	const catatPindahKeluar = useSiduk((s) => s.catatPindahKeluar);
	const catatLahir = useSiduk((s) => s.catatLahir);
	const catatPindahMasuk = useSiduk((s) => s.catatPindahMasuk);
	const [jenis, setJenis] = (0, import_react.useState)(presetJenis || "lahir");
	const [nik, setNik] = (0, import_react.useState)(presetNik);
	const [tanggal, setTanggal] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [keterangan, setKeterangan] = (0, import_react.useState)("");
	const [noKk, setNoKk] = (0, import_react.useState)("");
	const [nama, setNama] = (0, import_react.useState)("");
	const [jk, setJk] = (0, import_react.useState)("L");
	const [tempat, setTempat] = (0, import_react.useState)("Lamongan");
	const [ayah, setAyah] = (0, import_react.useState)("");
	const [ibu, setIbu] = (0, import_react.useState)("");
	const [lahir, setLahir] = (0, import_react.useState)("1990-01-01");
	const [agama, setAgama] = (0, import_react.useState)("Islam");
	const [kawin, setKawin] = (0, import_react.useState)("Kawin");
	const [pekerjaanId, setPekerjaanId] = (0, import_react.useState)(pekerjaan[0]?.id ?? "");
	const [pendidikanId, setPendidikanId] = (0, import_react.useState)(pendidikan[0]?.id ?? "");
	const [statusId, setStatusId] = (0, import_react.useState)(statusKeluarga.find((s) => s.nama === "Famili Lain")?.id ?? statusKeluarga[0]?.id ?? "");
	const [error, setError] = (0, import_react.useState)(null);
	if (!user) return null;
	const boleh = can(user.role, "mutasi.write");
	const aktifList = penduduk.filter((p) => p.statusHidup === "aktif");
	function pilihKk(value) {
		setNoKk(value);
		const kk = keluarga.find((k) => k.noKk === value);
		const anggota = penduduk.filter((p) => p.noKk === value && p.statusHidup === "aktif");
		const kepala = anggota.find((p) => p.nama === kk?.kepalaKeluarga);
		const istri = anggota.find((p) => p.jenisKelamin === "P" && p.statusPerkawinan === "Kawin");
		if (kepala?.jenisKelamin === "L") setAyah(kepala.nama);
		if (istri) setIbu(istri.nama);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Mutasi penduduk",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 xl:grid-cols-[minmax(0,1fr)_22rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Catat kejadian",
				children: [!boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Kepala desa dapat melihat riwayat. Pencatatan dilakukan petugas." }) : null, boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 space-y-4",
					onSubmit: (event) => {
						event.preventDefault();
						let err = "Jenis mutasi tidak dikenal.";
						if (jenis === "meninggal") err = catatMeninggal(nik, tanggal, keterangan);
						if (jenis === "pindah_keluar") err = catatPindahKeluar(nik, tanggal, keterangan);
						if (jenis === "lahir") err = catatLahir({
							noKk,
							nik,
							nama,
							jenisKelamin: jk,
							tanggal,
							tempatLahir: tempat,
							namaAyah: ayah,
							namaIbu: ibu,
							keterangan
						});
						if (jenis === "pindah_masuk") err = catatPindahMasuk({
							nik,
							nama,
							jenisKelamin: jk,
							tempatLahir: tempat,
							tanggalLahir: lahir,
							agama,
							statusPerkawinan: kawin,
							pekerjaanId,
							pendidikanId,
							statusId,
							noKk,
							alamat: "",
							namaAyah: ayah,
							namaIbu: ibu,
							tanggal,
							keterangan
						});
						setError(err);
						if (!err) {
							toast.success("Mutasi dicatat");
							setKeterangan("");
							setNama("");
							setNik("");
						}
					},
					children: [
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: error }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Jenis",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: control,
								value: jenis,
								onChange: (e) => setJenis(e.target.value),
								children: Object.keys(MUTASI_LABEL).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: key,
									children: MUTASI_LABEL[key]
								}, key))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tanggal kejadian",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								type: "date",
								value: tanggal,
								onChange: (e) => setTanggal(e.target.value),
								required: true
							})
						}),
						jenis === "meninggal" || jenis === "pindah_keluar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Penduduk",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: control,
								value: nik,
								onChange: (e) => setNik(e.target.value),
								required: true,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Pilih penduduk aktif"
								}), aktifList.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: p.nik,
									children: [
										p.nama,
										" — ",
										p.nik
									]
								}, p.nik))]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Kartu keluarga",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: control,
									value: noKk,
									onChange: (e) => pilihKk(e.target.value),
									required: true,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Pilih KK"
									}), keluarga.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: k.noKk,
										children: [
											k.noKk,
											" — ",
											k.kepalaKeluarga
										]
									}, k.noKk))]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "NIK",
								hint: jenis === "lahir" ? "Isi NIK dari akta. Nomor sementara 16 digit boleh, lalu ubah di data penduduk." : "NIK penduduk yang masuk.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: control,
									inputMode: "numeric",
									maxLength: 16,
									value: nik,
									onChange: (e) => setNik(e.target.value.replace(/\D/g, "")),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nama",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: control,
									value: nama,
									onChange: (e) => setNama(e.target.value),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Jenis kelamin",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: control,
									value: jk,
									onChange: (e) => setJk(e.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "L",
										children: "Laki-laki"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "P",
										children: "Perempuan"
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Tempat lahir",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: control,
									value: tempat,
									onChange: (e) => setTempat(e.target.value)
								})
							}),
							jenis === "pindah_masuk" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Tanggal lahir",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: control,
										type: "date",
										value: lahir,
										onChange: (e) => setLahir(e.target.value),
										required: true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Agama",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: control,
										value: agama,
										onChange: (e) => setAgama(e.target.value),
										children: AGAMA.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Status perkawinan",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: control,
										value: kawin,
										onChange: (e) => setKawin(e.target.value),
										children: STATUS_KAWIN.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Pekerjaan",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: control,
										value: pekerjaanId,
										onChange: (e) => setPekerjaanId(e.target.value),
										children: pekerjaan.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: item.id,
											children: item.nama
										}, item.id))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Pendidikan",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: control,
										value: pendidikanId,
										onChange: (e) => setPendidikanId(e.target.value),
										children: pendidikan.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: item.id,
											children: item.nama
										}, item.id))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Status dalam keluarga",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: control,
										value: statusId,
										onChange: (e) => setStatusId(e.target.value),
										children: statusKeluarga.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: item.id,
											children: item.nama
										}, item.id))
									})
								})
							] }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nama ayah",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: control,
									value: ayah,
									onChange: (e) => setAyah(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nama ibu",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: control,
									value: ibu,
									onChange: (e) => setIbu(e.target.value)
								})
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Keterangan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: `${control} h-24 py-2`,
								value: keterangan,
								onChange: (e) => setKeterangan(e.target.value),
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: "Simpan mutasi"
						})
					]
				}) : null]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Riwayat",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "max-h-[40rem] space-y-3 overflow-auto",
					children: mutasi.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-b border-line pb-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: MUTASI_LABEL[item.jenis]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.nama }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-stone",
								children: [
									formatTanggal(item.tanggal),
									" · ",
									item.actor
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-stone",
								children: item.keterangan
							})
						]
					}, item.id))
				})
			})]
		})
	});
}
var SplitComponent = function MutasiRoute() {
	const { nik, jenis } = Route$8.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MutasiPage, {
		presetNik: nik ?? "",
		presetJenis: jenis ?? ""
	});
};
//#endregion
export { SplitComponent as component };
