import { a as ProfilPage } from "./kelola-Cf35GC1B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profil-CdUVN-np.js
var SplitComponent = ProfilPage;
//#endregion
export { SplitComponent as component };
