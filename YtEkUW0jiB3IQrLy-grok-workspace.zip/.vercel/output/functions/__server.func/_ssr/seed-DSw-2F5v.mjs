//#region node_modules/.nitro/vite/services/ssr/assets/seed-DSw-2F5v.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var DESA = {
	nama: "Monongo",
	kecamatan: "Sukodadi",
	kabupaten: "Lamongan",
	provinsi: "Jawa Timur"
};
var AGAMA = [
	"Islam",
	"Kristen",
	"Katolik",
	"Hindu",
	"Buddha",
	"Konghucu"
];
var STATUS_KAWIN = [
	"Belum Kawin",
	"Kawin",
	"Cerai Hidup",
	"Cerai Mati"
];
var KELOMPOK_USIA = [
	{
		id: "0-5",
		label: "0–5",
		min: 0,
		max: 5
	},
	{
		id: "6-12",
		label: "6–12",
		min: 6,
		max: 12
	},
	{
		id: "13-17",
		label: "13–17",
		min: 13,
		max: 17
	},
	{
		id: "18-30",
		label: "18–30",
		min: 18,
		max: 30
	},
	{
		id: "31-45",
		label: "31–45",
		min: 31,
		max: 45
	},
	{
		id: "46-60",
		label: "46–60",
		min: 46,
		max: 60
	},
	{
		id: "61+",
		label: "61+",
		min: 61,
		max: 120
	}
];
var CHART_COLORS = [
	"var(--color-brand)",
	"var(--color-brandsoft)",
	"var(--color-stone)",
	"var(--color-sand)",
	"var(--color-clay)"
];
var ROLE_LABEL = {
	admin: "Admin",
	petugas: "Petugas",
	kepala_desa: "Kepala Desa"
};
var MUTASI_LABEL = {
	lahir: "Kelahiran",
	meninggal: "Kematian",
	pindah_masuk: "Pindah masuk",
	pindah_keluar: "Pindah keluar"
};
var SURAT_KODE = {
	domisili: "SKD",
	usaha: "SKU",
	tidak_mampu: "SKTM",
	kelahiran: "SKL",
	kematian: "SKK",
	pengantar: "SP"
};
var BULAN = [
	"Januari",
	"Februari",
	"Maret",
	"April",
	"Mei",
	"Juni",
	"Juli",
	"Agustus",
	"September",
	"Oktober",
	"November",
	"Desember"
];
var ROMAWI = [
	"I",
	"II",
	"III",
	"IV",
	"V",
	"VI",
	"VII",
	"VIII",
	"IX",
	"X",
	"XI",
	"XII"
];
var DEMO_AKUN = [
	{
		username: "admin",
		password: "monongo",
		peran: "Admin desa — kelola pengguna dan data penduduk"
	},
	{
		username: "petugas",
		password: "monongo",
		peran: "Petugas — input penduduk, keluarga, dan foto rumah"
	},
	{
		username: "kepala",
		password: "monongo",
		peran: "Kepala desa — melihat data penduduk"
	}
];
function can(role, ability) {
	if (role === "admin") return true;
	if (role === "petugas") return ability !== "user.write";
	return ability === "surat.write";
}
function namaMaster(list, id) {
	return list.find((item) => item.id === id)?.nama ?? "—";
}
function umur(tanggalLahir, today = /* @__PURE__ */ new Date()) {
	const [y, m, d] = tanggalLahir.slice(0, 10).split("-").map(Number);
	if (!y || !m || !d) return 0;
	let age = today.getFullYear() - y;
	const month = today.getMonth() + 1;
	if (month < m || month === m && today.getDate() < d) age -= 1;
	return age;
}
function formatTanggal(iso) {
	const [y, m, d] = iso.slice(0, 10).split("-");
	if (!y || !m || !d) return iso;
	return `${Number(d)} ${BULAN[Number(m) - 1] ?? ""} ${y}`;
}
function formatWaktu(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return iso;
	return new Intl.DateTimeFormat("id-ID", {
		timeZone: "Asia/Jakarta",
		day: "numeric",
		month: "long",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	}).format(date);
}
function angka(n) {
	return new Intl.NumberFormat("id-ID").format(n);
}
function labelKelamin(jk) {
	return jk === "L" ? "Laki-laki" : "Perempuan";
}
function alamatKeluarga(k) {
	return `${k.alamat}, RT ${k.rt}/RW ${k.rw}, Dusun ${k.dusun}, Desa ${DESA.nama}`;
}
function formatNomorSurat(seq, jenis, tanggal) {
	const month = Number(tanggal.slice(5, 7)) - 1;
	const year = tanggal.slice(0, 4);
	return `${String(seq).padStart(3, "0")}/${SURAT_KODE[jenis]}/${ROMAWI[month] ?? "I"}/${year}`;
}
function aktif(p) {
	return p.statusHidup === "aktif";
}
function validateKeluarga(input, keluarga, ignoreNoKk) {
	if (!/^\d{16}$/.test(input.noKk.trim())) return "Nomor KK harus 16 digit angka.";
	if (input.kepalaKeluarga.trim().length < 3) return "Nama kepala keluarga belum lengkap.";
	if (input.alamat.trim().length < 3) return "Alamat belum diisi.";
	if (input.dusun.trim().length < 2) return "Dusun belum diisi.";
	if (!/^\d{1,3}$/.test(input.rt.trim()) || !/^\d{1,3}$/.test(input.rw.trim())) return "RT dan RW diisi angka.";
	if (keluarga.some((k) => k.noKk === input.noKk.trim() && k.noKk !== ignoreNoKk)) return "Nomor KK ini sudah terdaftar.";
	if (input.latitude != null && (input.latitude < -90 || input.latitude > 90)) return "Lintang tidak valid.";
	if (input.longitude != null && (input.longitude < -180 || input.longitude > 180)) return "Bujur tidak valid.";
	const listrik = input.noListrik.trim();
	if (listrik && !/^\d{6,20}$/.test(listrik)) return "Nomor pelanggan listrik diisi 6–20 digit, atau dikosongkan.";
	return null;
}
function validatePenduduk(input, ctx) {
	const nik = input.nik.trim();
	if (!/^\d{16}$/.test(nik)) return "NIK harus 16 digit angka.";
	if (ctx.penduduk.some((p) => p.nik === nik && p.nik !== ctx.ignoreNik)) return "NIK sudah dipakai penduduk lain.";
	if (input.nama.trim().length < 3) return "Nama lengkap belum cukup.";
	if (input.jenisKelamin !== "L" && input.jenisKelamin !== "P") return "Jenis kelamin belum dipilih.";
	if (input.tempatLahir.trim().length < 2) return "Tempat lahir belum diisi.";
	if (!/^\d{4}-\d{2}-\d{2}$/.test(input.tanggalLahir)) return "Tanggal lahir tidak valid.";
	if (input.tanggalLahir > (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)) return "Tanggal lahir tidak boleh di masa depan.";
	if (!AGAMA.includes(input.agama)) return "Agama belum dipilih.";
	if (!STATUS_KAWIN.includes(input.statusPerkawinan)) return "Status perkawinan belum dipilih.";
	if (!ctx.pekerjaan.some((p) => p.id === input.pekerjaanId)) return "Pekerjaan belum dipilih.";
	if (!ctx.pendidikan.some((p) => p.id === input.pendidikanId)) return "Pendidikan belum dipilih.";
	if (!ctx.statusKeluarga.some((p) => p.id === input.statusId)) return "Status dalam keluarga belum dipilih.";
	const kk = ctx.keluarga.find((k) => k.noKk === input.noKk.trim());
	if (!kk) return "Nomor KK tidak ditemukan. Buat kartu keluarga terlebih dahulu.";
	const kepalaId = ctx.statusKeluarga.find((s) => s.nama === "Kepala Keluarga")?.id;
	if (kepalaId && input.statusId === kepalaId) {
		const lain = ctx.penduduk.find((p) => p.noKk === kk.noKk && p.statusId === kepalaId && p.statusHidup === "aktif" && p.nik !== ctx.ignoreNik);
		if (lain) return `Kartu keluarga ini sudah memiliki kepala keluarga: ${lain.nama}.`;
	}
	return null;
}
function kelompokUsia(penduduk, pita = KELOMPOK_USIA) {
	const hidup = penduduk.filter(aktif);
	return pita.map((k) => ({
		label: k.label,
		jumlah: hidup.filter((p) => {
			const u = umur(p.tanggalLahir);
			return u >= k.min && u <= k.max;
		}).length
	}));
}
function validasiKelompok(rows) {
	if (!rows.length) return "Minimal satu kelompok umur.";
	const bersih = rows.map((row) => ({
		...row,
		label: row.label.trim(),
		min: Number(row.min),
		max: Number(row.max)
	}));
	for (const row of bersih) {
		if (!row.label) return "Nama kelompok belum diisi.";
		if (!Number.isInteger(row.min) || !Number.isInteger(row.max) || row.min < 0 || row.max > 150 || row.min > row.max) return `Rentang "${row.label || "kelompok"}" tidak valid.`;
	}
	const urut = [...bersih].sort((a, b) => a.min - b.min);
	for (let i = 1; i < urut.length; i += 1) if (urut[i].min <= urut[i - 1].max) return "Rentang umur tidak boleh saling tumpang tindih.";
	return null;
}
function hitungMaster(penduduk, list, pick) {
	const hidup = penduduk.filter(aktif);
	return list.map((item) => ({
		label: item.nama,
		jumlah: hidup.filter((p) => pick(p) === item.id).length
	})).filter((row) => row.jumlah > 0).sort((a, b) => b.jumlah - a.jumlah);
}
function ringkas(rows, n = 6) {
	if (rows.length <= n) return rows;
	const head = rows.slice(0, n - 1);
	const rest = rows.slice(n - 1).reduce((sum, row) => sum + row.jumlah, 0);
	return [...head, {
		label: "Lainnya",
		jumlah: rest
	}];
}
function hitungTeks(penduduk, pick) {
	const map = /* @__PURE__ */ new Map();
	for (const p of penduduk.filter(aktif)) {
		const key = pick(p) || "—";
		map.set(key, (map.get(key) ?? 0) + 1);
	}
	return [...map.entries()].map(([label, jumlah]) => ({
		label,
		jumlah
	})).sort((a, b) => b.jumlah - a.jumlah);
}
function persen(bagian, total) {
	if (!total) return "0%";
	return `${(bagian / total * 100).toFixed(1).replace(".", ",")}%`;
}
var CSV_HEADERS = [
	"nik",
	"nama",
	"jenis_kelamin",
	"tempat_lahir",
	"tanggal_lahir",
	"agama",
	"status_perkawinan",
	"pekerjaan",
	"pendidikan",
	"status_keluarga",
	"no_kk",
	"nama_ayah",
	"nama_ibu"
];
function csvEscape(value) {
	if (/[",\n\r]/.test(value)) return `"${value.replace(/"/g, "\"\"")}"`;
	return value;
}
function pendudukToCsv(rows, ctx) {
	const lines = [CSV_HEADERS.join(",")];
	for (const p of rows) {
		const cols = [
			p.nik,
			p.nama,
			p.jenisKelamin,
			p.tempatLahir,
			p.tanggalLahir,
			p.agama,
			p.statusPerkawinan,
			namaMaster(ctx.pekerjaan, p.pekerjaanId),
			namaMaster(ctx.pendidikan, p.pendidikanId),
			namaMaster(ctx.statusKeluarga, p.statusId),
			p.noKk,
			p.namaAyah,
			p.namaIbu
		];
		lines.push(cols.map(csvEscape).join(","));
	}
	return lines.join("\n");
}
function templateCsv() {
	return [CSV_HEADERS.join(","), [
		"3524120101900099",
		"Nama Contoh",
		"L",
		"Lamongan",
		"1990-01-01",
		"Islam",
		"Kawin",
		"Petani",
		"SMA/SMK/Sederajat",
		"Kepala Keluarga",
		"3524120000001001",
		"Nama Ayah",
		"Nama Ibu"
	].join(",")].join("\n");
}
function parseCsv(text) {
	const rows = [];
	let row = [];
	let cur = "";
	let quoted = false;
	const src = text.replace(/^\uFEFF/, "");
	for (let i = 0; i < src.length; i += 1) {
		const c = src[i];
		if (quoted) {
			if (c === "\"") {
				if (src[i + 1] === "\"") {
					cur += "\"";
					i += 1;
				} else quoted = false;
			} else cur += c;
		} else if (c === "\"") quoted = true;
		else if (c === ",") {
			row.push(cur);
			cur = "";
		} else if (c === "\n") {
			row.push(cur);
			rows.push(row);
			row = [];
			cur = "";
		} else if (c !== "\r") cur += c;
	}
	if (cur.length || row.length) {
		row.push(cur);
		rows.push(row);
	}
	return rows.filter((r) => r.some((cell) => cell.trim() !== ""));
}
function planImport(matrix, ctx) {
	if (matrix.length < 2) return {
		ok: [],
		issues: [{
			baris: 1,
			pesan: "Berkas kosong atau hanya berisi judul kolom."
		}]
	};
	const header = matrix[0].map((h) => h.trim().toLowerCase());
	const missing = CSV_HEADERS.filter((h) => !header.includes(h));
	if (missing.length) return {
		ok: [],
		issues: [{
			baris: 1,
			pesan: `Kolom wajib belum ada: ${missing.join(", ")}.`
		}]
	};
	const idx = (name) => header.indexOf(name);
	const ok = [];
	const issues = [];
	const seen = /* @__PURE__ */ new Set();
	const penduduk = [...ctx.penduduk];
	matrix.slice(1).forEach((cols, index) => {
		const baris = index + 2;
		const cell = (name) => (cols[idx(name)] ?? "").trim();
		const jkRaw = cell("jenis_kelamin").toUpperCase();
		const jk = jkRaw === "L" || jkRaw === "LAKI-LAKI" ? "L" : jkRaw === "P" || jkRaw === "PEREMPUAN" ? "P" : "";
		const pekerjaan = ctx.pekerjaan.find((p) => p.nama.toLowerCase() === cell("pekerjaan").toLowerCase());
		const pendidikan = ctx.pendidikan.find((p) => p.nama.toLowerCase() === cell("pendidikan").toLowerCase());
		const status = ctx.statusKeluarga.find((p) => p.nama.toLowerCase() === cell("status_keluarga").toLowerCase());
		const kk = ctx.keluarga.find((k) => k.noKk === cell("no_kk"));
		const input = {
			nik: cell("nik"),
			nama: cell("nama"),
			jenisKelamin: jk || "L",
			tempatLahir: cell("tempat_lahir"),
			tanggalLahir: cell("tanggal_lahir"),
			agama: cell("agama"),
			statusPerkawinan: cell("status_perkawinan"),
			pekerjaanId: pekerjaan?.id ?? "",
			pendidikanId: pendidikan?.id ?? "",
			statusId: status?.id ?? "",
			noKk: cell("no_kk"),
			namaAyah: cell("nama_ayah"),
			namaIbu: cell("nama_ibu"),
			alamat: kk ? kk.alamat : ""
		};
		if (!jk) {
			issues.push({
				baris,
				pesan: "Jenis kelamin harus L atau P."
			});
			return;
		}
		if (!pekerjaan) {
			issues.push({
				baris,
				pesan: `Pekerjaan "${cell("pekerjaan")}" tidak ada di master data.`
			});
			return;
		}
		if (!pendidikan) {
			issues.push({
				baris,
				pesan: `Pendidikan "${cell("pendidikan")}" tidak ada di master data.`
			});
			return;
		}
		if (!status) {
			issues.push({
				baris,
				pesan: `Status keluarga "${cell("status_keluarga")}" tidak ada di master data.`
			});
			return;
		}
		if (seen.has(input.nik)) {
			issues.push({
				baris,
				pesan: "NIK dobel di dalam berkas."
			});
			return;
		}
		const err = validatePenduduk(input, {
			...ctx,
			penduduk
		});
		if (err) {
			issues.push({
				baris,
				pesan: err
			});
			return;
		}
		seen.add(input.nik);
		penduduk.push({
			...input,
			id: "tmp",
			statusHidup: "aktif",
			createdAt: ""
		});
		ok.push(input);
	});
	return {
		ok,
		issues
	};
}
function downloadText(filename, text, mime) {
	const blob = new Blob([text], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
}
function bulanIni(iso, today = /* @__PURE__ */ new Date()) {
	const [y, m] = iso.slice(0, 10).split("-");
	return Number(y) === today.getFullYear() && Number(m) === today.getMonth() + 1;
}
function jejakBaru(actor, aksi, entitas, detail) {
	return {
		id: crypto.randomUUID(),
		waktu: (/* @__PURE__ */ new Date()).toISOString(),
		actor,
		aksi,
		entitas,
		detail
	};
}
var seed_exports = /* @__PURE__ */ __exportAll({
	AUDIT_AWAL: () => AUDIT_AWAL,
	KELUARGA_AWAL: () => KELUARGA_AWAL,
	MUTASI_AWAL: () => MUTASI_AWAL,
	PEKERJAAN: () => PEKERJAAN,
	PENDIDIKAN: () => PENDIDIKAN,
	PENDUDUK_AWAL: () => PENDUDUK_AWAL,
	STATUS_KELUARGA: () => STATUS_KELUARGA,
	SURAT_AWAL: () => SURAT_AWAL,
	USERS_AWAL: () => USERS_AWAL,
	dataContoh: () => dataContoh,
	lengkapi: () => lengkapi
});
var PEKERJAAN = [
	{
		id: "pk-petani",
		nama: "Petani"
	},
	{
		id: "pk-dagang",
		nama: "Pedagang"
	},
	{
		id: "pk-pns",
		nama: "PNS"
	},
	{
		id: "pk-tni",
		nama: "TNI/Polri"
	},
	{
		id: "pk-guru",
		nama: "Guru"
	},
	{
		id: "pk-perawat",
		nama: "Perawat"
	},
	{
		id: "pk-swasta",
		nama: "Karyawan Swasta"
	},
	{
		id: "pk-buruh",
		nama: "Buruh"
	},
	{
		id: "pk-pensiun",
		nama: "Pensiunan"
	},
	{
		id: "pk-mahasiswa",
		nama: "Mahasiswa"
	},
	{
		id: "pk-pelajar",
		nama: "Pelajar"
	},
	{
		id: "pk-irt",
		nama: "Ibu Rumah Tangga"
	},
	{
		id: "pk-tidak",
		nama: "Tidak Bekerja"
	},
	{
		id: "pk-lain",
		nama: "Lainnya"
	}
];
var PENDIDIKAN = [
	{
		id: "pd-tidak",
		nama: "Tidak Sekolah"
	},
	{
		id: "pd-sd",
		nama: "SD/Sederajat"
	},
	{
		id: "pd-smp",
		nama: "SMP/Sederajat"
	},
	{
		id: "pd-sma",
		nama: "SMA/SMK/Sederajat"
	},
	{
		id: "pd-d3",
		nama: "Diploma III"
	},
	{
		id: "pd-s1",
		nama: "Diploma IV/S1"
	},
	{
		id: "pd-s2",
		nama: "S2"
	},
	{
		id: "pd-s3",
		nama: "S3"
	}
];
var STATUS_KELUARGA = [
	{
		id: "st-kk",
		nama: "Kepala Keluarga"
	},
	{
		id: "st-istri",
		nama: "Istri"
	},
	{
		id: "st-anak",
		nama: "Anak"
	},
	{
		id: "st-menantu",
		nama: "Menantu"
	},
	{
		id: "st-cucu",
		nama: "Cucu"
	},
	{
		id: "st-ortu",
		nama: "Orang Tua"
	},
	{
		id: "st-mertua",
		nama: "Mertua"
	},
	{
		id: "st-famili",
		nama: "Famili Lain"
	},
	{
		id: "st-pembantu",
		nama: "Pembantu"
	},
	{
		id: "st-lain",
		nama: "Lainnya"
	}
];
var T = "2026-01-12T02:00:00.000Z";
function kk(id, noKk, kepala, dusun, rt, rw, alamat, lat, lng, noListrik = "") {
	return {
		id,
		noKk,
		kepalaKeluarga: kepala,
		alamat,
		dusun,
		rt,
		rw,
		latitude: lat,
		longitude: lng,
		noListrik,
		fotoKk: null,
		fotoDepan: null,
		fotoDalam: null,
		fotoKamarMandi: null,
		fotoLokasi: null,
		createdAt: T
	};
}
var KELUARGA_AWAL = [
	kk("kk1", "3524120000001001", "Sarman", "Monongo", "01", "01", "Kampung Kulon", -7.1092, 112.3314, "541100220011"),
	kk("kk2", "3524120000001002", "Sarmin", "Monongo", "02", "01", "Kampung Wetan", -7.1084, 112.3326, "541100220028"),
	kk("kk3", "3524120000001003", "Arman", "Krajan", "01", "02", "Jl. Balai Desa", -7.1128, 112.336, "541100220035"),
	kk("kk4", "3524120000001004", "Sutrisno", "Krajan", "02", "02", "Gang Melati", -7.1136, 112.3371, "541100220042"),
	kk("kk5", "3524120000001005", "Ahmad Fauzi", "Sumberrejo", "01", "03", "Blok Sawah Lor", -7.1064, 112.3275, "541100330017"),
	kk("kk6", "3524120000001006", "Joko Santoso", "Sumberrejo", "02", "03", "Blok Sawah Kidul", -7.1055, 112.3284, "541100330024"),
	kk("kk7", "3524120000001007", "Sutini", "Monongo", "03", "01", "Kampung Kauman", -7.1101, 112.3302, "541100220059"),
	kk("kk8", "3524120000001008", "Eko Prasetyo", "Krajan", "03", "02", "Gang Kenanga", -7.1142, 112.3352, "541100220066")
];
function w(id, nik, nama, jk, lahir, tempat, agama, kawin, kerja, didik, noKk, status, ayah, ibu, hidup = "aktif") {
	return {
		id,
		nik,
		nama,
		jenisKelamin: jk,
		tempatLahir: tempat,
		tanggalLahir: lahir,
		agama,
		statusPerkawinan: kawin,
		pekerjaanId: kerja,
		pendidikanId: didik,
		alamat: KELUARGA_AWAL.find((k) => k.noKk === noKk)?.alamat ?? "",
		noKk,
		statusId: status,
		namaAyah: ayah,
		namaIbu: ibu,
		statusHidup: hidup,
		createdAt: T
	};
}
var PENDUDUK_AWAL = [
	w("p1", "3524121403780001", "Sarman", "L", "1978-03-14", "Lamongan", "Islam", "Kawin", "pk-petani", "pd-sma", "3524120000001001", "st-kk", "Karman", "Tuminah"),
	w("p2", "3524126107820002", "Siti Aminah", "P", "1982-07-21", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-smp", "3524120000001001", "st-istri", "Darmo", "Painem"),
	w("p3", "3524120211080003", "Andi Pratama", "L", "2008-11-02", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sma", "3524120000001001", "st-anak", "Sarman", "Siti Aminah"),
	w("p4", "3524125804120004", "Rina Aulia", "P", "2012-04-18", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-smp", "3524120000001001", "st-anak", "Sarman", "Siti Aminah"),
	w("p5", "3524120909160005", "Bagas Saputra", "L", "2016-09-09", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001001", "st-anak", "Sarman", "Siti Aminah"),
	w("p6", "3524123001750006", "Sarmin", "L", "1975-01-30", "Lamongan", "Islam", "Kawin", "pk-dagang", "pd-sma", "3524120000001002", "st-kk", "Sarju", "Tinah"),
	w("p7", "3524124512790007", "Murni", "P", "1979-12-05", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sd", "3524120000001002", "st-istri", "Karto", "Siyem"),
	w("p8", "3524126206040008", "Dewi Lestari", "P", "2004-06-22", "Lamongan", "Islam", "Belum Kawin", "pk-mahasiswa", "pd-sma", "3524120000001002", "st-anak", "Sarmin", "Murni"),
	w("p9", "3524121105880009", "Arman", "L", "1988-05-11", "Surabaya", "Islam", "Kawin", "pk-swasta", "pd-sma", "3524120000001003", "st-kk", "Rahman", "Ginem"),
	w("p10", "3524126802900010", "Lestari", "P", "1990-02-28", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sma", "3524120000001003", "st-istri", "Sukardi", "Waginem"),
	w("p11", "3524125408190011", "Nisa Amalia", "P", "2019-08-14", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001003", "st-anak", "Arman", "Lestari"),
	w("p12", "3524122001230012", "Rafa Ardian", "L", "2023-01-20", "Lamongan", "Islam", "Belum Kawin", "pk-tidak", "pd-tidak", "3524120000001003", "st-anak", "Arman", "Lestari"),
	w("p13", "3524120810520013", "Sutrisno", "L", "1952-10-08", "Lamongan", "Islam", "Kawin", "pk-pensiun", "pd-sma", "3524120000001004", "st-kk", "Rekso Diharjo", "Sutiyah"),
	w("p14", "3524125903550014", "Paini", "P", "1955-03-19", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sd", "3524120000001004", "st-istri", "Darmin", "Kasemi"),
	w("p15", "3524121102380015", "Rekso Diharjo", "L", "1938-02-11", "Lamongan", "Islam", "Kawin", "pk-tidak", "pd-tidak", "3524120000001004", "st-ortu", "Kartodikromo", "Minem", "meninggal"),
	w("p16", "3524120209840016", "Ahmad Fauzi", "L", "1984-09-02", "Lamongan", "Islam", "Kawin", "pk-pns", "pd-s1", "3524120000001005", "st-kk", "Hadi", "Rumini"),
	w("p17", "3524126711860017", "Yuni Kartika", "P", "1986-11-27", "Gresik", "Islam", "Kawin", "pk-guru", "pd-s1", "3524120000001005", "st-istri", "Suprapto", "Endang"),
	w("p18", "3524120605140018", "Farhan Aziz", "L", "2014-05-06", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001005", "st-anak", "Ahmad Fauzi", "Yuni Kartika"),
	w("p19", "3524127012170019", "Aisyah Nur", "P", "2017-12-30", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001005", "st-anak", "Ahmad Fauzi", "Yuni Kartika"),
	w("p20", "3524121504920020", "Joko Santoso", "L", "1992-04-15", "Lamongan", "Islam", "Kawin", "pk-buruh", "pd-smp", "3524120000001006", "st-kk", "Santoso", "Parti"),
	w("p21", "3524124908940021", "Wati", "P", "1994-08-09", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-smp", "3524120000001006", "st-istri", "Slamet", "Tumi"),
	w("p22", "3524120202210022", "Dimas Putra", "L", "2021-02-02", "Lamongan", "Islam", "Belum Kawin", "pk-tidak", "pd-tidak", "3524120000001006", "st-anak", "Joko Santoso", "Wati"),
	w("p23", "3524120303960023", "Budi Santoso", "L", "1996-03-03", "Lamongan", "Islam", "Belum Kawin", "pk-buruh", "pd-smp", "3524120000001006", "st-famili", "Santoso", "Parti", "pindah"),
	w("p24", "3524125206480024", "Sutini", "P", "1948-06-12", "Lamongan", "Islam", "Cerai Mati", "pk-tidak", "pd-tidak", "3524120000001007", "st-kk", "Kasan", "Sipon"),
	w("p25", "3524120707980025", "Eko Prasetyo", "L", "1998-07-07", "Lamongan", "Islam", "Kawin", "pk-petani", "pd-sma", "3524120000001008", "st-kk", "Prasetyo", "Sulastri"),
	w("p26", "3524126501000026", "Nur Halimah", "P", "2000-01-25", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sma", "3524120000001008", "st-istri", "Halim", "Musringah"),
	w("p27", "3524121209260027", "Ahmad Raihan", "L", "2026-09-12", "Lamongan", "Islam", "Belum Kawin", "pk-tidak", "pd-tidak", "3524120000001008", "st-anak", "Eko Prasetyo", "Nur Halimah")
];
var MUTASI_AWAL = [
	{
		id: "m1",
		jenis: "meninggal",
		nik: "3524121102380015",
		nama: "Rekso Diharjo",
		tanggal: "2026-06-15",
		keterangan: "Meninggal di rumah, Dusun Krajan.",
		noKk: "3524120000001004",
		actor: "Tajid",
		createdAt: "2026-06-15T04:00:00.000Z"
	},
	{
		id: "m2",
		jenis: "pindah_keluar",
		nik: "3524120303960023",
		nama: "Budi Santoso",
		tanggal: "2026-08-02",
		keterangan: "Pindah ke Desa Sukodadi karena kerja.",
		noKk: "3524120000001006",
		actor: "Tajid",
		createdAt: "2026-08-02T04:00:00.000Z"
	},
	{
		id: "m3",
		jenis: "lahir",
		nik: "3524121209260027",
		nama: "Ahmad Raihan",
		tanggal: "2026-09-12",
		keterangan: "Lahir di Puskesmas Sukodadi. Anak dari Eko Prasetyo dan Nur Halimah.",
		noKk: "3524120000001008",
		actor: "Tajid",
		createdAt: "2026-09-12T03:30:00.000Z"
	}
];
var SURAT_AWAL = [{
	id: "s1",
	nomor: "001/SKD/IX/2026",
	jenis: "domisili",
	nik: "3524121403780001",
	nama: "Sarman",
	keperluan: "pengurusan kepesertaan BPJS Kesehatan",
	tanggal: "2026-09-04",
	actor: "Kepala Desa Monongo",
	createdAt: "2026-09-04T02:00:00.000Z"
}, {
	id: "s2",
	nomor: "002/SKTM/IX/2026",
	jenis: "tidak_mampu",
	nik: "3524121504920020",
	nama: "Joko Santoso",
	keperluan: "pengajuan keringanan biaya sekolah anak",
	tanggal: "2026-09-18",
	actor: "Kepala Desa Monongo",
	createdAt: "2026-09-18T02:10:00.000Z"
}];
var USERS_AWAL = [
	{
		id: "u-admin",
		username: "admin",
		password: "monongo",
		nama: "Admin Desa",
		email: "admin@monongo.desa.id",
		noHp: "083846776155",
		alamat: "Balai Desa Monongo",
		role: "admin"
	},
	{
		id: "u-petugas",
		username: "petugas",
		password: "monongo",
		nama: "Tajid",
		email: "tajid@monongo.desa.id",
		noHp: "083846776155",
		alamat: "Dusun Monongo, Sukodadi",
		role: "petugas"
	},
	{
		id: "u-kepala",
		username: "kepala",
		password: "monongo",
		nama: "Kepala Desa Monongo",
		email: "kepala@monongo.desa.id",
		noHp: "081234567890",
		alamat: "Balai Desa Monongo",
		role: "kepala_desa"
	}
];
var AUDIT_AWAL = [
	{
		id: "a1",
		waktu: "2026-09-18T02:10:00.000Z",
		actor: "Kepala Desa Monongo",
		aksi: "Terbit",
		entitas: "Surat",
		detail: "002/SKTM/IX/2026 atas nama Joko Santoso"
	},
	{
		id: "a2",
		waktu: "2026-09-12T03:30:00.000Z",
		actor: "Tajid",
		aksi: "Catat",
		entitas: "Mutasi",
		detail: "Kelahiran Ahmad Raihan"
	},
	{
		id: "a3",
		waktu: "2026-08-02T04:00:00.000Z",
		actor: "Tajid",
		aksi: "Catat",
		entitas: "Mutasi",
		detail: "Pindah keluar Budi Santoso"
	}
];
function dataContoh() {
	return {
		users: USERS_AWAL.map((u) => ({ ...u })),
		pekerjaan: PEKERJAAN.map((x) => ({ ...x })),
		pendidikan: PENDIDIKAN.map((x) => ({ ...x })),
		statusKeluarga: STATUS_KELUARGA.map((x) => ({ ...x })),
		keluarga: KELUARGA_AWAL.map((x) => ({ ...x })),
		penduduk: PENDUDUK_AWAL.map((x) => ({ ...x })),
		mutasi: MUTASI_AWAL.map((x) => ({ ...x })),
		surat: SURAT_AWAL.map((x) => ({ ...x })),
		audit: AUDIT_AWAL.map((x) => ({ ...x })),
		suratSeq: 2,
		kelompokUsia: KELOMPOK_USIA.map((x) => ({ ...x }))
	};
}
function lengkapi(raw) {
	const dasar = dataContoh();
	if (!raw || !Array.isArray(raw.penduduk) || !Array.isArray(raw.users)) return dasar;
	return {
		users: raw.users.length ? raw.users : dasar.users,
		pekerjaan: raw.pekerjaan ?? dasar.pekerjaan,
		pendidikan: raw.pendidikan ?? dasar.pendidikan,
		statusKeluarga: raw.statusKeluarga ?? dasar.statusKeluarga,
		keluarga: (raw.keluarga ?? []).map((k) => ({
			...k,
			latitude: k.latitude ?? null,
			longitude: k.longitude ?? null,
			noListrik: k.noListrik ?? "",
			fotoKk: k.fotoKk ?? null,
			fotoDepan: k.fotoDepan ?? null,
			fotoDalam: k.fotoDalam ?? null,
			fotoKamarMandi: k.fotoKamarMandi ?? null,
			fotoLokasi: k.fotoLokasi ?? null
		})),
		penduduk: raw.penduduk,
		mutasi: raw.mutasi ?? [],
		surat: raw.surat ?? [],
		audit: raw.audit ?? [],
		suratSeq: typeof raw.suratSeq === "number" ? raw.suratSeq : 1,
		kelompokUsia: Array.isArray(raw.kelompokUsia) && raw.kelompokUsia.length ? raw.kelompokUsia : dasar.kelompokUsia
	};
}
//#endregion
export { ringkas as A, kelompokUsia as C, pendudukToCsv as D, parseCsv as E, validatePenduduk as F, __exportAll as I, umur as M, validasiKelompok as N, persen as O, validateKeluarga as P, jejakBaru as S, namaMaster as T, formatNomorSurat as _, CHART_COLORS as a, hitungMaster as b, MUTASI_LABEL as c, aktif as d, alamatKeluarga as f, downloadText as g, can as h, AGAMA as i, templateCsv as j, planImport as k, ROLE_LABEL as l, bulanIni as m, lengkapi as n, DEMO_AKUN as o, angka as p, seed_exports as r, DESA as s, dataContoh as t, STATUS_KAWIN as u, formatTanggal as v, labelKelamin as w, hitungTeks as x, formatWaktu as y };
