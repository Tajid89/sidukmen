import { i as PenggunaPage } from "./kelola-Cf35GC1B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pengguna-C3VQ7okU.js
var SplitComponent = PenggunaPage;
//#endregion
export { SplitComponent as component };
