import { t as KeluargaBaruPage } from "./keluarga-CJUAbv20.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/baru-kzB6WQSV.js
var SplitComponent = KeluargaBaruPage;
//#endregion
export { SplitComponent as component };
