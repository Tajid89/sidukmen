import { r as PendudukListPage } from "./penduduk-TltSk4Qb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/penduduk-D0LYTuzr.js
var SplitComponent = PendudukListPage;
//#endregion
export { SplitComponent as component };
