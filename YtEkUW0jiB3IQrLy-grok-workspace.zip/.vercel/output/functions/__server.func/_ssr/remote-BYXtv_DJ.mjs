import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/remote-BYXtv_DJ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tarikSiduk_createServerFn_handler = createServerRpc({
	id: "037ce7c7a8d9fc4c57383f73ba5947c3950550183aee7b7be9e7673fa72092ce",
	name: "tarikSiduk",
	filename: "src/lib/sidukmen/remote.ts"
}, (opts) => tarikSiduk.__executeServer(opts));
var tarikSiduk = createServerFn({ method: "GET" }).handler(tarikSiduk_createServerFn_handler, async () => {
	const { getSql } = await import("./db-CaWwX6Rh.mjs");
	const { dataContoh } = await import("./seed-DSw-2F5v.mjs").then((n) => n.r);
	const sql = await getSql();
	const ada = await sql`
    select payload, revisi from siduk_dokumen where id = 'utama'
  `;
	if (ada[0]) return {
		payload: ada[0].payload,
		revisi: Number(ada[0].revisi)
	};
	const payload = dataContoh();
	await sql`
    insert into siduk_dokumen (id, payload, revisi)
    values ('utama', ${JSON.stringify(payload)}::jsonb, 1)
    on conflict (id) do nothing
  `;
	const lagi = await sql`
    select payload, revisi from siduk_dokumen where id = 'utama'
  `;
	return {
		payload: lagi[0]?.payload ?? payload,
		revisi: Number(lagi[0]?.revisi ?? 1)
	};
});
var simpanSiduk_createServerFn_handler = createServerRpc({
	id: "2f5b0cf9dc13b362267bf3d07d305b8f3331f93e6c3b7d8928ca493273daf232",
	name: "simpanSiduk",
	filename: "src/lib/sidukmen/remote.ts"
}, (opts) => simpanSiduk.__executeServer(opts));
var simpanSiduk = createServerFn({ method: "POST" }).validator((input) => {
	if (!input?.payload || typeof input.revisi !== "number") throw new Error("Data tidak lengkap.");
	return input;
}).handler(simpanSiduk_createServerFn_handler, async ({ data }) => {
	const { getSql } = await import("./db-CaWwX6Rh.mjs");
	const sql = await getSql();
	const json = JSON.stringify(data.payload);
	const updated = await sql`
      update siduk_dokumen
      set payload = ${json}::jsonb, revisi = revisi + 1, updated_at = now()
      where id = 'utama' and revisi = ${data.revisi}
      returning revisi
    `;
	if (updated[0]) return {
		ok: true,
		revisi: Number(updated[0].revisi)
	};
	const current = await sql`
      select payload, revisi from siduk_dokumen where id = 'utama'
    `;
	if (!current[0]) {
		await sql`
        insert into siduk_dokumen (id, payload, revisi)
        values ('utama', ${json}::jsonb, 1)
      `;
		return {
			ok: true,
			revisi: 1
		};
	}
	return {
		ok: false,
		payload: current[0].payload,
		revisi: Number(current[0].revisi)
	};
});
//#endregion
export { simpanSiduk_createServerFn_handler, tarikSiduk_createServerFn_handler };
