import { o as __toESM } from "../_runtime.mjs";
import { M as umur, d as aktif, f as alamatKeluarga, h as can, w as labelKelamin } from "./seed-DSw-2F5v.mjs";
import { S as useNavigate, Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useSessionUser, s as useSiduk } from "./router-DBFAyprg.mjs";
import { a as Modal, l as control, n as Btn, o as Notice, r as Empty, t as Badge } from "./bits-DokRK5cV.mjs";
import { t as Shell } from "./shell-BOWreftS.mjs";
import { a as SLOT_FOTO, n as KeluargaForm, r as PanelGeotag, t as FotoBidang } from "./forms-Qk0mC1-q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/keluarga-CJUAbv20.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function KeluargaListPage() {
	const user = useSessionUser();
	const keluarga = useSiduk((s) => s.keluarga);
	const penduduk = useSiduk((s) => s.penduduk);
	const [q, setQ] = (0, import_react.useState)("");
	const [dusun, setDusun] = (0, import_react.useState)("");
	const dusunList = (0, import_react.useMemo)(() => [...new Set(keluarga.map((k) => k.dusun))], [keluarga]);
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return keluarga.filter((k) => {
			if (dusun && k.dusun !== dusun) return false;
			if (!query) return true;
			return k.noKk.includes(query) || k.kepalaKeluarga.toLowerCase().includes(query) || k.alamat.toLowerCase().includes(query) || k.noListrik.includes(query);
		});
	}, [
		keluarga,
		q,
		dusun
	]);
	if (!user) return null;
	const boleh = can(user.role, "keluarga.write");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: "Data keluarga",
		user,
		action: boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/keluarga/baru",
			className: "inline-flex h-11 items-center rounded-lg bg-brand px-4 text-sm font-semibold text-paper",
			children: "Tambah KK"
		}) : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-2 sm:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: control,
				placeholder: "No. KK, kepala keluarga, alamat, atau ID listrik",
				value: q,
				onChange: (e) => setQ(e.target.value),
				"aria-label": "Cari keluarga"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: control,
				value: dusun,
				onChange: (e) => setDusun(e.target.value),
				"aria-label": "Dusun",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "Semua dusun"
				}), dusunList.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
			})]
		}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "Tidak ada keluarga",
			body: "Tambah kartu keluarga sebelum mengisi anggota."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-3 lg:grid-cols-2",
			children: rows.map((k) => {
				const aktifCount = penduduk.filter((p) => p.noKk === k.noKk).filter(aktif).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/keluarga/$noKk",
					params: { noKk: k.noKk },
					className: "block rounded-xl border border-line bg-sheet p-4 hover:border-brand",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl",
								children: k.kepalaKeluarga
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-stone tabular-nums",
								children: k.noKk
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								tone: "brand",
								children: [aktifCount, " jiwa"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-stone",
							children: [
								"Dusun ",
								k.dusun,
								" · RT ",
								k.rt,
								"/RW ",
								k.rw
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: k.alamat
						}),
						k.noListrik ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-stone tabular-nums",
							children: ["Listrik ", k.noListrik]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs font-semibold text-stone",
							children: [jumlahFoto(k), "/5 foto"]
						})
					]
				}) }, k.noKk);
			})
		})]
	});
}
function KeluargaBaruPage() {
	const user = useSessionUser();
	const addKeluarga = useSiduk((s) => s.addKeluarga);
	const navigate = useNavigate();
	if (!user) return null;
	if (!can(user.role, "keluarga.write")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Tambah keluarga",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Peran Anda tidak dapat menambah kartu keluarga." })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Tambah keluarga",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-3xl rounded-xl border border-line bg-sheet p-4 md:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeluargaForm, {
				submitLabel: "Simpan KK",
				onCancel: () => navigate({ to: "/keluarga" }),
				onSubmit: (input) => {
					const err = addKeluarga(input);
					if (!err) {
						toast.success("Kartu keluarga disimpan");
						navigate({
							to: "/keluarga/$noKk",
							params: { noKk: input.noKk.trim() }
						});
					}
					return err;
				}
			})
		})
	});
}
function KeluargaDetailPage({ noKk }) {
	const user = useSessionUser();
	const keluarga = useSiduk((s) => s.keluarga);
	const penduduk = useSiduk((s) => s.penduduk);
	const statusKeluarga = useSiduk((s) => s.statusKeluarga);
	const updateKeluarga = useSiduk((s) => s.updateKeluarga);
	const deleteKeluarga = useSiduk((s) => s.deleteKeluarga);
	const navigate = useNavigate();
	const [edit, setEdit] = (0, import_react.useState)(false);
	const [hapus, setHapus] = (0, import_react.useState)(false);
	if (!user) return null;
	const kk = keluarga.find((k) => k.noKk === noKk);
	if (!kk) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Keluarga",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "KK tidak ditemukan",
			body: "Nomor ini tidak ada dalam data."
		})
	});
	const anggota = penduduk.filter((p) => p.noKk === kk.noKk);
	const boleh = can(user.role, "keluarga.write");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: kk.kepalaKeluarga,
		user,
		children: [edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-3xl rounded-xl border border-line bg-sheet p-4 md:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeluargaForm, {
				initial: keInput(kk),
				submitLabel: "Simpan perubahan",
				onCancel: () => setEdit(false),
				onSubmit: (input) => {
					const err = updateKeluarga(kk.noKk, input);
					if (!err) {
						toast.success("Keluarga diperbarui");
						setEdit(false);
						if (input.noKk.trim() !== kk.noKk) navigate({
							to: "/keluarga/$noKk",
							params: { noKk: input.noKk.trim() }
						});
					}
					return err;
				}
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-sheet p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-stone tabular-nums",
						children: ["No. KK ", kk.noKk]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: alamatKeluarga(kk)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-stone tabular-nums",
						children: ["Nomor pelanggan listrik: ", kk.noListrik || "belum diisi"]
					}),
					boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: () => setEdit(true),
							children: "Ubah KK"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "danger",
							onClick: () => setHapus(true),
							children: "Hapus KK"
						})]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelGeotag, {
					latitude: kk.latitude,
					longitude: kk.longitude,
					disabled: !boleh,
					pesanSukses: "Latitude dan longitude tersimpan.",
					onSimpan: (titik) => updateKeluarga(kk.noKk, {
						...keInput(kk),
						...titik
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Dokumentasi rumah"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 mb-3 max-w-2xl text-sm text-stone",
						children: "Foto KK, tampak rumah, kamar mandi, dan lokasi. Di ponsel, Kamera membuka kamera langsung. Berkas memilih gambar yang sudah ada."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: SLOT_FOTO.map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FotoBidang, {
							label: slot.label,
							hint: slot.hint,
							geotag: slot.geotag,
							disabled: !boleh,
							src: kk[slot.key] ?? null,
							onChange: (dataUrl, titik) => {
								const err = updateKeluarga(kk.noKk, {
									...keInput(kk),
									[slot.key]: dataUrl,
									...slot.geotag && titik ? {
										latitude: titik.latitude,
										longitude: titik.longitude
									} : {}
								});
								if (err) toast.error(err);
								else toast.success(dataUrl ? `${slot.label} disimpan` : `${slot.label} dihapus`);
							}
						}, slot.key))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Anggota"
				}), can(user.role, "penduduk.write") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/penduduk/baru",
					search: { kk: kk.noKk },
					className: "text-sm font-semibold text-brand",
					children: "Tambah anggota"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet",
				children: anggota.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-4 py-6 text-sm text-stone",
					children: "Belum ada anggota pada KK ini."
				}) : anggota.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/penduduk/$nik",
					params: { nik: p.nik },
					className: "flex items-center justify-between gap-3 px-4 py-3 hover:bg-paper",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-semibold",
						children: p.nama
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-stone",
						children: [
							statusKeluarga.find((s) => s.id === p.statusId)?.nama,
							" · ",
							labelKelamin(p.jenisKelamin),
							" · ",
							umur(p.tanggalLahir),
							" th"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: p.statusHidup === "aktif" ? "brand" : "sand",
						children: p.statusHidup
					})]
				}) }, p.nik))
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
			open: hapus,
			title: "Hapus kartu keluarga?",
			onClose: () => setHapus(false),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-stone",
				children: "KK hanya bisa dihapus jika sudah tidak punya anggota."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "danger",
				onClick: () => {
					const err = deleteKeluarga(kk.noKk);
					if (err) toast.error(err);
					else {
						toast.success("Kartu keluarga dihapus");
						navigate({ to: "/keluarga" });
					}
				},
				children: "Hapus"
			})]
		})]
	});
}
function jumlahFoto(k) {
	return SLOT_FOTO.filter((slot) => k[slot.key]).length;
}
function keInput(k) {
	return {
		noKk: k.noKk,
		kepalaKeluarga: k.kepalaKeluarga,
		alamat: k.alamat,
		dusun: k.dusun,
		rt: k.rt,
		rw: k.rw,
		latitude: k.latitude,
		longitude: k.longitude,
		noListrik: k.noListrik ?? "",
		fotoKk: k.fotoKk ?? null,
		fotoDepan: k.fotoDepan ?? null,
		fotoDalam: k.fotoDalam ?? null,
		fotoKamarMandi: k.fotoKamarMandi ?? null,
		fotoLokasi: k.fotoLokasi ?? null
	};
}
//#endregion
export { KeluargaDetailPage as n, KeluargaListPage as r, KeluargaBaruPage as t };
