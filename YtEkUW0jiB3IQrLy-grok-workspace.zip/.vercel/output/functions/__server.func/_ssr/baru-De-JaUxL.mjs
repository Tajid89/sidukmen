import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-DBFAyprg.mjs";
import { t as PendudukBaruPage } from "./penduduk-TltSk4Qb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/baru-De-JaUxL.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function PendudukBaruRoute() {
	const { kk } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendudukBaruPage, { noKk: kk ?? "" });
};
//#endregion
export { SplitComponent as component };
