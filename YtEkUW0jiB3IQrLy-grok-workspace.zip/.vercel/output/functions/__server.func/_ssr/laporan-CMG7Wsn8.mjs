import { n as LaporanPage } from "./kelola-Cf35GC1B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/laporan-CMG7Wsn8.js
var SplitComponent = LaporanPage;
//#endregion
export { SplitComponent as component };
