import { o as __toESM } from "../_runtime.mjs";
import { D as pendudukToCsv, E as parseCsv, M as umur, T as namaMaster, c as MUTASI_LABEL, d as aktif, f as alamatKeluarga, g as downloadText, h as can, j as templateCsv, k as planImport, v as formatTanggal, w as labelKelamin } from "./seed-DSw-2F5v.mjs";
import { S as useNavigate, Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useSessionUser, s as useSiduk } from "./router-DBFAyprg.mjs";
import { a as Modal, l as control, n as Btn, o as Notice, r as Empty, t as Badge } from "./bits-DokRK5cV.mjs";
import { t as Shell } from "./shell-BOWreftS.mjs";
import { i as PendudukForm } from "./forms-Qk0mC1-q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/penduduk-TltSk4Qb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PendudukListPage() {
	const user = useSessionUser();
	const penduduk = useSiduk((s) => s.penduduk);
	const keluarga = useSiduk((s) => s.keluarga);
	const pekerjaan = useSiduk((s) => s.pekerjaan);
	const pendidikan = useSiduk((s) => s.pendidikan);
	const statusKeluarga = useSiduk((s) => s.statusKeluarga);
	const importPenduduk = useSiduk((s) => s.importPenduduk);
	const [q, setQ] = (0, import_react.useState)("");
	const [jk, setJk] = (0, import_react.useState)("");
	const [dusun, setDusun] = (0, import_react.useState)("");
	const [hidup, setHidup] = (0, import_react.useState)("aktif");
	const [kerja, setKerja] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [importOpen, setImportOpen] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const dusunList = [...new Set(keluarga.map((k) => k.dusun))];
	const filtered = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return penduduk.filter((p) => {
			const kk = keluarga.find((k) => k.noKk === p.noKk);
			if (query && !p.nama.toLowerCase().includes(query) && !p.nik.includes(query)) return false;
			if (jk && p.jenisKelamin !== jk) return false;
			if (hidup === "aktif" && !aktif(p)) return false;
			if (hidup === "nonaktif" && aktif(p)) return false;
			if (kerja && p.pekerjaanId !== kerja) return false;
			if (dusun && kk?.dusun !== dusun) return false;
			return true;
		}).sort((a, b) => a.nama.localeCompare(b.nama, "id"));
	}, [
		penduduk,
		keluarga,
		q,
		jk,
		hidup,
		kerja,
		dusun
	]);
	if (!user) return null;
	const boleh = can(user.role, "penduduk.write");
	const size = 10;
	const pages = Math.max(1, Math.ceil(filtered.length / size));
	const current = Math.min(page, pages);
	const view = filtered.slice((current - 1) * size, current * size);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: "Data penduduk",
		user,
		action: boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "ghost",
				onClick: () => setImportOpen(true),
				children: "Impor"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/penduduk/baru",
				search: { kk: "" },
				className: "inline-flex h-11 items-center rounded-lg bg-brand px-4 text-sm font-semibold text-paper",
				children: "Tambah"
			})]
		}) : void 0,
		children: [
			!boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-stone",
				children: "Anda masuk sebagai kepala desa. Data dapat dilihat, perubahan dilakukan petugas."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: control,
						placeholder: "Nama atau NIK",
						value: q,
						onChange: (e) => {
							setQ(e.target.value);
							setPage(1);
						},
						"aria-label": "Saring nama"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: control,
						value: jk,
						onChange: (e) => {
							setJk(e.target.value);
							setPage(1);
						},
						"aria-label": "Jenis kelamin",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Semua kelamin"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "L",
								children: "Laki-laki"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "P",
								children: "Perempuan"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: control,
						value: dusun,
						onChange: (e) => {
							setDusun(e.target.value);
							setPage(1);
						},
						"aria-label": "Dusun",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Semua dusun"
						}), dusunList.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: control,
						value: kerja,
						onChange: (e) => {
							setKerja(e.target.value);
							setPage(1);
						},
						"aria-label": "Pekerjaan",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Semua pekerjaan"
						}), pekerjaan.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.nama
						}, item.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: control,
						value: hidup,
						onChange: (e) => {
							setHidup(e.target.value);
							setPage(1);
						},
						"aria-label": "Status kependudukan",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "aktif",
								children: "Penduduk aktif"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "nonaktif",
								children: "Meninggal / pindah"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Semua status"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3 text-sm text-stone",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [filtered.length, " jiwa"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "font-semibold text-brand",
					onClick: () => downloadText("penduduk-sidukmen.csv", pendudukToCsv(filtered, {
						pekerjaan,
						pendidikan,
						statusKeluarga
					}), "text/csv;charset=utf-8"),
					children: "Unduh CSV"
				})]
			}),
			view.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Tidak ada penduduk",
				body: "Ubah saringan, atau tambah data baru."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet",
				children: view.map((p) => {
					const kk = keluarga.find((k) => k.noKk === p.noKk);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/penduduk/$nik",
						params: { nik: p.nik },
						className: "flex flex-col gap-1 px-4 py-3 hover:bg-paper sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: p.nama
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-stone tabular-nums",
								children: [
									p.nik,
									" · ",
									labelKelamin(p.jenisKelamin),
									" · ",
									umur(p.tanggalLahir),
									" th"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2 text-sm text-stone",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: namaMaster(pekerjaan, p.pekerjaanId) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: kk?.dusun ?? "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { orang: p })
							]
						})]
					}) }, p.nik);
				})
			}),
			pages > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						disabled: current <= 1,
						onClick: () => setPage((n) => Math.max(1, n - 1)),
						children: "Sebelumnya"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-stone tabular-nums",
						children: [
							current,
							" / ",
							pages
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						disabled: current >= pages,
						onClick: () => setPage((n) => n + 1),
						children: "Berikutnya"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open: importOpen,
				title: "Impor CSV",
				onClose: () => {
					setImportOpen(false);
					setPreview(null);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-stone",
						children: "Baris yang gagal dilewati. Kartu keluarga harus sudah ada. Unduh contoh kolom bila perlu."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						onClick: () => downloadText("contoh-penduduk.csv", templateCsv(), "text/csv;charset=utf-8"),
						children: "Unduh contoh"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-3 block w-full text-sm",
						type: "file",
						accept: ".csv,text/csv",
						onChange: async (event) => {
							const file = event.target.files?.[0];
							if (!file) return;
							const text = await file.text();
							const plan = planImport(parseCsv(text), {
								penduduk,
								keluarga,
								pekerjaan,
								pendidikan,
								statusKeluarga
							});
							setPreview({
								ok: plan.ok.length,
								issues: plan.issues.slice(0, 8),
								rows: plan.ok
							});
						}
					}),
					preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [preview.ok, " baris siap disimpan."] }),
							preview.issues.map((issue) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-clay",
								children: [
									"Baris ",
									issue.baris,
									": ",
									issue.pesan
								]
							}, `${issue.baris}-${issue.pesan}`)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								disabled: !preview.ok,
								onClick: () => {
									const err = importPenduduk(preview.rows);
									if (err) toast.error(err);
									else {
										toast.success(`${preview.ok} penduduk ditambahkan`);
										setImportOpen(false);
										setPreview(null);
									}
								},
								children: "Simpan yang sah"
							})
						]
					}) : null
				]
			})
		]
	});
}
function StatusBadge({ orang }) {
	if (orang.statusHidup === "aktif") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "brand",
		children: "Aktif"
	});
	if (orang.statusHidup === "meninggal") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "clay",
		children: "Meninggal"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: "sand",
		children: "Pindah"
	});
}
function PendudukBaruPage({ noKk = "" }) {
	const user = useSessionUser();
	const addPenduduk = useSiduk((s) => s.addPenduduk);
	const navigate = useNavigate();
	if (!user) return null;
	if (!can(user.role, "penduduk.write")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Tambah penduduk",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Peran Anda tidak dapat menambah penduduk." })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Tambah penduduk",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-4xl rounded-xl border border-line bg-sheet p-4 md:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendudukForm, {
				initial: { noKk },
				submitLabel: "Simpan penduduk",
				onCancel: () => navigate({ to: "/penduduk" }),
				onSubmit: (input) => {
					const err = addPenduduk(input);
					if (!err) {
						toast.success("Penduduk disimpan");
						navigate({
							to: "/penduduk/$nik",
							params: { nik: input.nik.trim() }
						});
					}
					return err;
				}
			})
		})
	});
}
function PendudukDetailPage({ nik }) {
	const user = useSessionUser();
	const penduduk = useSiduk((s) => s.penduduk);
	const keluarga = useSiduk((s) => s.keluarga);
	const pekerjaan = useSiduk((s) => s.pekerjaan);
	const pendidikan = useSiduk((s) => s.pendidikan);
	const statusKeluarga = useSiduk((s) => s.statusKeluarga);
	const mutasi = useSiduk((s) => s.mutasi);
	const updatePenduduk = useSiduk((s) => s.updatePenduduk);
	const deletePenduduk = useSiduk((s) => s.deletePenduduk);
	const aktifkan = useSiduk((s) => s.aktifkan);
	const navigate = useNavigate();
	const [edit, setEdit] = (0, import_react.useState)(false);
	const [hapus, setHapus] = (0, import_react.useState)(false);
	if (!user) return null;
	const orang = penduduk.find((p) => p.nik === nik);
	if (!orang) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Penduduk",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
			title: "Tidak ditemukan",
			body: "NIK ini tidak ada di data desa."
		})
	});
	const kk = keluarga.find((k) => k.noKk === orang.noKk);
	const boleh = can(user.role, "penduduk.write");
	const bolehMutasi = can(user.role, "mutasi.write");
	const riwayat = mutasi.filter((m) => m.nik === orang.nik);
	const rows = [
		["NIK", orang.nik],
		["Jenis kelamin", labelKelamin(orang.jenisKelamin)],
		["Tempat, tanggal lahir", `${orang.tempatLahir}, ${formatTanggal(orang.tanggalLahir)} (${umur(orang.tanggalLahir)} tahun)`],
		["Agama", orang.agama],
		["Perkawinan", orang.statusPerkawinan],
		["Pekerjaan", namaMaster(pekerjaan, orang.pekerjaanId)],
		["Pendidikan", namaMaster(pendidikan, orang.pendidikanId)],
		["Status keluarga", namaMaster(statusKeluarga, orang.statusId)],
		["Ayah", orang.namaAyah || "—"],
		["Ibu", orang.namaIbu || "—"],
		["Alamat", kk ? alamatKeluarga(kk) : orang.alamat]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: orang.nama,
		user,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { orang }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: labelKelamin(orang.jenisKelamin) }),
					kk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/keluarga/$noKk",
						params: { noKk: kk.noKk },
						className: "text-sm font-semibold text-brand",
						children: ["KK ", kk.kepalaKeluarga]
					}) : null
				]
			}),
			edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-w-4xl rounded-xl border border-line bg-sheet p-4 md:p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendudukForm, {
					initial: orang,
					submitLabel: "Simpan perubahan",
					onCancel: () => setEdit(false),
					onSubmit: (input) => {
						const err = updatePenduduk(orang.nik, input);
						if (!err) {
							toast.success("Perubahan disimpan");
							setEdit(false);
							if (input.nik.trim() !== orang.nik) navigate({
								to: "/penduduk/$nik",
								params: { nik: input.nik.trim() }
							});
						}
						return err;
					}
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "divide-y divide-line rounded-xl border border-line bg-sheet",
					children: rows.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1 px-4 py-3 sm:grid-cols-[12rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-stone",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-medium",
							children: value
						})]
					}, label))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							className: "w-full",
							onClick: () => setEdit(true),
							children: "Ubah data"
						}) : null,
						bolehMutasi && orang.statusHidup === "aktif" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/mutasi",
							search: {
								nik: orang.nik,
								jenis: "meninggal"
							},
							className: "inline-flex h-11 w-full items-center justify-center rounded-lg border border-line bg-sheet text-sm font-semibold",
							children: "Catat mutasi"
						}) : null,
						bolehMutasi && orang.statusHidup !== "aktif" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "ghost",
							className: "w-full",
							onClick: () => {
								const err = aktifkan(orang.nik);
								if (err) toast.error(err);
								else toast.success("Status dikembalikan menjadi aktif");
							},
							children: "Kembalikan aktif"
						}) : null,
						boleh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							variant: "danger",
							className: "w-full",
							onClick: () => setHapus(true),
							children: "Hapus"
						}) : null
					]
				})]
			}),
			riwayat.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-display text-xl",
					children: "Riwayat mutasi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: riwayat.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border border-line bg-sheet px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-semibold",
							children: [
								MUTASI_LABEL[item.jenis],
								" · ",
								formatTanggal(item.tanggal)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-stone",
							children: item.keterangan
						})]
					}, item.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open: hapus,
				title: "Hapus penduduk?",
				onClose: () => setHapus(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-4 text-sm text-stone",
					children: [orang.nama, " akan dihapus dari daftar. Riwayat mutasi yang sudah tercatat tetap menyimpan nama."]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "danger",
						onClick: () => {
							const err = deletePenduduk(orang.nik);
							if (err) toast.error(err);
							else {
								toast.success("Penduduk dihapus");
								navigate({ to: "/penduduk" });
							}
						},
						children: "Hapus"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "ghost",
						onClick: () => setHapus(false),
						children: "Batal"
					})]
				})]
			})
		]
	});
}
//#endregion
export { PendudukDetailPage as n, PendudukListPage as r, PendudukBaruPage as t };
