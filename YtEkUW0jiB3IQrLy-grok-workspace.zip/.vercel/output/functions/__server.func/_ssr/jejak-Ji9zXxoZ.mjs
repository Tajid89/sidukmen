import { t as JejakPage } from "./kelola-Cf35GC1B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jejak-Ji9zXxoZ.js
var SplitComponent = JejakPage;
//#endregion
export { SplitComponent as component };
