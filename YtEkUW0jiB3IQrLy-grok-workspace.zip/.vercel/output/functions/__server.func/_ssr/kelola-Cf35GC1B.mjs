import { o as __toESM } from "../_runtime.mjs";
import { C as kelompokUsia, O as persen, b as hitungMaster, c as MUTASI_LABEL, d as aktif, h as can, l as ROLE_LABEL, p as angka, s as DESA, x as hitungTeks, y as formatWaktu } from "./seed-DSw-2F5v.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as useSessionUser, s as useSiduk } from "./router-DBFAyprg.mjs";
import { a as Modal, c as Stat, i as Field, l as control, n as Btn, o as Notice, r as Empty, s as Panel, t as Badge } from "./bits-DokRK5cV.mjs";
import { t as Shell } from "./shell-BOWreftS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kelola-Cf35GC1B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Baris({ label, jumlah, total }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-3 border-b border-line py-2 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-12 text-right font-semibold tabular-nums",
				children: jumlah
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-14 text-right text-stone tabular-nums",
				children: persen(jumlah, total)
			})
		]
	});
}
function LaporanPage() {
	const user = useSessionUser();
	const penduduk = useSiduk((s) => s.penduduk);
	const keluarga = useSiduk((s) => s.keluarga);
	const pekerjaan = useSiduk((s) => s.pekerjaan);
	const pendidikan = useSiduk((s) => s.pendidikan);
	const statusKeluarga = useSiduk((s) => s.statusKeluarga);
	const mutasi = useSiduk((s) => s.mutasi);
	const pita = useSiduk((s) => s.kelompokUsia);
	if (!user) return null;
	const hidup = penduduk.filter(aktif);
	const laki = hidup.filter((p) => p.jenisKelamin === "L").length;
	const kerja = hitungMaster(penduduk, pekerjaan, (p) => p.pekerjaanId);
	const didik = hitungMaster(penduduk, pendidikan, (p) => p.pendidikanId);
	const status = hitungMaster(penduduk, statusKeluarga, (p) => p.statusId);
	const agama = hitungTeks(penduduk, (p) => p.agama);
	const kawin = hitungTeks(penduduk, (p) => p.statusPerkawinan);
	const usia = kelompokUsia(penduduk, pita);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Laporan",
		user,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			onClick: () => window.print(),
			children: "Cetak"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "print-sheet space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "rounded-xl border border-line bg-sheet px-4 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold tracking-wide text-stone uppercase",
							children: ["Pemerintah Desa ", DESA.nama]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Laporan kependudukan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-stone",
							children: [
								"Kecamatan ",
								DESA.kecamatan,
								", Kabupaten ",
								DESA.kabupaten,
								". Dihitung dari penduduk aktif."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Penduduk aktif",
							value: angka(hidup.length),
							note: `${angka(laki)} laki-laki · ${angka(hidup.length - laki)} perempuan`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Keluarga",
							value: angka(keluarga.length),
							note: "kartu keluarga"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Mutasi tercatat",
							value: angka(mutasi.length),
							note: "semua jenis"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Jenis kelamin",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: "Laki-laki",
								jumlah: laki,
								total: hidup.length
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: "Perempuan",
								jumlah: hidup.length - laki,
								total: hidup.length
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Kelompok usia",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: usia.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: row.label,
								jumlah: row.jumlah,
								total: hidup.length
							}, row.label)) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Pekerjaan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: kerja.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: row.label,
								jumlah: row.jumlah,
								total: hidup.length
							}, row.label)) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Pendidikan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: didik.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: row.label,
								jumlah: row.jumlah,
								total: hidup.length
							}, row.label)) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Agama",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: agama.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: row.label,
								jumlah: row.jumlah,
								total: hidup.length
							}, row.label)) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Perkawinan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: kawin.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: row.label,
								jumlah: row.jumlah,
								total: hidup.length
							}, row.label)) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Status dalam keluarga",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: status.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: row.label,
								jumlah: row.jumlah,
								total: hidup.length
							}, row.label)) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
							title: "Mutasi",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: Object.keys(MUTASI_LABEL).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Baris, {
								label: MUTASI_LABEL[key],
								jumlah: mutasi.filter((m) => m.jenis === key).length,
								total: mutasi.length
							}, key)) })
						})
					]
				})
			]
		})
	});
}
var MASTER = [
	{
		kind: "pekerjaan",
		title: "Pekerjaan"
	},
	{
		kind: "pendidikan",
		title: "Pendidikan terakhir"
	},
	{
		kind: "statusKeluarga",
		title: "Status dalam keluarga"
	}
];
function MasterPage() {
	const user = useSessionUser();
	const pekerjaan = useSiduk((s) => s.pekerjaan);
	const pendidikan = useSiduk((s) => s.pendidikan);
	const statusKeluarga = useSiduk((s) => s.statusKeluarga);
	const addMaster = useSiduk((s) => s.addMaster);
	const renameMaster = useSiduk((s) => s.renameMaster);
	const deleteMaster = useSiduk((s) => s.deleteMaster);
	const lists = {
		pekerjaan,
		pendidikan,
		statusKeluarga
	};
	const [draft, setDraft] = (0, import_react.useState)({});
	const [edit, setEdit] = (0, import_react.useState)(null);
	if (!user) return null;
	if (!can(user.role, "master.write")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Master data",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Hanya admin dan petugas yang mengubah master data." })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: "Master data",
		user,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 xl:grid-cols-3",
				children: MASTER.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: group.title,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mb-3 flex gap-2",
						onSubmit: (event) => {
							event.preventDefault();
							const err = addMaster(group.kind, draft[group.kind] ?? "");
							if (err) toast.error(err);
							else {
								toast.success("Master ditambahkan");
								setDraft((prev) => ({
									...prev,
									[group.kind]: ""
								}));
							}
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							placeholder: "Nama baru",
							value: draft[group.kind] ?? "",
							onChange: (e) => setDraft((prev) => ({
								...prev,
								[group.kind]: e.target.value
							})),
							"aria-label": `Tambah ${group.title}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: "Tambah"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-line",
						children: lists[group.kind].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.nama }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "font-semibold text-brand",
									onClick: () => setEdit({
										kind: group.kind,
										id: item.id,
										nama: item.nama
									}),
									children: "Ubah"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "font-semibold text-clay",
									onClick: () => {
										const err = deleteMaster(group.kind, item.id);
										if (err) toast.error(err);
										else toast.success("Dihapus");
									},
									children: "Hapus"
								})]
							})]
						}, item.id))
					})]
				}, group.kind))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RentangUmur, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: !!edit,
				title: "Ubah nama",
				onClose: () => setEdit(null),
				children: edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-4",
					onSubmit: (event) => {
						event.preventDefault();
						const err = renameMaster(edit.kind, edit.id, edit.nama);
						if (err) toast.error(err);
						else {
							toast.success("Nama diperbarui");
							setEdit(null);
						}
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: edit.nama,
							onChange: (e) => setEdit({
								...edit,
								nama: e.target.value
							}),
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "Simpan"
					})]
				}) : null
			})
		]
	});
}
function RentangUmur() {
	const tersimpan = useSiduk((s) => s.kelompokUsia);
	const simpanKelompok = useSiduk((s) => s.simpanKelompok);
	const [rows, setRows] = (0, import_react.useState)(tersimpan);
	(0, import_react.useEffect)(() => {
		setRows(tersimpan);
	}, [tersimpan]);
	function setBaris(id, patch) {
		setRows((prev) => prev.map((row) => row.id === id ? {
			...row,
			...patch
		} : row));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Kelompok umur",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-stone",
				children: "Sesuaikan nama dan rentang tahun. Kelompok tidak boleh saling tumpang tindih. Dasbor dan laporan mengikuti pengaturan ini."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-2 sm:grid-cols-[minmax(0,1.4fr)_5rem_5rem_auto]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							"aria-label": "Nama kelompok",
							value: row.label,
							onChange: (e) => setBaris(row.id, { label: e.target.value })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							"aria-label": "Umur minimum",
							inputMode: "numeric",
							value: row.min,
							onChange: (e) => setBaris(row.id, { min: Number(e.target.value.replace(/\D/g, "") || 0) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							"aria-label": "Umur maksimum",
							inputMode: "numeric",
							value: row.max,
							onChange: (e) => setBaris(row.id, { max: Number(e.target.value.replace(/\D/g, "") || 0) })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "button",
							variant: "ghost",
							disabled: rows.length < 2,
							onClick: () => setRows((prev) => prev.filter((item) => item.id !== row.id)),
							children: "Hapus"
						})
					]
				}, row.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "button",
					variant: "ghost",
					onClick: () => setRows((prev) => [...prev, {
						id: crypto.randomUUID(),
						label: "",
						min: 0,
						max: 0
					}]),
					children: "Tambah rentang"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "button",
					onClick: () => {
						const err = simpanKelompok(rows);
						if (err) toast.error(err);
						else toast.success("Kelompok umur disimpan");
					},
					children: "Simpan rentang"
				})]
			})
		]
	});
}
var EMPTY_USER = {
	username: "",
	password: "",
	nama: "",
	email: "",
	noHp: "",
	alamat: "",
	role: "petugas"
};
function PenggunaPage() {
	const user = useSessionUser();
	const users = useSiduk((s) => s.users);
	const addUser = useSiduk((s) => s.addUser);
	const updateUser = useSiduk((s) => s.updateUser);
	const deleteUser = useSiduk((s) => s.deleteUser);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editId, setEditId] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)(EMPTY_USER);
	const [error, setError] = (0, import_react.useState)(null);
	if (!user) return null;
	if (!can(user.role, "user.write")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Pengguna",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: "Hanya admin yang mengelola pengguna." })
	});
	function bukaBaru() {
		setEditId(null);
		setForm(EMPTY_USER);
		setError(null);
		setOpen(true);
	}
	function bukaUbah(row) {
		setEditId(row.id);
		setForm({
			...row,
			password: ""
		});
		setError(null);
		setOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: "Pengguna",
		user,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			onClick: bukaBaru,
			children: "Tambah"
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet",
			children: users.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: row.nama
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-stone",
					children: [
						row.username,
						" · ",
						row.email || "tanpa surel"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "brand",
							children: ROLE_LABEL[row.role]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-semibold text-brand",
							onClick: () => bukaUbah(row),
							children: "Ubah"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-semibold text-clay",
							onClick: () => {
								const err = deleteUser(row.id);
								if (err) toast.error(err);
								else toast.success("Pengguna dihapus");
							},
							children: "Hapus"
						})
					]
				})]
			}, row.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			title: editId ? "Ubah pengguna" : "Pengguna baru",
			onClose: () => setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (event) => {
					event.preventDefault();
					const err = editId ? updateUser(editId, form) : addUser(form);
					setError(err);
					if (!err) {
						toast.success(editId ? "Pengguna diperbarui" : "Pengguna ditambahkan");
						setOpen(false);
					}
				},
				children: [
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: error }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama pengguna",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.username,
							onChange: (e) => setForm({
								...form,
								username: e.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama lengkap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.nama,
							onChange: (e) => setForm({
								...form,
								nama: e.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: editId ? "Kata sandi baru" : "Kata sandi",
						hint: editId ? "Kosongkan jika tidak diganti." : "Minimal 6 karakter.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							type: "password",
							value: form.password,
							onChange: (e) => setForm({
								...form,
								password: e.target.value
							}),
							required: !editId
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Surel",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							type: "email",
							value: form.email,
							onChange: (e) => setForm({
								...form,
								email: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nomor HP",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.noHp,
							onChange: (e) => setForm({
								...form,
								noHp: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Alamat",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.alamat,
							onChange: (e) => setForm({
								...form,
								alamat: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Peran",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: control,
							value: form.role,
							onChange: (e) => setForm({
								...form,
								role: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "admin",
									children: "Admin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "petugas",
									children: "Petugas"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "kepala_desa",
									children: "Kepala desa"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						type: "submit",
						children: "Simpan"
					})
				]
			})
		})]
	});
}
function JejakPage() {
	const user = useSessionUser();
	const audit = useSiduk((s) => s.audit);
	const [q, setQ] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		if (!query) return audit;
		return audit.filter((item) => `${item.aksi} ${item.entitas} ${item.detail} ${item.actor}`.toLowerCase().includes(query));
	}, [audit, q]);
	if (!user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: "Jejak perubahan",
		user,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 max-w-2xl text-sm text-stone",
				children: "Catatan siapa mengubah penduduk, keluarga, mutasi, dan pengguna. Disimpan bersama data desa di peramban ini."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `${control} mb-4 max-w-md`,
				placeholder: "Cari aksi atau nama",
				value: q,
				onChange: (e) => setQ(e.target.value),
				"aria-label": "Saring jejak"
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Jejak kosong",
				body: "Perubahan berikutnya akan tercatat di sini."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet",
				children: rows.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-semibold",
							children: [
								item.aksi,
								" · ",
								item.entitas
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: item.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-stone",
							children: [
								item.actor,
								" · ",
								formatWaktu(item.waktu)
							]
						})
					]
				}, item.id))
			})
		]
	});
}
function ProfilPage() {
	const user = useSessionUser();
	const updateProfile = useSiduk((s) => s.updateProfile);
	const changePassword = useSiduk((s) => s.changePassword);
	const [nama, setNama] = (0, import_react.useState)(user?.nama ?? "");
	const [email, setEmail] = (0, import_react.useState)(user?.email ?? "");
	const [noHp, setNoHp] = (0, import_react.useState)(user?.noHp ?? "");
	const [alamat, setAlamat] = (0, import_react.useState)(user?.alamat ?? "");
	const [lama, setLama] = (0, import_react.useState)("");
	const [baru, setBaru] = (0, import_react.useState)("");
	if (!user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		title: "Profil",
		user,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid max-w-3xl gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Data petugas",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mb-3 text-sm text-stone",
					children: [
						ROLE_LABEL[user.role],
						" · ",
						user.username
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3",
					onSubmit: (event) => {
						event.preventDefault();
						const err = updateProfile({
							nama,
							email,
							noHp,
							alamat
						});
						if (err) toast.error(err);
						else toast.success("Profil disimpan");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nama",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								value: nama,
								onChange: (e) => setNama(e.target.value),
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Surel",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nomor HP",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								value: noHp,
								onChange: (e) => setNoHp(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Alamat",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								value: alamat,
								onChange: (e) => setAlamat(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: "Simpan profil"
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Kata sandi",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3",
					onSubmit: (event) => {
						event.preventDefault();
						const err = changePassword(lama, baru);
						if (err) toast.error(err);
						else {
							toast.success("Kata sandi diperbarui");
							setLama("");
							setBaru("");
						}
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Kata sandi lama",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								type: "password",
								value: lama,
								onChange: (e) => setLama(e.target.value),
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Kata sandi baru",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								type: "password",
								value: baru,
								onChange: (e) => setBaru(e.target.value),
								required: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							type: "submit",
							children: "Ganti sandi"
						})
					]
				})
			})]
		})
	});
}
//#endregion
export { ProfilPage as a, PenggunaPage as i, LaporanPage as n, MasterPage as r, JejakPage as t };
