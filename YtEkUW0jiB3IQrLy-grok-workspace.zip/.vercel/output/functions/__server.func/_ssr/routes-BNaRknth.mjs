import { o as __toESM } from "../_runtime.mjs";
import { l as ROLE_LABEL, o as DEMO_AKUN, s as DESA } from "./seed-DSw-2F5v.mjs";
import { S as useNavigate, Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as useUser, s as useSiduk } from "./router-DBFAyprg.mjs";
import { i as Field, l as control, n as Btn, o as Notice } from "./bits-DokRK5cV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BNaRknth.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MasukPage() {
	const user = useUser();
	const login = useSiduk((s) => s.login);
	const navigate = useNavigate();
	const [username, setUsername] = (0, import_react.useState)("admin");
	const [password, setPassword] = (0, import_react.useState)("monongo");
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (user) navigate({ to: "/dasbor" });
	}, [user, navigate]);
	if (user) return null;
	function masuk(nama, sandi) {
		const err = login(nama, sandi);
		setError(err);
		if (!err) navigate({ to: "/dasbor" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "grid min-h-screen lg:grid-cols-[22rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col justify-between bg-brand px-6 py-8 text-paper lg:px-8 lg:py-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-white/70 uppercase",
					children: ["Kabupaten ", DESA.kabupaten]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl font-semibold leading-tight",
					children: "SIDUKMEN"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 max-w-xs text-sm leading-6 text-white/75",
					children: [
						"Sistem data kependudukan Desa ",
						DESA.nama,
						", Kecamatan ",
						DESA.kecamatan,
						". Penduduk, kartu keluarga, dan dokumentasi rumah dalam satu meja."
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-sm text-white/75",
				children: "Data desa tersimpan di database server, dipakai bersama oleh perangkat yang masuk."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "flex items-center px-4 py-10 sm:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl text-ink",
						children: "Masuk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-stone",
						children: "Pilih peran contoh, atau isi nama pengguna sendiri."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 grid gap-2",
						children: DEMO_AKUN.map((akun) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "rounded-xl border border-line bg-sheet px-4 py-3 text-left hover:border-brand",
							onClick: () => {
								setUsername(akun.username);
								setPassword(akun.password);
								masuk(akun.username, akun.password);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-semibold",
								children: akun.username
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-stone",
								children: akun.peran
							})]
						}, akun.username))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 space-y-4",
						onSubmit: (event) => {
							event.preventDefault();
							masuk(username, password);
						},
						children: [
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: error }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nama pengguna",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: control,
									value: username,
									onChange: (e) => setUsername(e.target.value),
									autoComplete: "username",
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Kata sandi",
								hint: "Akun contoh memakai sandi monongo.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: control,
									type: "password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									autoComplete: "current-password",
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								type: "submit",
								className: "w-full",
								children: "Masuk ke desa"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs text-stone",
						children: [
							"Peran: ",
							Object.values(ROLE_LABEL).join(", "),
							"."
						]
					})
				]
			})
		})]
	});
}
var SplitComponent = MasukPage;
//#endregion
export { SplitComponent as component };
