import { r as MasterPage } from "./kelola-Cf35GC1B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-9ug1dinj.js
var SplitComponent = MasterPage;
//#endregion
export { SplitComponent as component };
