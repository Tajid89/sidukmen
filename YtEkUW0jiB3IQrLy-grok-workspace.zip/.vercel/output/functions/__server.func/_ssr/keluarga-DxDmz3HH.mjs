import { r as KeluargaListPage } from "./keluarga-CJUAbv20.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/keluarga-DxDmz3HH.js
var SplitComponent = KeluargaListPage;
//#endregion
export { SplitComponent as component };
