import { o as __toESM } from "../_runtime.mjs";
import { i as AGAMA, u as STATUS_KAWIN } from "./seed-DSw-2F5v.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Camera, a as Trash2, c as MapPin, d as ImagePlus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { s as useSiduk } from "./router-DBFAyprg.mjs";
import { a as Modal, i as Field, l as control, n as Btn, o as Notice } from "./bits-DokRK5cV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forms-Qk0mC1-q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function kompresGambar(file) {
	if (!file.type.startsWith("image/")) throw new Error("Berkas ini bukan gambar.");
	if (file.size > 15728640) throw new Error("Gambar terlalu besar. Maksimal 15 MB.");
	const url = URL.createObjectURL(file);
	try {
		const img = await muatGambar(url);
		const scale = Math.min(1, 960 / Math.max(img.width, img.height));
		const canvas = document.createElement("canvas");
		canvas.width = Math.max(1, Math.round(img.width * scale));
		canvas.height = Math.max(1, Math.round(img.height * scale));
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Gambar tidak dapat diproses.");
		ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
		return canvas.toDataURL("image/jpeg", .62);
	} finally {
		URL.revokeObjectURL(url);
	}
}
function muatGambar(url) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Format gambar tidak didukung. Gunakan JPG atau PNG."));
		img.src = url;
	});
}
function lokasiPerangkat() {
	return ambilLokasi().then((hasil) => hasil.ok ? {
		latitude: hasil.latitude,
		longitude: hasil.longitude
	} : null);
}
function ambilLokasi() {
	if (typeof navigator === "undefined" || !navigator.geolocation) return Promise.resolve({
		ok: false,
		pesan: "Peramban ini tidak mendukung GPS."
	});
	return new Promise((resolve) => {
		navigator.geolocation.getCurrentPosition((pos) => resolve({
			ok: true,
			latitude: Math.round(pos.coords.latitude * 1e6) / 1e6,
			longitude: Math.round(pos.coords.longitude * 1e6) / 1e6,
			accuracy: Math.round(pos.coords.accuracy)
		}), (err) => resolve({
			ok: false,
			pesan: err.code === 1 ? "Izin lokasi ditolak. Aktifkan lokasi untuk situs ini, lalu coba lagi." : "Sinyal GPS belum terbaca. Coba di luar ruangan."
		}), {
			enableHighAccuracy: true,
			timeout: 12e3,
			maximumAge: 0
		});
	});
}
async function bacaGpsExif(file) {
	try {
		const buf = await file.slice(0, 524288).arrayBuffer();
		const view = new DataView(buf);
		if (view.byteLength < 4 || view.getUint16(0) !== 65496) return null;
		let offset = 2;
		while (offset + 4 < view.byteLength) {
			const marker = view.getUint16(offset);
			if (marker === 65498 || marker === 65497) break;
			const size = view.getUint16(offset + 2);
			if (size < 2 || offset + 2 + size > view.byteLength) break;
			if (marker === 65505) return gpsDariExif(view, offset + 4, size - 2);
			offset += 2 + size;
		}
	} catch {
		return null;
	}
	return null;
}
function gpsDariExif(view, start, length) {
	if (length < 16) return null;
	if ([
		0,
		1,
		2,
		3
	].map((i) => String.fromCharCode(view.getUint8(start + i))).join("") !== "Exif") return null;
	const tiff = start + 6;
	if (tiff + 8 > view.byteLength) return null;
	const order = view.getUint16(tiff);
	const le = order === 18761;
	if (!le && order !== 19789) return null;
	const u16 = (o) => view.getUint16(o, le);
	const u32 = (o) => view.getUint32(o, le);
	if (u16(tiff + 2) !== 42) return null;
	const gpsPtr = pointerIfd(view, tiff + u32(tiff + 4), 34853, u16, u32);
	if (gpsPtr == null) return null;
	return bacaGps(view, tiff, tiff + gpsPtr, u16, u32, le);
}
function pointerIfd(view, ifd, tag, u16, u32) {
	if (ifd + 2 > view.byteLength) return null;
	const count = u16(ifd);
	for (let i = 0; i < count; i += 1) {
		const entry = ifd + 2 + i * 12;
		if (entry + 12 > view.byteLength) return null;
		if (u16(entry) === tag) return u32(entry + 8);
	}
	return null;
}
function bacaGps(view, tiff, gps, u16, u32, le) {
	if (gps + 2 > view.byteLength) return null;
	const count = u16(gps);
	let lat = null;
	let lng = null;
	let latRef = "N";
	let lngRef = "E";
	for (let i = 0; i < count; i += 1) {
		const entry = gps + 2 + i * 12;
		if (entry + 12 > view.byteLength) break;
		const tag = u16(entry);
		const type = u16(entry);
		const n = u32(entry + 4);
		const val = u32(entry + 8);
		if (tag === 1 && type === 2) latRef = ascii(view, entry + 8, 2);
		if (tag === 3 && type === 2) lngRef = ascii(view, entry + 8, 2);
		if ((tag === 2 || tag === 4) && type === 5 && n === 3) {
			const off = tiff + val;
			const d = rasio(view, off, le);
			const m = rasio(view, off + 8, le);
			const s = rasio(view, off + 16, le);
			const deg = d + m / 60 + s / 3600;
			if (tag === 2) lat = deg;
			else lng = deg;
		}
	}
	if (lat == null || lng == null) return null;
	if (latRef === "S") lat = -lat;
	if (lngRef === "W") lng = -lng;
	if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return null;
	return {
		latitude: Math.round(lat * 1e6) / 1e6,
		longitude: Math.round(lng * 1e6) / 1e6
	};
}
function rasio(view, offset, le) {
	if (offset + 8 > view.byteLength) return 0;
	const den = view.getUint32(offset + 4, le);
	if (!den) return 0;
	return view.getUint32(offset, le) / den;
}
function ascii(view, offset, n) {
	let out = "";
	for (let i = 0; i < n; i += 1) {
		if (offset + i >= view.byteLength) break;
		const c = view.getUint8(offset + i);
		if (c === 0) break;
		out += String.fromCharCode(c);
	}
	return out;
}
var SLOT_FOTO = [
	{
		key: "fotoKk",
		label: "Foto KK",
		hint: "Halaman kartu keluarga, usahakan tulisan terbaca."
	},
	{
		key: "fotoDepan",
		label: "Depan rumah",
		hint: "Tampak muka rumah dari jalan."
	},
	{
		key: "fotoDalam",
		label: "Dalam rumah",
		hint: "Ruang utama di dalam rumah."
	},
	{
		key: "fotoKamarMandi",
		label: "Kamar mandi",
		hint: "Kondisi kamar mandi."
	},
	{
		key: "fotoLokasi",
		label: "Foto lokasi",
		hint: "Ambil di depan rumah. Koordinat dibaca dari foto, atau dari GPS perangkat.",
		geotag: true
	}
];
function FotoBidang({ label, hint, src, geotag, disabled, onChange }) {
	const kamera = (0, import_react.useRef)(null);
	const berkas = (0, import_react.useRef)(null);
	const [sibuk, setSibuk] = (0, import_react.useState)(false);
	const [lihat, setLihat] = (0, import_react.useState)(false);
	async function ambil(file) {
		if (!file) return;
		setSibuk(true);
		try {
			const dataUrl = await kompresGambar(file);
			let titik = null;
			if (geotag) {
				titik = await bacaGpsExif(file) ?? await lokasiPerangkat();
				if (!titik) toast.message("Foto tersimpan, koordinat belum terbaca. Izinkan lokasi, atau isi lintang dan bujur.");
			}
			onChange(dataUrl, titik);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Gambar gagal diproses.");
		} finally {
			setSibuk(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-paper p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs leading-5 text-stone",
				children: hint
			}),
			src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 block w-full",
				onClick: () => setLihat(true),
				"aria-label": `Lihat ${label}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: label,
					className: "h-40 w-full rounded-lg object-cover"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid h-40 place-items-center rounded-lg border border-dashed border-line text-sm text-stone",
				children: "Belum ada foto"
			}),
			disabled ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						type: "button",
						variant: "ghost",
						disabled: sibuk,
						onClick: () => kamera.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }), sibuk ? "Memproses…" : "Kamera"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						type: "button",
						variant: "ghost",
						disabled: sibuk,
						onClick: () => berkas.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), "Berkas"]
					}),
					src ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						type: "button",
						variant: "ghost",
						disabled: sibuk,
						onClick: () => onChange(null, null),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Hapus"]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: kamera,
				className: "hidden",
				type: "file",
				accept: "image/*",
				capture: "environment",
				onChange: (event) => {
					ambil(event.target.files?.[0]);
					event.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: berkas,
				className: "hidden",
				type: "file",
				accept: "image/*",
				onChange: (event) => {
					ambil(event.target.files?.[0]);
					event.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: lihat && !!src,
				title: label,
				onClose: () => setLihat(false),
				children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: label,
					className: "max-h-[70vh] w-full object-contain"
				}) : null
			})
		]
	});
}
function PanelGeotag({ latitude, longitude, disabled, pesanSukses, onSimpan }) {
	const [sibuk, setSibuk] = (0, import_react.useState)(false);
	const [akurasi, setAkurasi] = (0, import_react.useState)(null);
	const siap = latitude != null && longitude != null;
	const peta = siap ? `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=18/${latitude}/${longitude}` : null;
	async function ambil() {
		setSibuk(true);
		const hasil = await ambilLokasi();
		setSibuk(false);
		if (!hasil.ok) {
			toast.error(hasil.pesan);
			return;
		}
		const err = onSimpan({
			latitude: hasil.latitude,
			longitude: hasil.longitude
		});
		if (err) {
			toast.error(err);
			return;
		}
		setAkurasi(hasil.accuracy);
		toast.success(pesanSukses);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-line bg-sheet p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Geotagging"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-stone",
				children: "Ambil titik rumah dari GPS. Latitude dan longitude tersimpan pada kartu keluarga ini."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-paper px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-stone",
							children: "Latitude"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-2xl tabular-nums",
							children: siap ? latitude : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-stone",
							children: "Lintang"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-paper px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-stone",
							children: "Longitude"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-2xl tabular-nums",
							children: siap ? longitude : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-stone",
							children: "Bujur"
						})
					]
				})]
			}),
			akurasi != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-stone",
				children: [
					"Akurasi perkiraan ±",
					akurasi,
					" meter."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2 sm:flex-row",
				children: [disabled ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					type: "button",
					disabled: sibuk,
					onClick: () => void ambil(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), sibuk ? "Mencari sinyal…" : "Ambil lokasi"]
				}), peta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "inline-flex h-11 items-center justify-center rounded-lg border border-line bg-sheet px-4 text-sm font-semibold",
					href: peta,
					target: "_blank",
					rel: "noreferrer",
					children: "Lihat titik di peta"
				}) : null]
			})
		]
	});
}
function PendudukForm({ initial, submitLabel, onSubmit, onCancel }) {
	const keluarga = useSiduk((s) => s.keluarga);
	const pekerjaan = useSiduk((s) => s.pekerjaan);
	const pendidikan = useSiduk((s) => s.pendidikan);
	const statusKeluarga = useSiduk((s) => s.statusKeluarga);
	const [error, setError] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		nik: initial?.nik ?? "",
		nama: initial?.nama ?? "",
		jenisKelamin: initial?.jenisKelamin ?? "L",
		tempatLahir: initial?.tempatLahir ?? "Lamongan",
		tanggalLahir: initial?.tanggalLahir ?? "",
		agama: initial?.agama ?? "Islam",
		statusPerkawinan: initial?.statusPerkawinan ?? "Belum Kawin",
		pekerjaanId: initial?.pekerjaanId ?? pekerjaan[0]?.id ?? "",
		pendidikanId: initial?.pendidikanId ?? pendidikan[0]?.id ?? "",
		alamat: initial?.alamat ?? "",
		noKk: initial?.noKk ?? "",
		statusId: initial?.statusId ?? statusKeluarga[0]?.id ?? "",
		namaAyah: initial?.namaAyah ?? "",
		namaIbu: initial?.namaIbu ?? ""
	});
	const set = (patch) => setForm((prev) => ({
		...prev,
		...patch
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-5",
		onSubmit: (event) => {
			event.preventDefault();
			const kk = keluarga.find((k) => k.noKk === form.noKk);
			const message = onSubmit({
				...form,
				alamat: kk?.alamat ?? form.alamat
			});
			setError(message);
		},
		children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: error }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nomor KK",
						hint: "Pilih kartu keluarga yang sudah terdaftar.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: control,
							value: form.noKk,
							onChange: (e) => set({ noKk: e.target.value }),
							required: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Pilih KK"
							}), keluarga.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: k.noKk,
								children: [
									k.noKk,
									" — ",
									k.kepalaKeluarga
								]
							}, k.noKk))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "NIK",
						hint: "16 digit. Kode wilayah contoh Lamongan diawali 3524.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							inputMode: "numeric",
							maxLength: 16,
							value: form.nik,
							onChange: (e) => set({ nik: e.target.value.replace(/\D/g, "") }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama lengkap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.nama,
							onChange: (e) => set({ nama: e.target.value }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Jenis kelamin",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: control,
							value: form.jenisKelamin,
							onChange: (e) => set({ jenisKelamin: e.target.value }),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "L",
								children: "Laki-laki"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "P",
								children: "Perempuan"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tempat lahir",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.tempatLahir,
							onChange: (e) => set({ tempatLahir: e.target.value }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tanggal lahir",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							type: "date",
							value: form.tanggalLahir,
							onChange: (e) => set({ tanggalLahir: e.target.value }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Agama",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: control,
							value: form.agama,
							onChange: (e) => set({ agama: e.target.value }),
							children: AGAMA.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Status perkawinan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: control,
							value: form.statusPerkawinan,
							onChange: (e) => set({ statusPerkawinan: e.target.value }),
							children: STATUS_KAWIN.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pekerjaan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: control,
							value: form.pekerjaanId,
							onChange: (e) => set({ pekerjaanId: e.target.value }),
							children: pekerjaan.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.nama
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pendidikan terakhir",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: control,
							value: form.pendidikanId,
							onChange: (e) => set({ pendidikanId: e.target.value }),
							children: pendidikan.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.nama
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Status dalam keluarga",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: control,
							value: form.statusId,
							onChange: (e) => set({ statusId: e.target.value }),
							children: statusKeluarga.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.nama
							}, item.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama ayah",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.namaAyah,
							onChange: (e) => set({ namaAyah: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nama ibu",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.namaIbu,
							onChange: (e) => set({ namaIbu: e.target.value })
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: submitLabel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "button",
					variant: "ghost",
					onClick: onCancel,
					children: "Batal"
				})]
			})
		]
	});
}
function KeluargaForm({ initial, submitLabel, onSubmit, onCancel }) {
	const [error, setError] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		noKk: initial?.noKk ?? "",
		kepalaKeluarga: initial?.kepalaKeluarga ?? "",
		alamat: initial?.alamat ?? "",
		dusun: initial?.dusun ?? "Monongo",
		rt: initial?.rt ?? "01",
		rw: initial?.rw ?? "01",
		latitude: initial?.latitude ?? null,
		longitude: initial?.longitude ?? null,
		noListrik: initial?.noListrik ?? "",
		fotoKk: initial?.fotoKk ?? null,
		fotoDepan: initial?.fotoDepan ?? null,
		fotoDalam: initial?.fotoDalam ?? null,
		fotoKamarMandi: initial?.fotoKamarMandi ?? null,
		fotoLokasi: initial?.fotoLokasi ?? null
	});
	const set = (patch) => setForm((prev) => ({
		...prev,
		...patch
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-5",
		onSubmit: (event) => {
			event.preventDefault();
			setError(onSubmit(form));
		},
		children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, { children: error }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nomor KK",
						hint: "16 digit angka.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							inputMode: "numeric",
							maxLength: 16,
							value: form.noKk,
							onChange: (e) => set({ noKk: e.target.value.replace(/\D/g, "") }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kepala keluarga",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.kepalaKeluarga,
							onChange: (e) => set({ kepalaKeluarga: e.target.value }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Dusun",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.dusun,
							onChange: (e) => set({ dusun: e.target.value }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "RT",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								value: form.rt,
								onChange: (e) => set({ rt: e.target.value }),
								required: true
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "RW",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: control,
								value: form.rw,
								onChange: (e) => set({ rw: e.target.value }),
								required: true
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Alamat",
						hint: "Nama kampung atau gang, tanpa mengulang dusun.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							value: form.alamat,
							onChange: (e) => set({ alamat: e.target.value }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nomor pelanggan listrik",
						hint: "ID pelanggan PLN. Kosongkan jika belum ada sambungan.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							inputMode: "numeric",
							maxLength: 20,
							value: form.noListrik,
							onChange: (e) => set({ noListrik: e.target.value.replace(/\D/g, "") })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Lintang",
						hint: "Kosongkan jika belum diukur.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							inputMode: "decimal",
							value: form.latitude ?? "",
							onChange: (e) => set({ latitude: e.target.value === "" ? null : Number(e.target.value) })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bujur",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: control,
							inputMode: "decimal",
							value: form.longitude ?? "",
							onChange: (e) => set({ longitude: e.target.value === "" ? null : Number(e.target.value) })
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelGeotag, {
				latitude: form.latitude,
				longitude: form.longitude,
				pesanSukses: "Koordinat terisi. Tekan simpan agar tercatat.",
				onSimpan: (titik) => {
					set(titik);
					return null;
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: SLOT_FOTO.map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FotoBidang, {
					label: slot.label,
					hint: slot.hint,
					geotag: slot.geotag,
					src: form[slot.key],
					onChange: (dataUrl, titik) => set({
						[slot.key]: dataUrl,
						...slot.geotag && titik ? {
							latitude: titik.latitude,
							longitude: titik.longitude
						} : {}
					})
				}, slot.key))
			}),
			form.latitude != null && form.longitude != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-stone tabular-nums",
				children: [
					"Koordinat rumah: ",
					form.latitude,
					", ",
					form.longitude
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				type: "button",
				variant: "ghost",
				onClick: () => set({
					latitude: -7.1098,
					longitude: 112.333
				}),
				children: "Isi titik perkiraan Desa Monongo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "submit",
					children: submitLabel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					type: "button",
					variant: "ghost",
					onClick: onCancel,
					children: "Batal"
				})]
			})
		]
	});
}
//#endregion
export { SLOT_FOTO as a, PendudukForm as i, KeluargaForm as n, PanelGeotag as r, FotoBidang as t };
