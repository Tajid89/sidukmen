import { A as ringkas, C as kelompokUsia, M as umur, a as CHART_COLORS, b as hitungMaster, c as MUTASI_LABEL, d as aktif, m as bulanIni, p as angka, v as formatTanggal, x as hitungTeks } from "./seed-DSw-2F5v.mjs";
import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useSessionUser, s as useSiduk } from "./router-DBFAyprg.mjs";
import { c as Stat, s as Panel } from "./bits-DokRK5cV.mjs";
import { t as Shell } from "./shell-BOWreftS.mjs";
import { a as CartesianGrid, c as Cell, i as XAxis, l as ResponsiveContainer, n as BarChart, o as Bar, r as YAxis, s as Pie, t as PieChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dasbor-Dv3Guls2.js
var import_jsx_runtime = require_jsx_runtime();
function PetaTitik({ titik }) {
	if (titik.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-stone",
		children: "Belum ada kartu keluarga yang punya koordinat."
	});
	const lats = titik.map((t) => t.lat);
	const lngs = titik.map((t) => t.lng);
	const minLat = Math.min(...lats);
	const maxLat = Math.max(...lats);
	const minLng = Math.min(...lngs);
	const maxLng = Math.max(...lngs);
	const padLat = Math.max((maxLat - minLat) * .18, .0012);
	const padLng = Math.max((maxLng - minLng) * .18, .0012);
	const x = (lng) => (lng - (minLng - padLng)) / (maxLng - minLng + padLng * 2) * 100;
	const y = (lat) => (maxLat + padLat - lat) / (maxLat - minLat + padLat * 2) * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_16rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-72 overflow-hidden rounded-lg border border-line bg-paper",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0",
				"aria-hidden": "true",
				children: [Array.from({ length: 4 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute right-0 left-0 border-t border-line",
					style: { top: `${(i + 1) * 20}%` }
				}, `h${i}`)), Array.from({ length: 5 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-0 bottom-0 border-l border-line",
					style: { left: `${(i + 1) * 16}%` }
				}, `v${i}`))]
			}), titik.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/keluarga/$noKk",
				params: { noKk: item.id },
				className: "absolute z-10 grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center",
				style: {
					left: `${x(item.lng)}%`,
					top: `${y(item.lat)}%`
				},
				title: `${item.nama}, Dusun ${item.meta}`,
				"aria-label": `${item.nama}, Dusun ${item.meta}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-6 place-items-center rounded-full bg-brand text-[11px] font-semibold text-paper",
					children: index + 1
				})
			}, item.id))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "max-h-72 space-y-1 overflow-auto text-sm",
			children: titik.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/keluarga/$noKk",
				params: { noKk: item.id },
				className: "flex items-baseline gap-2 rounded-md px-1 py-1 hover:bg-paper",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-5 font-semibold text-brand tabular-nums",
					children: index + 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: item.nama
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-xs text-stone",
					children: ["Dusun ", item.meta]
				})] })]
			}) }, item.id))
		})]
	});
}
function Tip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-line bg-sheet px-3 py-2 text-sm text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-stone",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-semibold tabular-nums",
			children: [angka(payload[0]?.value ?? 0), " jiwa"]
		})]
	});
}
function DasborPage() {
	const user = useSessionUser();
	const penduduk = useSiduk((s) => s.penduduk);
	const keluarga = useSiduk((s) => s.keluarga);
	const pekerjaan = useSiduk((s) => s.pekerjaan);
	const pendidikan = useSiduk((s) => s.pendidikan);
	const mutasi = useSiduk((s) => s.mutasi);
	const audit = useSiduk((s) => s.audit);
	const pita = useSiduk((s) => s.kelompokUsia);
	if (!user) return null;
	const hidup = penduduk.filter(aktif);
	const laki = hidup.filter((p) => p.jenisKelamin === "L").length;
	const perempuan = hidup.length - laki;
	const muda = pita[0];
	const tua = pita[pita.length - 1];
	const dalam = (band) => band ? hidup.filter((p) => {
		const u = umur(p.tanggalLahir);
		return u >= band.min && u <= band.max;
	}).length : 0;
	const kerja = ringkas(hitungMaster(penduduk, pekerjaan, (p) => p.pekerjaanId));
	const didik = hitungMaster(penduduk, pendidikan, (p) => p.pendidikanId);
	const usia = kelompokUsia(penduduk, pita);
	const dusunMap = /* @__PURE__ */ new Map();
	for (const kk of keluarga) {
		const row = dusunMap.get(kk.dusun) ?? {
			kk: 0,
			jiwa: 0
		};
		row.kk += 1;
		row.jiwa += hidup.filter((p) => p.noKk === kk.noKk).length;
		dusunMap.set(kk.dusun, row);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		title: "Dasbor",
		user,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-5 max-w-2xl text-sm text-stone",
				children: "Ringkasan penduduk aktif. Yang meninggal atau pindah tetap tersimpan di riwayat, tetapi tidak dihitung di sini."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Penduduk aktif",
						value: angka(hidup.length),
						note: "jiwa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Keluarga",
						value: angka(keluarga.length),
						note: "kartu keluarga"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Laki-laki",
						value: angka(laki),
						note: perempuan ? `${angka(perempuan)} perempuan` : "perempuan 0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Perempuan",
						value: angka(perempuan),
						note: "jiwa"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: muda ? muda.label : "Kelompok muda",
						value: angka(dalam(muda)),
						note: muda ? `${muda.min}–${muda.max} tahun` : "atur di master"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: tua && tua !== muda ? tua.label : "Kelompok lain",
						value: angka(tua && tua !== muda ? dalam(tua) : 0),
						note: tua && tua !== muda ? `${tua.min}–${tua.max} tahun` : "tambah rentang di master"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Mutasi bulan ini",
						value: angka(mutasi.filter((m) => bulanIni(m.tanggal)).length),
						note: "kejadian"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "KK berfoto",
						value: angka(keluarga.filter((k) => k.fotoDepan || k.fotoKk || k.fotoLokasi || k.fotoDalam || k.fotoKamarMandi).length),
						note: `dari ${angka(keluarga.length)} keluarga`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 xl:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						title: "Pekerjaan",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-52",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
									data: kerja,
									dataKey: "jumlah",
									nameKey: "label",
									innerRadius: 48,
									outerRadius: 78,
									stroke: "transparent",
									children: kerja.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: CHART_COLORS[index % CHART_COLORS.length] }, row.label))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) })] })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1 text-sm",
							children: kerja.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-2.5 rounded-full",
										style: { background: CHART_COLORS[index % CHART_COLORS.length] }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-stone",
										children: row.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto font-semibold tabular-nums",
										children: row.jumlah
									})
								]
							}, row.label))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Pendidikan",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-72",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: didik,
									layout: "vertical",
									margin: {
										left: 8,
										right: 8
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "var(--color-line)",
											horizontal: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											type: "number",
											allowDecimals: false,
											tick: {
												fill: "var(--color-stone)",
												fontSize: 12
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											type: "category",
											dataKey: "label",
											width: 108,
											tick: {
												fill: "var(--color-stone)",
												fontSize: 11
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "jumlah",
											fill: "var(--color-brand)",
											radius: [
												0,
												4,
												4,
												0
											]
										})
									]
								})
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Kelompok usia",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-72",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: usia,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "var(--color-line)",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "label",
											tick: {
												fill: "var(--color-stone)",
												fontSize: 12
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											allowDecimals: false,
											tick: {
												fill: "var(--color-stone)",
												fontSize: 12
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "jumlah",
											fill: "var(--color-brandsoft)",
											radius: [
												4,
												4,
												0,
												0
											]
										})
									]
								})
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Sebaran dusun",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-left text-stone",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold",
										children: "Dusun"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-semibold",
										children: "KK"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 text-right font-semibold",
										children: "Jiwa"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [...dusunMap.entries()].map(([dusun, row]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5",
										children: dusun
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "tabular-nums",
										children: row.kk
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "text-right font-semibold tabular-nums",
										children: row.jiwa
									})
								]
							}, dusun)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Agama",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2 text-sm",
							children: hitungTeks(penduduk, (p) => p.agama).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 border-b border-line py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold tabular-nums",
									children: row.jumlah
								})]
							}, row.label))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Mutasi terbaru",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-3",
							children: mutasi.slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "border-b border-line pb-3 last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: item.nama
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-stone",
									children: [
										MUTASI_LABEL[item.jenis],
										" · ",
										formatTanggal(item.tanggal)
									]
								})]
							}, item.id))
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Peta rumah",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-stone",
						children: "Titik mengikuti koordinat kartu keluarga. Sentuh nama untuk membuka KK."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PetaTitik, { titik: keluarga.filter((k) => k.latitude != null && k.longitude != null).map((k) => ({
						id: k.noKk,
						nama: k.kepalaKeluarga,
						lat: k.latitude,
						lng: k.longitude,
						meta: k.dusun
					})) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Jejak terakhir",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2 text-sm",
						children: audit.slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-col gap-0.5 border-b border-line py-2 sm:flex-row sm:items-baseline sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: item.aksi
								}),
								" ",
								item.entitas.toLowerCase(),
								" — ",
								item.detail
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-stone",
								children: item.actor
							})]
						}, item.id))
					})
				})
			})
		]
	});
}
var SplitComponent = DasborPage;
//#endregion
export { SplitComponent as component };
