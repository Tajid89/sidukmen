import { o as __toESM } from "../_runtime.mjs";
import { F as validatePenduduk, I as __exportAll, N as validasiKelompok, P as validateKeluarga, S as jejakBaru, _ as formatNomorSurat, h as can, n as lengkapi, s as DESA, t as dataContoh } from "./seed-DSw-2F5v.mjs";
import { C as useRouter, S as useNavigate, Z as require_react, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, p as HeadContent, v as lazyRouteComponent, w as require_jsx_runtime, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as TriangleAlert } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DBFAyprg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tarikSiduk = createServerFn({ method: "GET" }).handler(createSsrRpc("037ce7c7a8d9fc4c57383f73ba5947c3950550183aee7b7be9e7673fa72092ce"));
var simpanSiduk = createServerFn({ method: "POST" }).validator((input) => {
	if (!input?.payload || typeof input.revisi !== "number") throw new Error("Data tidak lengkap.");
	return input;
}).handler(createSsrRpc("2f5b0cf9dc13b362267bf3d07d305b8f3331f93e6c3b7d8928ca493273daf232"));
var SESI = "sidukmen-sesi";
function bacaSesi() {
	if (typeof sessionStorage === "undefined") return null;
	try {
		const raw = sessionStorage.getItem(SESI);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return parsed?.userId ? { userId: parsed.userId } : null;
	} catch {
		return null;
	}
}
function tulisSesi(session) {
	if (typeof sessionStorage === "undefined") return;
	if (!session) sessionStorage.removeItem(SESI);
	else sessionStorage.setItem(SESI, JSON.stringify(session));
}
function actorOf(state) {
	if (!state.session) return null;
	const user = state.users.find((u) => u.id === state.session?.userId);
	return user ? {
		nama: user.nama,
		role: user.role
	} : null;
}
function deny(state, ability) {
	const actor = actorOf(state);
	if (!actor) return "Sesi berakhir. Masuk kembali.";
	if (!can(actor.role, ability)) return "Peran Anda tidak dapat melakukan tindakan ini.";
	return null;
}
function withJejak(state, aksi, entitas, detail, actor) {
	return [jejakBaru(actor ?? actorOf(state)?.nama ?? "Sistem", aksi, entitas, detail), ...state.audit].slice(0, 400);
}
function blank() {
	return {
		...dataContoh(),
		session: null
	};
}
function syncAlamat(penduduk, keluarga) {
	return penduduk.map((p) => {
		const kk = keluarga.find((k) => k.noKk === p.noKk);
		return kk ? {
			...p,
			alamat: kk.alamat
		} : p;
	});
}
var useSiduk = create()((set, get) => ({
	...blank(),
	login: (username, password) => {
		const user = get().users.find((u) => u.username.toLowerCase() === username.trim().toLowerCase());
		if (!user || user.password !== password) return "Nama pengguna atau kata sandi tidak sesuai.";
		tulisSesi({ userId: user.id });
		set((s) => ({
			session: { userId: user.id },
			audit: withJejak(s, "Masuk", "Sesi", user.nama, user.nama)
		}));
		return null;
	},
	logout: () => {
		const nama = actorOf(get())?.nama;
		tulisSesi(null);
		set((s) => ({
			session: null,
			audit: nama ? withJejak(s, "Keluar", "Sesi", nama, nama) : s.audit
		}));
	},
	addPenduduk: (input) => {
		const state = get();
		const blocked = deny(state, "penduduk.write");
		if (blocked) return blocked;
		const err = validatePenduduk(input, state);
		if (err) return err;
		const row = {
			...input,
			nik: input.nik.trim(),
			nama: input.nama.trim(),
			noKk: input.noKk.trim(),
			tempatLahir: input.tempatLahir.trim(),
			namaAyah: input.namaAyah.trim(),
			namaIbu: input.namaIbu.trim(),
			alamat: state.keluarga.find((k) => k.noKk === input.noKk.trim())?.alamat ?? input.alamat,
			id: crypto.randomUUID(),
			statusHidup: "aktif",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({
			penduduk: [...s.penduduk, row],
			audit: withJejak(s, "Tambah", "Penduduk", `${row.nama} (${row.nik})`)
		}));
		return null;
	},
	updatePenduduk: (oldNik, input) => {
		const state = get();
		const blocked = deny(state, "penduduk.write");
		if (blocked) return blocked;
		const prev = state.penduduk.find((p) => p.nik === oldNik);
		if (!prev) return "Data penduduk tidak ditemukan.";
		const err = validatePenduduk(input, {
			...state,
			ignoreNik: oldNik
		});
		if (err) return err;
		const nik = input.nik.trim();
		const row = {
			...prev,
			...input,
			nik,
			nama: input.nama.trim(),
			noKk: input.noKk.trim(),
			tempatLahir: input.tempatLahir.trim(),
			namaAyah: input.namaAyah.trim(),
			namaIbu: input.namaIbu.trim(),
			alamat: state.keluarga.find((k) => k.noKk === input.noKk.trim())?.alamat ?? input.alamat
		};
		set((s) => ({
			penduduk: s.penduduk.map((p) => p.nik === oldNik ? row : p),
			mutasi: s.mutasi.map((m) => m.nik === oldNik ? {
				...m,
				nik,
				nama: row.nama,
				noKk: row.noKk
			} : m),
			surat: s.surat.map((sr) => sr.nik === oldNik ? {
				...sr,
				nik,
				nama: row.nama
			} : sr),
			audit: withJejak(s, "Ubah", "Penduduk", `${row.nama} (${row.nik})`)
		}));
		return null;
	},
	deletePenduduk: (nik) => {
		const state = get();
		const blocked = deny(state, "penduduk.write");
		if (blocked) return blocked;
		const prev = state.penduduk.find((p) => p.nik === nik);
		if (!prev) return "Data penduduk tidak ditemukan.";
		set((s) => ({
			penduduk: s.penduduk.filter((p) => p.nik !== nik),
			audit: withJejak(s, "Hapus", "Penduduk", `${prev.nama} (${prev.nik})`)
		}));
		return null;
	},
	aktifkan: (nik) => {
		const state = get();
		const blocked = deny(state, "mutasi.write");
		if (blocked) return blocked;
		const prev = state.penduduk.find((p) => p.nik === nik);
		if (!prev) return "Data penduduk tidak ditemukan.";
		if (prev.statusHidup === "aktif") return "Penduduk ini sudah berstatus aktif.";
		set((s) => ({
			penduduk: s.penduduk.map((p) => p.nik === nik ? {
				...p,
				statusHidup: "aktif"
			} : p),
			audit: withJejak(s, "Aktifkan", "Penduduk", `${prev.nama} dikembalikan ke penduduk aktif`)
		}));
		return null;
	},
	addKeluarga: (input) => {
		const state = get();
		const blocked = deny(state, "keluarga.write");
		if (blocked) return blocked;
		const err = validateKeluarga(input, state.keluarga);
		if (err) return err;
		const row = {
			id: crypto.randomUUID(),
			noKk: input.noKk.trim(),
			kepalaKeluarga: input.kepalaKeluarga.trim(),
			alamat: input.alamat.trim(),
			dusun: input.dusun.trim(),
			rt: input.rt.trim().padStart(2, "0"),
			rw: input.rw.trim().padStart(2, "0"),
			latitude: input.latitude,
			longitude: input.longitude,
			noListrik: input.noListrik.trim(),
			fotoKk: input.fotoKk,
			fotoDepan: input.fotoDepan,
			fotoDalam: input.fotoDalam,
			fotoKamarMandi: input.fotoKamarMandi,
			fotoLokasi: input.fotoLokasi,
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({
			keluarga: [...s.keluarga, row],
			audit: withJejak(s, "Tambah", "Keluarga", `${row.kepalaKeluarga} (${row.noKk})`)
		}));
		return null;
	},
	updateKeluarga: (oldNoKk, input) => {
		const state = get();
		const blocked = deny(state, "keluarga.write");
		if (blocked) return blocked;
		const prev = state.keluarga.find((k) => k.noKk === oldNoKk);
		if (!prev) return "Kartu keluarga tidak ditemukan.";
		const err = validateKeluarga(input, state.keluarga, oldNoKk);
		if (err) return err;
		const row = {
			...prev,
			noKk: input.noKk.trim(),
			kepalaKeluarga: input.kepalaKeluarga.trim(),
			alamat: input.alamat.trim(),
			dusun: input.dusun.trim(),
			rt: input.rt.trim().padStart(2, "0"),
			rw: input.rw.trim().padStart(2, "0"),
			latitude: input.latitude,
			longitude: input.longitude,
			noListrik: input.noListrik.trim(),
			fotoKk: input.fotoKk,
			fotoDepan: input.fotoDepan,
			fotoDalam: input.fotoDalam,
			fotoKamarMandi: input.fotoKamarMandi,
			fotoLokasi: input.fotoLokasi
		};
		set((s) => {
			const penduduk = syncAlamat(s.penduduk.map((p) => p.noKk === oldNoKk ? {
				...p,
				noKk: row.noKk
			} : p), s.keluarga.map((k) => k.noKk === oldNoKk ? row : k));
			return {
				keluarga: s.keluarga.map((k) => k.noKk === oldNoKk ? row : k),
				penduduk,
				mutasi: s.mutasi.map((m) => m.noKk === oldNoKk ? {
					...m,
					noKk: row.noKk
				} : m),
				audit: withJejak(s, "Ubah", "Keluarga", `${row.kepalaKeluarga} (${row.noKk})`)
			};
		});
		return null;
	},
	deleteKeluarga: (noKk) => {
		const state = get();
		const blocked = deny(state, "keluarga.write");
		if (blocked) return blocked;
		const prev = state.keluarga.find((k) => k.noKk === noKk);
		if (!prev) return "Kartu keluarga tidak ditemukan.";
		if (state.penduduk.some((p) => p.noKk === noKk)) return "Masih ada anggota. Pindahkan atau hapus anggota terlebih dahulu.";
		set((s) => ({
			keluarga: s.keluarga.filter((k) => k.noKk !== noKk),
			audit: withJejak(s, "Hapus", "Keluarga", `${prev.kepalaKeluarga} (${prev.noKk})`)
		}));
		return null;
	},
	addMaster: (kind, nama) => {
		const state = get();
		const blocked = deny(state, "master.write");
		if (blocked) return blocked;
		const clean = nama.trim();
		if (clean.length < 2) return "Nama terlalu pendek.";
		if (state[kind].some((item) => item.nama.toLowerCase() === clean.toLowerCase())) return "Nama ini sudah ada.";
		const row = {
			id: crypto.randomUUID(),
			nama: clean
		};
		set((s) => ({
			[kind]: [...s[kind], row],
			audit: withJejak(s, "Tambah", "Master", clean)
		}));
		return null;
	},
	renameMaster: (kind, id, nama) => {
		const state = get();
		const blocked = deny(state, "master.write");
		if (blocked) return blocked;
		const clean = nama.trim();
		if (clean.length < 2) return "Nama terlalu pendek.";
		if (!state[kind].some((item) => item.id === id)) return "Data tidak ditemukan.";
		if (state[kind].some((item) => item.id !== id && item.nama.toLowerCase() === clean.toLowerCase())) return "Nama ini sudah ada.";
		set((s) => ({
			[kind]: s[kind].map((item) => item.id === id ? {
				...item,
				nama: clean
			} : item),
			audit: withJejak(s, "Ubah", "Master", clean)
		}));
		return null;
	},
	deleteMaster: (kind, id) => {
		const state = get();
		const blocked = deny(state, "master.write");
		if (blocked) return blocked;
		const item = state[kind].find((row) => row.id === id);
		if (!item) return "Data tidak ditemukan.";
		if (state.penduduk.some((p) => kind === "pekerjaan" ? p.pekerjaanId === id : kind === "pendidikan" ? p.pendidikanId === id : p.statusId === id)) return "Masih dipakai data penduduk. Ubah penduduk tersebut lebih dulu.";
		set((s) => ({
			[kind]: s[kind].filter((row) => row.id !== id),
			audit: withJejak(s, "Hapus", "Master", item.nama)
		}));
		return null;
	},
	simpanKelompok: (rows) => {
		const blocked = deny(get(), "master.write");
		if (blocked) return blocked;
		const err = validasiKelompok(rows);
		if (err) return err;
		const bersih = [...rows].map((row) => ({
			...row,
			label: row.label.trim(),
			min: Number(row.min),
			max: Number(row.max)
		})).sort((a, b) => a.min - b.min);
		set((s) => ({
			kelompokUsia: bersih,
			audit: withJejak(s, "Ubah", "Kelompok umur", bersih.map((row) => `${row.label} (${row.min}–${row.max})`).join(", "))
		}));
		return null;
	},
	catatMeninggal: (nik, tanggal, keterangan) => catatKeluar(get, set, "meninggal", nik, tanggal, keterangan),
	catatPindahKeluar: (nik, tanggal, keterangan) => catatKeluar(get, set, "pindah_keluar", nik, tanggal, keterangan),
	catatLahir: (input) => {
		const state = get();
		const blocked = deny(state, "mutasi.write");
		if (blocked) return blocked;
		if (!/^\d{4}-\d{2}-\d{2}$/.test(input.tanggal)) return "Tanggal kejadian tidak valid.";
		if (input.keterangan.trim().length < 3) return "Keterangan belum diisi.";
		const kk = state.keluarga.find((k) => k.noKk === input.noKk);
		if (!kk) return "Kartu keluarga tidak ditemukan.";
		const anak = state.statusKeluarga.find((s) => s.nama === "Anak");
		const tidakKerja = state.pekerjaan.find((p) => p.nama === "Tidak Bekerja");
		const tidakSekolah = state.pendidikan.find((p) => p.nama === "Tidak Sekolah");
		if (!anak || !tidakKerja || !tidakSekolah) return "Master data anak, pekerjaan, atau pendidikan belum lengkap.";
		const ibu = state.penduduk.find((p) => p.noKk === kk.noKk && p.nama.toLowerCase() === input.namaIbu.trim().toLowerCase());
		const pendudukInput = {
			nik: input.nik.trim(),
			nama: input.nama.trim(),
			jenisKelamin: input.jenisKelamin,
			tempatLahir: input.tempatLahir.trim() || "Lamongan",
			tanggalLahir: input.tanggal,
			agama: ibu?.agama ?? "Islam",
			statusPerkawinan: "Belum Kawin",
			pekerjaanId: tidakKerja.id,
			pendidikanId: tidakSekolah.id,
			statusId: anak.id,
			noKk: kk.noKk,
			alamat: kk.alamat,
			namaAyah: input.namaAyah.trim(),
			namaIbu: input.namaIbu.trim()
		};
		const err = validatePenduduk(pendudukInput, state);
		if (err) return err;
		const row = {
			...pendudukInput,
			id: crypto.randomUUID(),
			statusHidup: "aktif",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		const mutasi = buatMutasi("lahir", row, input.tanggal, input.keterangan.trim(), actorOf(state)?.nama ?? "Sistem");
		set((s) => ({
			penduduk: [...s.penduduk, row],
			mutasi: [mutasi, ...s.mutasi],
			audit: withJejak(s, "Catat", "Mutasi", `Kelahiran ${row.nama}`)
		}));
		return null;
	},
	catatPindahMasuk: (input) => {
		const state = get();
		const blocked = deny(state, "mutasi.write");
		if (blocked) return blocked;
		if (!/^\d{4}-\d{2}-\d{2}$/.test(input.tanggal)) return "Tanggal kejadian tidak valid.";
		if (input.keterangan.trim().length < 3) return "Keterangan asal pindah belum diisi.";
		const err = validatePenduduk(input, state);
		if (err) return err;
		const kk = state.keluarga.find((k) => k.noKk === input.noKk.trim());
		const row = {
			...input,
			nik: input.nik.trim(),
			nama: input.nama.trim(),
			noKk: input.noKk.trim(),
			alamat: kk?.alamat ?? input.alamat,
			tempatLahir: input.tempatLahir.trim(),
			namaAyah: input.namaAyah.trim(),
			namaIbu: input.namaIbu.trim(),
			id: crypto.randomUUID(),
			statusHidup: "aktif",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		const mutasi = buatMutasi("pindah_masuk", row, input.tanggal, input.keterangan.trim(), actorOf(state)?.nama ?? "Sistem");
		set((s) => ({
			penduduk: [...s.penduduk, row],
			mutasi: [mutasi, ...s.mutasi],
			audit: withJejak(s, "Catat", "Mutasi", `Pindah masuk ${row.nama}`)
		}));
		return null;
	},
	terbitSurat: (jenis, nik, keperluan, tanggal) => {
		const state = get();
		const blocked = deny(state, "surat.write");
		if (blocked) return blocked;
		const orang = state.penduduk.find((p) => p.nik === nik);
		if (!orang) return "Penduduk tidak ditemukan.";
		if (keperluan.trim().length < 5) return "Keperluan surat belum cukup jelas.";
		if (!/^\d{4}-\d{2}-\d{2}$/.test(tanggal)) return "Tanggal surat tidak valid.";
		if (jenis === "kematian" && orang.statusHidup !== "meninggal") return "Surat kematian hanya untuk penduduk yang sudah dicatat meninggal.";
		if (jenis !== "kematian" && orang.statusHidup !== "aktif") return "Surat ini hanya untuk penduduk berstatus aktif.";
		const seq = state.suratSeq + 1;
		const surat = {
			id: crypto.randomUUID(),
			nomor: formatNomorSurat(seq, jenis, tanggal),
			jenis,
			nik: orang.nik,
			nama: orang.nama,
			keperluan: keperluan.trim(),
			tanggal,
			actor: actorOf(state)?.nama ?? "Sistem",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({
			suratSeq: seq,
			surat: [surat, ...s.surat],
			audit: withJejak(s, "Terbit", "Surat", `${surat.nomor} atas nama ${surat.nama}`)
		}));
		return `ok:${surat.id}`;
	},
	deleteSurat: (id) => {
		const state = get();
		const blocked = deny(state, "surat.write");
		if (blocked) return blocked;
		const prev = state.surat.find((s) => s.id === id);
		if (!prev) return "Surat tidak ditemukan.";
		set((s) => ({
			surat: s.surat.filter((item) => item.id !== id),
			audit: withJejak(s, "Hapus", "Surat", prev.nomor)
		}));
		return null;
	},
	addUser: (input) => {
		const state = get();
		const blocked = deny(state, "user.write");
		if (blocked) return blocked;
		const err = validUser(input, state.users);
		if (err) return err;
		const row = {
			...input,
			id: crypto.randomUUID(),
			username: input.username.trim().toLowerCase(),
			nama: input.nama.trim(),
			email: input.email.trim(),
			noHp: input.noHp.trim(),
			alamat: input.alamat.trim()
		};
		set((s) => ({
			users: [...s.users, row],
			audit: withJejak(s, "Tambah", "Pengguna", `${row.nama} (${row.username})`)
		}));
		return null;
	},
	updateUser: (id, input) => {
		const state = get();
		const blocked = deny(state, "user.write");
		if (blocked) return blocked;
		const prev = state.users.find((u) => u.id === id);
		if (!prev) return "Pengguna tidak ditemukan.";
		const next = {
			...prev,
			...input,
			username: input.username.trim().toLowerCase(),
			nama: input.nama.trim(),
			email: input.email.trim(),
			password: input.password?.trim() ? input.password : prev.password
		};
		const err = validUser(next, state.users, id);
		if (err) return err;
		if (prev.role === "admin" && next.role !== "admin" && state.users.filter((u) => u.role === "admin").length < 2) return "Harus tersisa sedikitnya satu admin.";
		set((s) => ({
			users: s.users.map((u) => u.id === id ? next : u),
			audit: withJejak(s, "Ubah", "Pengguna", next.nama)
		}));
		return null;
	},
	deleteUser: (id) => {
		const state = get();
		const blocked = deny(state, "user.write");
		if (blocked) return blocked;
		if (state.session?.userId === id) return "Anda tidak dapat menghapus akun yang sedang dipakai.";
		const prev = state.users.find((u) => u.id === id);
		if (!prev) return "Pengguna tidak ditemukan.";
		if (prev.role === "admin" && state.users.filter((u) => u.role === "admin").length < 2) return "Admin terakhir tidak boleh dihapus.";
		set((s) => ({
			users: s.users.filter((u) => u.id !== id),
			audit: withJejak(s, "Hapus", "Pengguna", prev.nama)
		}));
		return null;
	},
	updateProfile: (input) => {
		const state = get();
		const id = state.session?.userId;
		if (!state.users.find((u) => u.id === id)) return "Sesi berakhir.";
		if (input.nama.trim().length < 3) return "Nama belum lengkap.";
		set((s) => ({
			users: s.users.map((u) => u.id === id ? {
				...u,
				nama: input.nama.trim(),
				email: input.email.trim(),
				noHp: input.noHp.trim(),
				alamat: input.alamat.trim()
			} : u),
			audit: withJejak(s, "Ubah", "Profil", input.nama.trim())
		}));
		return null;
	},
	changePassword: (lama, baru) => {
		const state = get();
		const id = state.session?.userId;
		const prev = state.users.find((u) => u.id === id);
		if (!prev) return "Sesi berakhir.";
		if (prev.password !== lama) return "Kata sandi lama tidak sesuai.";
		if (baru.trim().length < 6) return "Kata sandi baru minimal 6 karakter.";
		set((s) => ({
			users: s.users.map((u) => u.id === id ? {
				...u,
				password: baru
			} : u),
			audit: withJejak(s, "Ubah", "Profil", "Kata sandi diperbarui")
		}));
		return null;
	},
	importPenduduk: (rows) => {
		const state = get();
		const blocked = deny(state, "penduduk.write");
		if (blocked) return blocked;
		if (!rows.length) return "Tidak ada baris yang sah untuk diimpor.";
		const dibuat = rows.map((input) => ({
			...input,
			nik: input.nik.trim(),
			nama: input.nama.trim(),
			noKk: input.noKk.trim(),
			alamat: state.keluarga.find((k) => k.noKk === input.noKk)?.alamat ?? input.alamat,
			id: crypto.randomUUID(),
			statusHidup: "aktif",
			createdAt: (/* @__PURE__ */ new Date()).toISOString()
		}));
		set((s) => ({
			penduduk: [...s.penduduk, ...dibuat],
			audit: withJejak(s, "Impor", "Penduduk", `${dibuat.length} jiwa dari CSV`)
		}));
		return null;
	},
	restore: (data) => {
		const state = get();
		const blocked = deny(state, "backup.restore");
		if (blocked) return blocked;
		const sessionUser = state.users.find((u) => u.id === state.session?.userId);
		const nextSession = data.users.find((u) => u.username === sessionUser?.username);
		const nama = sessionUser?.nama ?? "Sistem";
		set({
			...data,
			session: nextSession ? { userId: nextSession.id } : null,
			audit: [jejakBaru(nama, "Pulihkan", "Cadangan", "Data desa dipulihkan dari berkas"), ...data.audit].slice(0, 400)
		});
		return null;
	},
	resetContoh: () => {
		const state = get();
		const blocked = deny(state, "backup.restore");
		if (blocked) return blocked;
		const fresh = dataContoh();
		const nama = actorOf(state)?.nama;
		const user = fresh.users.find((u) => u.nama === nama) ?? fresh.users[0];
		set({
			...fresh,
			session: user ? { userId: user.id } : null,
			audit: [jejakBaru(user?.nama ?? "Sistem", "Reset", "Cadangan", "Data contoh dimuat ulang"), ...fresh.audit]
		});
		return null;
	}
}));
function buatMutasi(jenis, orang, tanggal, keterangan, actor) {
	return {
		id: crypto.randomUUID(),
		jenis,
		nik: orang.nik,
		nama: orang.nama,
		tanggal,
		keterangan,
		noKk: orang.noKk,
		actor,
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function catatKeluar(get, set, jenis, nik, tanggal, keterangan) {
	const state = get();
	const blocked = deny(state, "mutasi.write");
	if (blocked) return blocked;
	const orang = state.penduduk.find((p) => p.nik === nik);
	if (!orang) return "Penduduk tidak ditemukan.";
	if (orang.statusHidup !== "aktif") return "Hanya penduduk aktif yang dapat dicatat mutasinya.";
	if (!/^\d{4}-\d{2}-\d{2}$/.test(tanggal)) return "Tanggal kejadian tidak valid.";
	if (tanggal < orang.tanggalLahir) return "Tanggal kejadian tidak boleh sebelum tanggal lahir.";
	if (keterangan.trim().length < 3) return "Keterangan belum diisi.";
	const hidup = jenis === "meninggal" ? "meninggal" : "pindah";
	const mutasi = buatMutasi(jenis, orang, tanggal, keterangan.trim(), actorOf(state)?.nama ?? "Sistem");
	set((s) => ({
		penduduk: s.penduduk.map((p) => p.nik === nik ? {
			...p,
			statusHidup: hidup
		} : p),
		mutasi: [mutasi, ...s.mutasi],
		audit: withJejak(s, "Catat", "Mutasi", `${jenis === "meninggal" ? "Kematian" : "Pindah keluar"} ${orang.nama}`)
	}));
	return null;
}
function validUser(input, users, ignoreId) {
	if (!/^[a-z0-9._]{3,20}$/i.test(input.username.trim())) return "Nama pengguna 3–20 karakter, huruf atau angka.";
	if (input.nama.trim().length < 3) return "Nama lengkap belum cukup.";
	if (input.password.trim().length < 6) return "Kata sandi minimal 6 karakter.";
	if (users.some((u) => u.username.toLowerCase() === input.username.trim().toLowerCase() && u.id !== ignoreId)) return "Nama pengguna sudah dipakai.";
	if (![
		"admin",
		"petugas",
		"kepala_desa"
	].includes(input.role)) return "Peran tidak dikenal.";
	return null;
}
function useUser() {
	return useSiduk((s) => s.users.find((u) => u.id === s.session?.userId) ?? null);
}
function potong(state) {
	return {
		users: state.users,
		pekerjaan: state.pekerjaan,
		pendidikan: state.pendidikan,
		statusKeluarga: state.statusKeluarga,
		keluarga: state.keluarga,
		penduduk: state.penduduk,
		mutasi: state.mutasi,
		surat: state.surat,
		audit: state.audit,
		suratSeq: state.suratSeq,
		kelompokUsia: state.kelompokUsia
	};
}
function bedaData(a, b) {
	return a.users !== b.users || a.pekerjaan !== b.pekerjaan || a.pendidikan !== b.pendidikan || a.statusKeluarga !== b.statusKeluarga || a.keluarga !== b.keluarga || a.penduduk !== b.penduduk || a.mutasi !== b.mutasi || a.surat !== b.surat || a.audit !== b.audit || a.suratSeq !== b.suratSeq || a.kelompokUsia !== b.kelompokUsia;
}
function ClientGate({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [gagal, setGagal] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let batal = false;
		let revisi = 0;
		let diam = true;
		let sedang = false;
		let antri = false;
		let timer = 0;
		async function dorong() {
			if (sedang) {
				antri = true;
				return;
			}
			sedang = true;
			const payload = potong(useSiduk.getState());
			const punya = revisi;
			try {
				const hasil = await simpanSiduk({ data: {
					payload,
					revisi: punya
				} });
				if (batal) return;
				if (hasil.ok) revisi = hasil.revisi;
				else {
					revisi = hasil.revisi;
					const sesi = useSiduk.getState().session;
					diam = true;
					useSiduk.setState({
						...lengkapi(hasil.payload),
						session: sesi
					});
					diam = false;
					toast.message("Data di server lebih baru. Tampilan diselaraskan.");
				}
			} catch {
				if (!batal) toast.error("Gagal menyimpan ke database server.");
			} finally {
				sedang = false;
				if (antri && !batal) {
					antri = false;
					dorong();
				}
			}
		}
		const lepas = useSiduk.subscribe((state, prev) => {
			if (diam || !bedaData(state, prev)) return;
			window.clearTimeout(timer);
			timer = window.setTimeout(() => void dorong(), 350);
		});
		tarikSiduk().then((dokumen) => {
			if (batal) return;
			revisi = dokumen.revisi;
			const data = lengkapi(dokumen.payload);
			const sesi = bacaSesi();
			const session = sesi && data.users.some((user) => user.id === sesi.userId) ? sesi : null;
			if (!session) tulisSesi(null);
			diam = true;
			useSiduk.setState({
				...data,
				session
			});
			diam = false;
			setReady(true);
		}).catch(() => {
			if (!batal) setGagal("Database server belum siap. Muat ulang halaman.");
		});
		return () => {
			batal = true;
			lepas();
			window.clearTimeout(timer);
		};
	}, []);
	if (gagal) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl text-brand",
			children: "SIDUKMEN"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-sm text-sm text-stone",
			children: gagal
		})]
	});
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl text-brand",
			children: "SIDUKMEN"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-stone",
			children: [
				"Menghubungkan database Desa ",
				DESA.nama,
				"…"
			]
		})]
	});
	return children ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
function useSessionUser() {
	const user = useUser();
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (!user) navigate({ to: "/" });
	}, [user, navigate]);
	return user;
}
var styles_default = "/assets/styles-Br19kJfl.css";
var Route$14 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "SIDUKMEN — Kependudukan Desa Monongo" },
			{
				name: "description",
				content: "Sistem data kependudukan Desa Monongo, Kecamatan Sukodadi, Kabupaten Lamongan."
			},
			{
				name: "theme-color",
				content: "#12343E"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&display=swap"
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "id",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientGate, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, { position: "top-center" })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$13 = () => import("./routes-BNaRknth.mjs");
var Route$13 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./dasbor-Dv3Guls2.mjs");
var Route$12 = createFileRoute("/dasbor")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./jejak-Ji9zXxoZ.mjs");
var Route$11 = createFileRoute("/jejak")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./laporan-CMG7Wsn8.mjs");
var Route$10 = createFileRoute("/laporan")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./master-9ug1dinj.mjs");
var Route$9 = createFileRoute("/master")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./mutasi-ZzT4l2H6.mjs");
var Route$8 = createFileRoute("/mutasi")({
	validateSearch: (search) => ({
		...typeof search.nik === "string" && search.nik ? { nik: search.nik } : {},
		...typeof search.jenis === "string" && search.jenis ? { jenis: search.jenis } : {}
	}),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./pengguna-C3VQ7okU.mjs");
var Route$7 = createFileRoute("/pengguna")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./profil-CdUVN-np.mjs");
var Route$6 = createFileRoute("/profil")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./keluarga-DxDmz3HH.mjs");
var Route$5 = createFileRoute("/keluarga/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("../_noKk-4Rv6JkPa.mjs");
var Route$4 = createFileRoute("/keluarga/$noKk")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./baru-kzB6WQSV.mjs");
var Route$3 = createFileRoute("/keluarga/baru")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./penduduk-D0LYTuzr.mjs");
var Route$2 = createFileRoute("/penduduk/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("../_nik-C_fWsYIw.mjs");
var Route$1 = createFileRoute("/penduduk/$nik")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./baru-De-JaUxL.mjs");
var Route = createFileRoute("/penduduk/baru")({
	validateSearch: (search) => typeof search.kk === "string" && search.kk ? { kk: search.kk } : {},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var DasborRoute = Route$12.update({
	id: "/dasbor",
	path: "/dasbor",
	getParentRoute: () => Route$14
});
var JejakRoute = Route$11.update({
	id: "/jejak",
	path: "/jejak",
	getParentRoute: () => Route$14
});
var LaporanRoute = Route$10.update({
	id: "/laporan",
	path: "/laporan",
	getParentRoute: () => Route$14
});
var MasterRoute = Route$9.update({
	id: "/master",
	path: "/master",
	getParentRoute: () => Route$14
});
var MutasiRoute = Route$8.update({
	id: "/mutasi",
	path: "/mutasi",
	getParentRoute: () => Route$14
});
var PenggunaRoute = Route$7.update({
	id: "/pengguna",
	path: "/pengguna",
	getParentRoute: () => Route$14
});
var ProfilRoute = Route$6.update({
	id: "/profil",
	path: "/profil",
	getParentRoute: () => Route$14
});
var KeluargaIndexRoute = Route$5.update({
	id: "/keluarga/",
	path: "/keluarga/",
	getParentRoute: () => Route$14
});
var KeluargaNoKkRoute = Route$4.update({
	id: "/keluarga/$noKk",
	path: "/keluarga/$noKk",
	getParentRoute: () => Route$14
});
var KeluargaBaruRoute = Route$3.update({
	id: "/keluarga/baru",
	path: "/keluarga/baru",
	getParentRoute: () => Route$14
});
var PendudukIndexRoute = Route$2.update({
	id: "/penduduk/",
	path: "/penduduk/",
	getParentRoute: () => Route$14
});
var rootRouteChildren = {
	IndexRoute,
	DasborRoute,
	JejakRoute,
	LaporanRoute,
	MasterRoute,
	MutasiRoute,
	PenggunaRoute,
	ProfilRoute,
	KeluargaNoKkRoute,
	KeluargaBaruRoute,
	PendudukNikRoute: Route$1.update({
		id: "/penduduk/$nik",
		path: "/penduduk/$nik",
		getParentRoute: () => Route$14
	}),
	PendudukBaruRoute: Route.update({
		id: "/penduduk/baru",
		path: "/penduduk/baru",
		getParentRoute: () => Route$14
	}),
	KeluargaIndexRoute,
	PendudukIndexRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Route$8 as a, useUser as c, Route$4 as i, Route as n, useSessionUser as o, Route$1 as r, useSiduk as s, router_exports as t };
