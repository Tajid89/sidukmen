import { o as __toESM } from "../_runtime.mjs";
import { h as can, l as ROLE_LABEL, s as DESA } from "./seed-DSw-2F5v.mjs";
import { S as useNavigate, Z as require_react, m as useRouterState, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as House, g as ChartColumn, h as CircleUser, l as LogOut, m as Database, n as Users, o as Search, p as History, r as UserCog, s as Menu, t as X, u as LayoutDashboard, v as ArrowLeftRight } from "../_libs/lucide-react.mjs";
import { s as useSiduk } from "./router-DBFAyprg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-BOWreftS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NAV = [
	{
		to: "/dasbor",
		label: "Dasbor",
		icon: LayoutDashboard,
		exact: true
	},
	{
		to: "/penduduk",
		label: "Penduduk",
		icon: Users
	},
	{
		to: "/keluarga",
		label: "Keluarga",
		icon: House
	},
	{
		to: "/mutasi",
		label: "Mutasi",
		icon: ArrowLeftRight
	},
	{
		to: "/laporan",
		label: "Laporan",
		icon: ChartColumn
	},
	{
		to: "/master",
		label: "Master data",
		icon: Database,
		ability: "master.write"
	},
	{
		to: "/pengguna",
		label: "Pengguna",
		icon: UserCog,
		ability: "user.write"
	},
	{
		to: "/jejak",
		label: "Jejak perubahan",
		icon: History
	},
	{
		to: "/profil",
		label: "Profil",
		icon: CircleUser
	}
];
function Shell({ title, user, action, children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const penduduk = useSiduk((s) => s.penduduk);
	const logout = useSiduk((s) => s.logout);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	const hits = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (q.length < 2) return [];
		return penduduk.filter((p) => p.nama.toLowerCase().includes(q) || p.nik.includes(q)).slice(0, 6);
	}, [penduduk, query]);
	const items = NAV.filter((item) => !item.ability || can(user.role, item.ability));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen md:grid md:grid-cols-[16.5rem_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "no-print hidden border-r border-line bg-sheet text-ink md:flex md:flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						items,
						pathname
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Account, {
						user,
						onLogout: () => logout()
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "absolute inset-0 bg-ink/40",
					"aria-label": "Tutup menu",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex h-full w-[18rem] max-w-[86vw] flex-col border-r border-line bg-sheet text-ink",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between pr-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center",
								onClick: () => setOpen(false),
								"aria-label": "Tutup",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
							items,
							pathname
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Account, {
							user,
							onLogout: () => logout()
						})
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "no-print sticky top-0 z-30 border-b border-line bg-paper/95 px-4 py-3 backdrop-blur md:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "grid size-11 place-items-center rounded-lg border border-line bg-sheet md:hidden",
									onClick: () => setOpen(true),
									"aria-label": "Buka menu",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold tracking-wide text-stone uppercase",
										children: ["Desa ", DESA.nama]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "truncate font-display text-2xl text-ink",
										children: title
									})]
								}),
								action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden sm:block",
									children: action
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-stone" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Cari nama atau NIK",
									className: "h-11 w-full rounded-lg border border-line bg-sheet pr-3 pl-10 text-base outline-none focus:border-brand",
									"aria-label": "Cari penduduk"
								}),
								query.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute right-0 left-0 z-20 mt-1 overflow-hidden rounded-lg border border-line bg-sheet shadow-sm",
									children: hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-3 py-3 text-sm text-stone",
										children: "Tidak ada penduduk yang cocok."
									}) : hits.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "block w-full px-3 py-3 text-left hover:bg-paper",
										onClick: () => {
											setQuery("");
											navigate({
												to: "/penduduk/$nik",
												params: { nik: p.nik }
											});
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-semibold",
											children: p.nama
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-stone tabular-nums",
											children: p.nik
										})]
									}, p.nik))
								}) : null
							]
						}),
						action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 sm:hidden",
							children: action
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "px-4 py-5 md:px-8 md:py-7",
					children
				})]
			})
		]
	});
}
function Brand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl font-semibold tracking-tight",
			children: "SIDUKMEN"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-stone",
			children: ["Kependudukan Desa ", DESA.nama]
		})]
	});
}
function Nav({ items, pathname }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex-1 space-y-1 overflow-auto px-3",
		children: items.map((item) => {
			const active = item.exact ? pathname === item.to : pathname === item.to || pathname.startsWith(`${item.to}/`);
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				className: `flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-semibold ${active ? "bg-brand text-white" : "text-ink hover:bg-paper"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), item.label]
			}, item.to);
		})
	});
}
function Account({ user, onLogout }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-line px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm font-semibold",
				children: user.nama
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-stone",
				children: ROLE_LABEL[user.role]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-3 flex min-h-11 items-center gap-2 text-sm font-semibold",
				onClick: onLogout,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "Keluar"]
			})
		]
	});
}
//#endregion
export { Shell as t };
