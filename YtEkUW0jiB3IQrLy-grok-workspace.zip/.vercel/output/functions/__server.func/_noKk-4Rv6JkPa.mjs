import { w as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as Route$4 } from "./_ssr/router-DBFAyprg.mjs";
import { n as KeluargaDetailPage } from "./_ssr/keluarga-CJUAbv20.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_noKk-4Rv6JkPa.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function KeluargaDetailRoute() {
	const { noKk } = Route$4.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeluargaDetailPage, { noKk });
};
//#endregion
export { SplitComponent as component };
