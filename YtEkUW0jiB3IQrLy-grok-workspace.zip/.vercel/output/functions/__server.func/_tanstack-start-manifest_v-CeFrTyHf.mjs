//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CeFrTyHf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/dasbor",
			"/jejak",
			"/laporan",
			"/master",
			"/mutasi",
			"/pengguna",
			"/profil",
			"/keluarga/$noKk",
			"/keluarga/baru",
			"/penduduk/$nik",
			"/penduduk/baru",
			"/keluarga/",
			"/penduduk/"
		],
		preloads: [
			"/assets/index-B6Y0s0m0.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/store-CL8bW9ca.js",
			"/assets/gate-IpOn8gaB.js",
			"/assets/preload-helper-p3-ptnuu.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B6Y0s0m0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DKR3_KWx.js", "/assets/bits-1kaVjTdq.js"]
	},
	"/dasbor": {
		filePath: "/workspace/src/routes/dasbor.tsx",
		children: void 0,
		preloads: [
			"/assets/dasbor-CRivJtiM.js",
			"/assets/shell-DqPpU5U9.js",
			"/assets/bits-1kaVjTdq.js"
		]
	},
	"/jejak": {
		filePath: "/workspace/src/routes/jejak.tsx",
		children: void 0,
		preloads: ["/assets/jejak-BmS-ReUF.js", "/assets/kelola-BZN4gbTK.js"]
	},
	"/laporan": {
		filePath: "/workspace/src/routes/laporan.tsx",
		children: void 0,
		preloads: ["/assets/laporan-DqIXmxmj.js", "/assets/kelola-BZN4gbTK.js"]
	},
	"/master": {
		filePath: "/workspace/src/routes/master.tsx",
		children: void 0,
		preloads: ["/assets/master-CCSWfEVe.js", "/assets/kelola-BZN4gbTK.js"]
	},
	"/mutasi": {
		filePath: "/workspace/src/routes/mutasi.tsx",
		children: void 0,
		preloads: [
			"/assets/mutasi-BcnEcJ_z.js",
			"/assets/shell-DqPpU5U9.js",
			"/assets/bits-1kaVjTdq.js"
		]
	},
	"/pengguna": {
		filePath: "/workspace/src/routes/pengguna.tsx",
		children: void 0,
		preloads: ["/assets/pengguna-CQtmmRTO.js", "/assets/kelola-BZN4gbTK.js"]
	},
	"/profil": {
		filePath: "/workspace/src/routes/profil.tsx",
		children: void 0,
		preloads: ["/assets/profil-CnTmq02V.js", "/assets/kelola-BZN4gbTK.js"]
	},
	"/keluarga/$noKk": {
		filePath: "/workspace/src/routes/keluarga/$noKk.tsx",
		children: void 0,
		preloads: ["/assets/_noKk-EfFfQNIy.js", "/assets/keluarga-hag5AC1u.js"]
	},
	"/keluarga/baru": {
		filePath: "/workspace/src/routes/keluarga/baru.tsx",
		children: void 0,
		preloads: ["/assets/baru-B8R1twEI.js", "/assets/keluarga-hag5AC1u.js"]
	},
	"/penduduk/$nik": {
		filePath: "/workspace/src/routes/penduduk/$nik.tsx",
		children: void 0,
		preloads: ["/assets/_nik-Nwg0vd7M.js", "/assets/penduduk-1HJ_PfN8.js"]
	},
	"/penduduk/baru": {
		filePath: "/workspace/src/routes/penduduk/baru.tsx",
		children: void 0,
		preloads: ["/assets/baru-CsX3_S5y.js", "/assets/penduduk-1HJ_PfN8.js"]
	},
	"/keluarga/": {
		filePath: "/workspace/src/routes/keluarga/index.tsx",
		children: void 0,
		preloads: ["/assets/keluarga-BC4IPH3o.js", "/assets/keluarga-hag5AC1u.js"]
	},
	"/penduduk/": {
		filePath: "/workspace/src/routes/penduduk/index.tsx",
		children: void 0,
		preloads: ["/assets/penduduk-BvXnI-3R.js", "/assets/penduduk-1HJ_PfN8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
