import { w as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./_ssr/router-DBFAyprg.mjs";
import { n as PendudukDetailPage } from "./_ssr/penduduk-TltSk4Qb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_nik-C_fWsYIw.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function PendudukDetailRoute() {
	const { nik } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendudukDetailPage, { nik });
};
//#endregion
export { SplitComponent as component };
