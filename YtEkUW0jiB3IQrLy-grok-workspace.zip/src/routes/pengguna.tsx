import { createFileRoute } from "@tanstack/react-router";
import { PenggunaPage } from "@/components/sidukmen/pages/kelola";

export const Route = createFileRoute("/pengguna")({ component: PenggunaPage });
