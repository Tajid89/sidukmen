import { createFileRoute } from "@tanstack/react-router";
import { MasukPage } from "@/components/sidukmen/pages/masuk";

export const Route = createFileRoute("/")({ component: MasukPage });
