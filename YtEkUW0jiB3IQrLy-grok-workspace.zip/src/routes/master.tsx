import { createFileRoute } from "@tanstack/react-router";
import { MasterPage } from "@/components/sidukmen/pages/kelola";

export const Route = createFileRoute("/master")({ component: MasterPage });
