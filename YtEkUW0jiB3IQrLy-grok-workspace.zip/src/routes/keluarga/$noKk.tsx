import { createFileRoute } from "@tanstack/react-router";
import { KeluargaDetailPage } from "@/components/sidukmen/pages/keluarga";

export const Route = createFileRoute("/keluarga/$noKk")({
  component: function KeluargaDetailRoute() {
    const { noKk } = Route.useParams();
    return <KeluargaDetailPage noKk={noKk} />;
  },
});
