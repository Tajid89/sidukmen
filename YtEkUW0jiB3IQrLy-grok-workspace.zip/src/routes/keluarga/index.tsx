import { createFileRoute } from "@tanstack/react-router";
import { KeluargaListPage } from "@/components/sidukmen/pages/keluarga";

export const Route = createFileRoute("/keluarga/")({ component: KeluargaListPage });
