import { createFileRoute } from "@tanstack/react-router";
import { KeluargaBaruPage } from "@/components/sidukmen/pages/keluarga";

export const Route = createFileRoute("/keluarga/baru")({ component: KeluargaBaruPage });
