import { createFileRoute } from "@tanstack/react-router";
import { DasborPage } from "@/components/sidukmen/pages/dasbor";

export const Route = createFileRoute("/dasbor")({ component: DasborPage });
