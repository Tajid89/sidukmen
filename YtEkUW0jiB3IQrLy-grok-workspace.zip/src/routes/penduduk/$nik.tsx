import { createFileRoute } from "@tanstack/react-router";
import { PendudukDetailPage } from "@/components/sidukmen/pages/penduduk";

export const Route = createFileRoute("/penduduk/$nik")({
  component: function PendudukDetailRoute() {
    const { nik } = Route.useParams();
    return <PendudukDetailPage nik={nik} />;
  },
});
