import { createFileRoute } from "@tanstack/react-router";
import { PendudukBaruPage } from "@/components/sidukmen/pages/penduduk";

type Cari = { kk?: string };

export const Route = createFileRoute("/penduduk/baru")({
  validateSearch: (search: Record<string, unknown>): Cari =>
    typeof search.kk === "string" && search.kk ? { kk: search.kk } : {},
  component: function PendudukBaruRoute() {
    const { kk } = Route.useSearch();
    return <PendudukBaruPage noKk={kk ?? ""} />;
  },
});
