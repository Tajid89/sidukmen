import { createFileRoute } from "@tanstack/react-router";
import { PendudukListPage } from "@/components/sidukmen/pages/penduduk";

export const Route = createFileRoute("/penduduk/")({ component: PendudukListPage });
