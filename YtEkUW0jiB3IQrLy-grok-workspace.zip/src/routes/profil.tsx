import { createFileRoute } from "@tanstack/react-router";
import { ProfilPage } from "@/components/sidukmen/pages/kelola";

export const Route = createFileRoute("/profil")({ component: ProfilPage });
