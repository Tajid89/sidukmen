import { createFileRoute } from "@tanstack/react-router";
import { JejakPage } from "@/components/sidukmen/pages/kelola";

export const Route = createFileRoute("/jejak")({ component: JejakPage });
