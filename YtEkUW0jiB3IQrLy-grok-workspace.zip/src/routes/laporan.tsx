import { createFileRoute } from "@tanstack/react-router";
import { LaporanPage } from "@/components/sidukmen/pages/kelola";

export const Route = createFileRoute("/laporan")({ component: LaporanPage });
