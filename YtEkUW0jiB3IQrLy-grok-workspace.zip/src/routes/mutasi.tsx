import { createFileRoute } from "@tanstack/react-router";
import { MutasiPage } from "@/components/sidukmen/pages/mutasi";

type Cari = { nik?: string; jenis?: string };

export const Route = createFileRoute("/mutasi")({
  validateSearch: (search: Record<string, unknown>): Cari => ({
    ...(typeof search.nik === "string" && search.nik ? { nik: search.nik } : {}),
    ...(typeof search.jenis === "string" && search.jenis ? { jenis: search.jenis } : {}),
  }),
  component: function MutasiRoute() {
    const { nik, jenis } = Route.useSearch();
    return <MutasiPage presetNik={nik ?? ""} presetJenis={jenis ?? ""} />;
  },
});
