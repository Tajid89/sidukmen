import { create } from "zustand";
import {
  formatNomorSurat,
  jejakBaru,
  validateKeluarga,
  validatePenduduk,
  validasiKelompok,
  can,
} from "./logic";
import { dataContoh, type DataSlice } from "./seed";
import type {
  Ability,
  KelompokUsia,
  Keluarga,
  KeluargaInput,
  Master,
  Mutasi,
  Penduduk,
  PendudukInput,
  Role,
  Session,
  Surat,
  JenisSurat,
  User,
} from "./types";

export type LahirInput = {
  noKk: string;
  nik: string;
  nama: string;
  jenisKelamin: "L" | "P";
  tanggal: string;
  tempatLahir: string;
  namaAyah: string;
  namaIbu: string;
  keterangan: string;
};

export type PindahMasukInput = PendudukInput & { tanggal: string; keterangan: string };

type Snapshot = DataSlice & { session: Session | null };

const SESI = "sidukmen-sesi";

export function bacaSesi(): Session | null {
  if (typeof sessionStorage === "undefined") return null;
  try {
    const raw = sessionStorage.getItem(SESI);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Session;
    return parsed?.userId ? { userId: parsed.userId } : null;
  } catch {
    return null;
  }
}

export function tulisSesi(session: Session | null) {
  if (typeof sessionStorage === "undefined") return;
  if (!session) sessionStorage.removeItem(SESI);
  else sessionStorage.setItem(SESI, JSON.stringify(session));
}

function actorOf(state: Snapshot): { nama: string; role: Role } | null {
  if (!state.session) return null;
  const user = state.users.find((u) => u.id === state.session?.userId);
  return user ? { nama: user.nama, role: user.role } : null;
}

function deny(state: Snapshot, ability: Ability): string | null {
  const actor = actorOf(state);
  if (!actor) return "Sesi berakhir. Masuk kembali.";
  if (!can(actor.role, ability)) return "Peran Anda tidak dapat melakukan tindakan ini.";
  return null;
}

function withJejak(state: Snapshot, aksi: string, entitas: string, detail: string, actor?: string) {
  return [jejakBaru(actor ?? actorOf(state)?.nama ?? "Sistem", aksi, entitas, detail), ...state.audit].slice(0, 400);
}

function blank(): Snapshot {
  return { ...dataContoh(), session: null };
}

type Actions = {
  login: (username: string, password: string) => string | null;
  logout: () => void;
  addPenduduk: (input: PendudukInput) => string | null;
  updatePenduduk: (oldNik: string, input: PendudukInput) => string | null;
  deletePenduduk: (nik: string) => string | null;
  aktifkan: (nik: string) => string | null;
  addKeluarga: (input: KeluargaInput) => string | null;
  updateKeluarga: (oldNoKk: string, input: KeluargaInput) => string | null;
  deleteKeluarga: (noKk: string) => string | null;
  addMaster: (kind: "pekerjaan" | "pendidikan" | "statusKeluarga", nama: string) => string | null;
  renameMaster: (kind: "pekerjaan" | "pendidikan" | "statusKeluarga", id: string, nama: string) => string | null;
  deleteMaster: (kind: "pekerjaan" | "pendidikan" | "statusKeluarga", id: string) => string | null;
  simpanKelompok: (rows: KelompokUsia[]) => string | null;
  catatMeninggal: (nik: string, tanggal: string, keterangan: string) => string | null;
  catatPindahKeluar: (nik: string, tanggal: string, keterangan: string) => string | null;
  catatLahir: (input: LahirInput) => string | null;
  catatPindahMasuk: (input: PindahMasukInput) => string | null;
  terbitSurat: (jenis: JenisSurat, nik: string, keperluan: string, tanggal: string) => string | null;
  deleteSurat: (id: string) => string | null;
  addUser: (input: Omit<User, "id">) => string | null;
  updateUser: (id: string, input: Omit<User, "id" | "password"> & { password?: string }) => string | null;
  deleteUser: (id: string) => string | null;
  updateProfile: (input: { nama: string; email: string; noHp: string; alamat: string }) => string | null;
  changePassword: (lama: string, baru: string) => string | null;
  importPenduduk: (rows: PendudukInput[]) => string | null;
  restore: (data: DataSlice) => string | null;
  resetContoh: () => string | null;
};

export type SidukState = Snapshot & Actions;

function syncAlamat(penduduk: Penduduk[], keluarga: Keluarga[]): Penduduk[] {
  return penduduk.map((p) => {
    const kk = keluarga.find((k) => k.noKk === p.noKk);
    return kk ? { ...p, alamat: kk.alamat } : p;
  });
}

export const useSiduk = create<SidukState>()((set, get) => ({
      ...blank(),
      login: (username, password) => {
        const user = get().users.find((u) => u.username.toLowerCase() === username.trim().toLowerCase());
        if (!user || user.password !== password) return "Nama pengguna atau kata sandi tidak sesuai.";
        tulisSesi({ userId: user.id });
        set((s) => ({
          session: { userId: user.id },
          audit: withJejak(s, "Masuk", "Sesi", user.nama, user.nama),
        }));
        return null;
      },
      logout: () => {
        const nama = actorOf(get())?.nama;
        tulisSesi(null);
        set((s) => ({
          session: null,
          audit: nama ? withJejak(s, "Keluar", "Sesi", nama, nama) : s.audit,
        }));
      },
      addPenduduk: (input) => {
        const state = get();
        const blocked = deny(state, "penduduk.write");
        if (blocked) return blocked;
        const err = validatePenduduk(input, state);
        if (err) return err;
        const row: Penduduk = {
          ...input,
          nik: input.nik.trim(),
          nama: input.nama.trim(),
          noKk: input.noKk.trim(),
          tempatLahir: input.tempatLahir.trim(),
          namaAyah: input.namaAyah.trim(),
          namaIbu: input.namaIbu.trim(),
          alamat: state.keluarga.find((k) => k.noKk === input.noKk.trim())?.alamat ?? input.alamat,
          id: crypto.randomUUID(),
          statusHidup: "aktif",
          createdAt: new Date().toISOString(),
        };
        set((s) => ({
          penduduk: [...s.penduduk, row],
          audit: withJejak(s, "Tambah", "Penduduk", `${row.nama} (${row.nik})`),
        }));
        return null;
      },
      updatePenduduk: (oldNik, input) => {
        const state = get();
        const blocked = deny(state, "penduduk.write");
        if (blocked) return blocked;
        const prev = state.penduduk.find((p) => p.nik === oldNik);
        if (!prev) return "Data penduduk tidak ditemukan.";
        const err = validatePenduduk(input, { ...state, ignoreNik: oldNik });
        if (err) return err;
        const nik = input.nik.trim();
        const row: Penduduk = {
          ...prev,
          ...input,
          nik,
          nama: input.nama.trim(),
          noKk: input.noKk.trim(),
          tempatLahir: input.tempatLahir.trim(),
          namaAyah: input.namaAyah.trim(),
          namaIbu: input.namaIbu.trim(),
          alamat: state.keluarga.find((k) => k.noKk === input.noKk.trim())?.alamat ?? input.alamat,
        };
        set((s) => ({
          penduduk: s.penduduk.map((p) => (p.nik === oldNik ? row : p)),
          mutasi: s.mutasi.map((m) => (m.nik === oldNik ? { ...m, nik, nama: row.nama, noKk: row.noKk } : m)),
          surat: s.surat.map((sr) => (sr.nik === oldNik ? { ...sr, nik, nama: row.nama } : sr)),
          audit: withJejak(s, "Ubah", "Penduduk", `${row.nama} (${row.nik})`),
        }));
        return null;
      },
      deletePenduduk: (nik) => {
        const state = get();
        const blocked = deny(state, "penduduk.write");
        if (blocked) return blocked;
        const prev = state.penduduk.find((p) => p.nik === nik);
        if (!prev) return "Data penduduk tidak ditemukan.";
        set((s) => ({
          penduduk: s.penduduk.filter((p) => p.nik !== nik),
          audit: withJejak(s, "Hapus", "Penduduk", `${prev.nama} (${prev.nik})`),
        }));
        return null;
      },
      aktifkan: (nik) => {
        const state = get();
        const blocked = deny(state, "mutasi.write");
        if (blocked) return blocked;
        const prev = state.penduduk.find((p) => p.nik === nik);
        if (!prev) return "Data penduduk tidak ditemukan.";
        if (prev.statusHidup === "aktif") return "Penduduk ini sudah berstatus aktif.";
        set((s) => ({
          penduduk: s.penduduk.map((p) => (p.nik === nik ? { ...p, statusHidup: "aktif" } : p)),
          audit: withJejak(s, "Aktifkan", "Penduduk", `${prev.nama} dikembalikan ke penduduk aktif`),
        }));
        return null;
      },
      addKeluarga: (input) => {
        const state = get();
        const blocked = deny(state, "keluarga.write");
        if (blocked) return blocked;
        const err = validateKeluarga(input, state.keluarga);
        if (err) return err;
        const row: Keluarga = {
          id: crypto.randomUUID(),
          noKk: input.noKk.trim(),
          kepalaKeluarga: input.kepalaKeluarga.trim(),
          alamat: input.alamat.trim(),
          dusun: input.dusun.trim(),
          rt: input.rt.trim().padStart(2, "0"),
          rw: input.rw.trim().padStart(2, "0"),
          latitude: input.latitude,
          longitude: input.longitude,
          noListrik: input.noListrik.trim(),
          fotoKk: input.fotoKk,
          fotoDepan: input.fotoDepan,
          fotoDalam: input.fotoDalam,
          fotoKamarMandi: input.fotoKamarMandi,
          fotoLokasi: input.fotoLokasi,
          createdAt: new Date().toISOString(),
        };
        set((s) => ({
          keluarga: [...s.keluarga, row],
          audit: withJejak(s, "Tambah", "Keluarga", `${row.kepalaKeluarga} (${row.noKk})`),
        }));
        return null;
      },
      updateKeluarga: (oldNoKk, input) => {
        const state = get();
        const blocked = deny(state, "keluarga.write");
        if (blocked) return blocked;
        const prev = state.keluarga.find((k) => k.noKk === oldNoKk);
        if (!prev) return "Kartu keluarga tidak ditemukan.";
        const err = validateKeluarga(input, state.keluarga, oldNoKk);
        if (err) return err;
        const row: Keluarga = {
          ...prev,
          noKk: input.noKk.trim(),
          kepalaKeluarga: input.kepalaKeluarga.trim(),
          alamat: input.alamat.trim(),
          dusun: input.dusun.trim(),
          rt: input.rt.trim().padStart(2, "0"),
          rw: input.rw.trim().padStart(2, "0"),
          latitude: input.latitude,
          longitude: input.longitude,
          noListrik: input.noListrik.trim(),
          fotoKk: input.fotoKk,
          fotoDepan: input.fotoDepan,
          fotoDalam: input.fotoDalam,
          fotoKamarMandi: input.fotoKamarMandi,
          fotoLokasi: input.fotoLokasi,
        };
        set((s) => {
          const penduduk = syncAlamat(
            s.penduduk.map((p) => (p.noKk === oldNoKk ? { ...p, noKk: row.noKk } : p)),
            s.keluarga.map((k) => (k.noKk === oldNoKk ? row : k)),
          );
          return {
            keluarga: s.keluarga.map((k) => (k.noKk === oldNoKk ? row : k)),
            penduduk,
            mutasi: s.mutasi.map((m) => (m.noKk === oldNoKk ? { ...m, noKk: row.noKk } : m)),
            audit: withJejak(s, "Ubah", "Keluarga", `${row.kepalaKeluarga} (${row.noKk})`),
          };
        });
        return null;
      },
      deleteKeluarga: (noKk) => {
        const state = get();
        const blocked = deny(state, "keluarga.write");
        if (blocked) return blocked;
        const prev = state.keluarga.find((k) => k.noKk === noKk);
        if (!prev) return "Kartu keluarga tidak ditemukan.";
        if (state.penduduk.some((p) => p.noKk === noKk)) {
          return "Masih ada anggota. Pindahkan atau hapus anggota terlebih dahulu.";
        }
        set((s) => ({
          keluarga: s.keluarga.filter((k) => k.noKk !== noKk),
          audit: withJejak(s, "Hapus", "Keluarga", `${prev.kepalaKeluarga} (${prev.noKk})`),
        }));
        return null;
      },
      addMaster: (kind, nama) => {
        const state = get();
        const blocked = deny(state, "master.write");
        if (blocked) return blocked;
        const clean = nama.trim();
        if (clean.length < 2) return "Nama terlalu pendek.";
        if (state[kind].some((item) => item.nama.toLowerCase() === clean.toLowerCase())) return "Nama ini sudah ada.";
        const row: Master = { id: crypto.randomUUID(), nama: clean };
        set((s) => ({
          [kind]: [...s[kind], row],
          audit: withJejak(s, "Tambah", "Master", clean),
        }));
        return null;
      },
      renameMaster: (kind, id, nama) => {
        const state = get();
        const blocked = deny(state, "master.write");
        if (blocked) return blocked;
        const clean = nama.trim();
        if (clean.length < 2) return "Nama terlalu pendek.";
        if (!state[kind].some((item) => item.id === id)) return "Data tidak ditemukan.";
        if (state[kind].some((item) => item.id !== id && item.nama.toLowerCase() === clean.toLowerCase())) {
          return "Nama ini sudah ada.";
        }
        set((s) => ({
          [kind]: s[kind].map((item) => (item.id === id ? { ...item, nama: clean } : item)),
          audit: withJejak(s, "Ubah", "Master", clean),
        }));
        return null;
      },
      deleteMaster: (kind, id) => {
        const state = get();
        const blocked = deny(state, "master.write");
        if (blocked) return blocked;
        const item = state[kind].find((row) => row.id === id);
        if (!item) return "Data tidak ditemukan.";
        const dipakai = state.penduduk.some((p) =>
          kind === "pekerjaan" ? p.pekerjaanId === id : kind === "pendidikan" ? p.pendidikanId === id : p.statusId === id,
        );
        if (dipakai) return "Masih dipakai data penduduk. Ubah penduduk tersebut lebih dulu.";
        set((s) => ({
          [kind]: s[kind].filter((row) => row.id !== id),
          audit: withJejak(s, "Hapus", "Master", item.nama),
        }));
        return null;
      },
      simpanKelompok: (rows) => {
        const state = get();
        const blocked = deny(state, "master.write");
        if (blocked) return blocked;
        const err = validasiKelompok(rows);
        if (err) return err;
        const bersih = [...rows]
          .map((row) => ({ ...row, label: row.label.trim(), min: Number(row.min), max: Number(row.max) }))
          .sort((a, b) => a.min - b.min);
        set((s) => ({
          kelompokUsia: bersih,
          audit: withJejak(s, "Ubah", "Kelompok umur", bersih.map((row) => `${row.label} (${row.min}–${row.max})`).join(", ")),
        }));
        return null;
      },
      catatMeninggal: (nik, tanggal, keterangan) => catatKeluar(get, set, "meninggal", nik, tanggal, keterangan),
      catatPindahKeluar: (nik, tanggal, keterangan) => catatKeluar(get, set, "pindah_keluar", nik, tanggal, keterangan),
      catatLahir: (input) => {
        const state = get();
        const blocked = deny(state, "mutasi.write");
        if (blocked) return blocked;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(input.tanggal)) return "Tanggal kejadian tidak valid.";
        if (input.keterangan.trim().length < 3) return "Keterangan belum diisi.";
        const kk = state.keluarga.find((k) => k.noKk === input.noKk);
        if (!kk) return "Kartu keluarga tidak ditemukan.";
        const anak = state.statusKeluarga.find((s) => s.nama === "Anak");
        const tidakKerja = state.pekerjaan.find((p) => p.nama === "Tidak Bekerja");
        const tidakSekolah = state.pendidikan.find((p) => p.nama === "Tidak Sekolah");
        if (!anak || !tidakKerja || !tidakSekolah) return "Master data anak, pekerjaan, atau pendidikan belum lengkap.";
        const ibu = state.penduduk.find((p) => p.noKk === kk.noKk && p.nama.toLowerCase() === input.namaIbu.trim().toLowerCase());
        const pendudukInput: PendudukInput = {
          nik: input.nik.trim(),
          nama: input.nama.trim(),
          jenisKelamin: input.jenisKelamin,
          tempatLahir: input.tempatLahir.trim() || "Lamongan",
          tanggalLahir: input.tanggal,
          agama: ibu?.agama ?? "Islam",
          statusPerkawinan: "Belum Kawin",
          pekerjaanId: tidakKerja.id,
          pendidikanId: tidakSekolah.id,
          statusId: anak.id,
          noKk: kk.noKk,
          alamat: kk.alamat,
          namaAyah: input.namaAyah.trim(),
          namaIbu: input.namaIbu.trim(),
        };
        const err = validatePenduduk(pendudukInput, state);
        if (err) return err;
        const row: Penduduk = {
          ...pendudukInput,
          id: crypto.randomUUID(),
          statusHidup: "aktif",
          createdAt: new Date().toISOString(),
        };
        const mutasi: Mutasi = buatMutasi("lahir", row, input.tanggal, input.keterangan.trim(), actorOf(state)?.nama ?? "Sistem");
        set((s) => ({
          penduduk: [...s.penduduk, row],
          mutasi: [mutasi, ...s.mutasi],
          audit: withJejak(s, "Catat", "Mutasi", `Kelahiran ${row.nama}`),
        }));
        return null;
      },
      catatPindahMasuk: (input) => {
        const state = get();
        const blocked = deny(state, "mutasi.write");
        if (blocked) return blocked;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(input.tanggal)) return "Tanggal kejadian tidak valid.";
        if (input.keterangan.trim().length < 3) return "Keterangan asal pindah belum diisi.";
        const err = validatePenduduk(input, state);
        if (err) return err;
        const kk = state.keluarga.find((k) => k.noKk === input.noKk.trim());
        const row: Penduduk = {
          ...input,
          nik: input.nik.trim(),
          nama: input.nama.trim(),
          noKk: input.noKk.trim(),
          alamat: kk?.alamat ?? input.alamat,
          tempatLahir: input.tempatLahir.trim(),
          namaAyah: input.namaAyah.trim(),
          namaIbu: input.namaIbu.trim(),
          id: crypto.randomUUID(),
          statusHidup: "aktif",
          createdAt: new Date().toISOString(),
        };
        const mutasi = buatMutasi("pindah_masuk", row, input.tanggal, input.keterangan.trim(), actorOf(state)?.nama ?? "Sistem");
        set((s) => ({
          penduduk: [...s.penduduk, row],
          mutasi: [mutasi, ...s.mutasi],
          audit: withJejak(s, "Catat", "Mutasi", `Pindah masuk ${row.nama}`),
        }));
        return null;
      },
      terbitSurat: (jenis, nik, keperluan, tanggal) => {
        const state = get();
        const blocked = deny(state, "surat.write");
        if (blocked) return blocked;
        const orang = state.penduduk.find((p) => p.nik === nik);
        if (!orang) return "Penduduk tidak ditemukan.";
        if (keperluan.trim().length < 5) return "Keperluan surat belum cukup jelas.";
        if (!/^\d{4}-\d{2}-\d{2}$/.test(tanggal)) return "Tanggal surat tidak valid.";
        if (jenis === "kematian" && orang.statusHidup !== "meninggal") {
          return "Surat kematian hanya untuk penduduk yang sudah dicatat meninggal.";
        }
        if (jenis !== "kematian" && orang.statusHidup !== "aktif") {
          return "Surat ini hanya untuk penduduk berstatus aktif.";
        }
        const seq = state.suratSeq + 1;
        const surat: Surat = {
          id: crypto.randomUUID(),
          nomor: formatNomorSurat(seq, jenis, tanggal),
          jenis,
          nik: orang.nik,
          nama: orang.nama,
          keperluan: keperluan.trim(),
          tanggal,
          actor: actorOf(state)?.nama ?? "Sistem",
          createdAt: new Date().toISOString(),
        };
        set((s) => ({
          suratSeq: seq,
          surat: [surat, ...s.surat],
          audit: withJejak(s, "Terbit", "Surat", `${surat.nomor} atas nama ${surat.nama}`),
        }));
        return `ok:${surat.id}`;
      },
      deleteSurat: (id) => {
        const state = get();
        const blocked = deny(state, "surat.write");
        if (blocked) return blocked;
        const prev = state.surat.find((s) => s.id === id);
        if (!prev) return "Surat tidak ditemukan.";
        set((s) => ({
          surat: s.surat.filter((item) => item.id !== id),
          audit: withJejak(s, "Hapus", "Surat", prev.nomor),
        }));
        return null;
      },
      addUser: (input) => {
        const state = get();
        const blocked = deny(state, "user.write");
        if (blocked) return blocked;
        const err = validUser(input, state.users);
        if (err) return err;
        const row: User = {
          ...input,
          id: crypto.randomUUID(),
          username: input.username.trim().toLowerCase(),
          nama: input.nama.trim(),
          email: input.email.trim(),
          noHp: input.noHp.trim(),
          alamat: input.alamat.trim(),
        };
        set((s) => ({
          users: [...s.users, row],
          audit: withJejak(s, "Tambah", "Pengguna", `${row.nama} (${row.username})`),
        }));
        return null;
      },
      updateUser: (id, input) => {
        const state = get();
        const blocked = deny(state, "user.write");
        if (blocked) return blocked;
        const prev = state.users.find((u) => u.id === id);
        if (!prev) return "Pengguna tidak ditemukan.";
        const next: User = {
          ...prev,
          ...input,
          username: input.username.trim().toLowerCase(),
          nama: input.nama.trim(),
          email: input.email.trim(),
          password: input.password?.trim() ? input.password : prev.password,
        };
        const err = validUser(next, state.users, id);
        if (err) return err;
        if (prev.role === "admin" && next.role !== "admin" && state.users.filter((u) => u.role === "admin").length < 2) {
          return "Harus tersisa sedikitnya satu admin.";
        }
        set((s) => ({
          users: s.users.map((u) => (u.id === id ? next : u)),
          audit: withJejak(s, "Ubah", "Pengguna", next.nama),
        }));
        return null;
      },
      deleteUser: (id) => {
        const state = get();
        const blocked = deny(state, "user.write");
        if (blocked) return blocked;
        if (state.session?.userId === id) return "Anda tidak dapat menghapus akun yang sedang dipakai.";
        const prev = state.users.find((u) => u.id === id);
        if (!prev) return "Pengguna tidak ditemukan.";
        if (prev.role === "admin" && state.users.filter((u) => u.role === "admin").length < 2) {
          return "Admin terakhir tidak boleh dihapus.";
        }
        set((s) => ({
          users: s.users.filter((u) => u.id !== id),
          audit: withJejak(s, "Hapus", "Pengguna", prev.nama),
        }));
        return null;
      },
      updateProfile: (input) => {
        const state = get();
        const id = state.session?.userId;
        const prev = state.users.find((u) => u.id === id);
        if (!prev) return "Sesi berakhir.";
        if (input.nama.trim().length < 3) return "Nama belum lengkap.";
        set((s) => ({
          users: s.users.map((u) =>
            u.id === id
              ? { ...u, nama: input.nama.trim(), email: input.email.trim(), noHp: input.noHp.trim(), alamat: input.alamat.trim() }
              : u,
          ),
          audit: withJejak(s, "Ubah", "Profil", input.nama.trim()),
        }));
        return null;
      },
      changePassword: (lama, baru) => {
        const state = get();
        const id = state.session?.userId;
        const prev = state.users.find((u) => u.id === id);
        if (!prev) return "Sesi berakhir.";
        if (prev.password !== lama) return "Kata sandi lama tidak sesuai.";
        if (baru.trim().length < 6) return "Kata sandi baru minimal 6 karakter.";
        set((s) => ({
          users: s.users.map((u) => (u.id === id ? { ...u, password: baru } : u)),
          audit: withJejak(s, "Ubah", "Profil", "Kata sandi diperbarui"),
        }));
        return null;
      },
      importPenduduk: (rows) => {
        const state = get();
        const blocked = deny(state, "penduduk.write");
        if (blocked) return blocked;
        if (!rows.length) return "Tidak ada baris yang sah untuk diimpor.";
        const dibuat: Penduduk[] = rows.map((input) => ({
          ...input,
          nik: input.nik.trim(),
          nama: input.nama.trim(),
          noKk: input.noKk.trim(),
          alamat: state.keluarga.find((k) => k.noKk === input.noKk)?.alamat ?? input.alamat,
          id: crypto.randomUUID(),
          statusHidup: "aktif",
          createdAt: new Date().toISOString(),
        }));
        set((s) => ({
          penduduk: [...s.penduduk, ...dibuat],
          audit: withJejak(s, "Impor", "Penduduk", `${dibuat.length} jiwa dari CSV`),
        }));
        return null;
      },
      restore: (data) => {
        const state = get();
        const blocked = deny(state, "backup.restore");
        if (blocked) return blocked;
        const sessionUser = state.users.find((u) => u.id === state.session?.userId);
        const nextSession = data.users.find((u) => u.username === sessionUser?.username);
        const nama = sessionUser?.nama ?? "Sistem";
        set({
          ...data,
          session: nextSession ? { userId: nextSession.id } : null,
          audit: [jejakBaru(nama, "Pulihkan", "Cadangan", "Data desa dipulihkan dari berkas"), ...data.audit].slice(0, 400),
        });
        return null;
      },
      resetContoh: () => {
        const state = get();
        const blocked = deny(state, "backup.restore");
        if (blocked) return blocked;
        const fresh = dataContoh();
        const nama = actorOf(state)?.nama;
        const user = fresh.users.find((u) => u.nama === nama) ?? fresh.users[0];
        set({
          ...fresh,
          session: user ? { userId: user.id } : null,
          audit: [jejakBaru(user?.nama ?? "Sistem", "Reset", "Cadangan", "Data contoh dimuat ulang"), ...fresh.audit],
        });
        return null;
      },
}));

function buatMutasi(jenis: Mutasi["jenis"], orang: Penduduk, tanggal: string, keterangan: string, actor: string): Mutasi {
  return {
    id: crypto.randomUUID(),
    jenis,
    nik: orang.nik,
    nama: orang.nama,
    tanggal,
    keterangan,
    noKk: orang.noKk,
    actor,
    createdAt: new Date().toISOString(),
  };
}

function catatKeluar(
  get: () => SidukState,
  set: (partial: Partial<SidukState> | ((state: SidukState) => Partial<SidukState>)) => void,
  jenis: "meninggal" | "pindah_keluar",
  nik: string,
  tanggal: string,
  keterangan: string,
): string | null {
  const state = get();
  const blocked = deny(state, "mutasi.write");
  if (blocked) return blocked;
  const orang = state.penduduk.find((p) => p.nik === nik);
  if (!orang) return "Penduduk tidak ditemukan.";
  if (orang.statusHidup !== "aktif") return "Hanya penduduk aktif yang dapat dicatat mutasinya.";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(tanggal)) return "Tanggal kejadian tidak valid.";
  if (tanggal < orang.tanggalLahir) return "Tanggal kejadian tidak boleh sebelum tanggal lahir.";
  if (keterangan.trim().length < 3) return "Keterangan belum diisi.";
  const hidup = jenis === "meninggal" ? "meninggal" : "pindah";
  const mutasi = buatMutasi(jenis, orang, tanggal, keterangan.trim(), actorOf(state)?.nama ?? "Sistem");
  set((s) => ({
    penduduk: s.penduduk.map((p) => (p.nik === nik ? { ...p, statusHidup: hidup } : p)),
    mutasi: [mutasi, ...s.mutasi],
    audit: withJejak(s, "Catat", "Mutasi", `${jenis === "meninggal" ? "Kematian" : "Pindah keluar"} ${orang.nama}`),
  }));
  return null;
}

function validUser(input: Omit<User, "id"> | User, users: User[], ignoreId?: string): string | null {
  if (!/^[a-z0-9._]{3,20}$/i.test(input.username.trim())) return "Nama pengguna 3–20 karakter, huruf atau angka.";
  if (input.nama.trim().length < 3) return "Nama lengkap belum cukup.";
  if (input.password.trim().length < 6) return "Kata sandi minimal 6 karakter.";
  if (users.some((u) => u.username.toLowerCase() === input.username.trim().toLowerCase() && u.id !== ignoreId)) {
    return "Nama pengguna sudah dipakai.";
  }
  if (!["admin", "petugas", "kepala_desa"].includes(input.role)) return "Peran tidak dikenal.";
  return null;
}

export function useUser() {
  return useSiduk((s) => s.users.find((u) => u.id === s.session?.userId) ?? null);
}
