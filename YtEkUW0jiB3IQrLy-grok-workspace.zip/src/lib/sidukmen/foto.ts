export type Titik = { latitude: number; longitude: number };

export async function kompresGambar(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) throw new Error("Berkas ini bukan gambar.");
  if (file.size > 15 * 1024 * 1024) throw new Error("Gambar terlalu besar. Maksimal 15 MB.");
  const url = URL.createObjectURL(file);
  try {
    const img = await muatGambar(url);
    const max = 960;
    const scale = Math.min(1, max / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.width * scale));
    canvas.height = Math.max(1, Math.round(img.height * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Gambar tidak dapat diproses.");
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.62);
  } finally {
    URL.revokeObjectURL(url);
  }
}

function muatGambar(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Format gambar tidak didukung. Gunakan JPG atau PNG."));
    img.src = url;
  });
}

export function lokasiPerangkat(): Promise<Titik | null> {
  return ambilLokasi().then((hasil) => (hasil.ok ? { latitude: hasil.latitude, longitude: hasil.longitude } : null));
}

export type HasilLokasi = { ok: true; latitude: number; longitude: number; accuracy: number } | { ok: false; pesan: string };

export function ambilLokasi(): Promise<HasilLokasi> {
  if (typeof navigator === "undefined" || !navigator.geolocation) {
    return Promise.resolve({ ok: false, pesan: "Peramban ini tidak mendukung GPS." });
  }
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          ok: true,
          latitude: Math.round(pos.coords.latitude * 1e6) / 1e6,
          longitude: Math.round(pos.coords.longitude * 1e6) / 1e6,
          accuracy: Math.round(pos.coords.accuracy),
        }),
      (err) =>
        resolve({
          ok: false,
          pesan: err.code === 1 ? "Izin lokasi ditolak. Aktifkan lokasi untuk situs ini, lalu coba lagi." : "Sinyal GPS belum terbaca. Coba di luar ruangan.",
        }),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 },
    );
  });
}

export async function bacaGpsExif(file: File): Promise<Titik | null> {
  try {
    const buf = await file.slice(0, 512 * 1024).arrayBuffer();
    const view = new DataView(buf);
    if (view.byteLength < 4 || view.getUint16(0) !== 0xffd8) return null;
    let offset = 2;
    while (offset + 4 < view.byteLength) {
      const marker = view.getUint16(offset);
      if (marker === 0xffda || marker === 0xffd9) break;
      const size = view.getUint16(offset + 2);
      if (size < 2 || offset + 2 + size > view.byteLength) break;
      if (marker === 0xffe1) return gpsDariExif(view, offset + 4, size - 2);
      offset += 2 + size;
    }
  } catch {
    return null;
  }
  return null;
}

function gpsDariExif(view: DataView, start: number, length: number): Titik | null {
  if (length < 16) return null;
  const sig = [0, 1, 2, 3].map((i) => String.fromCharCode(view.getUint8(start + i))).join("");
  if (sig !== "Exif") return null;
  const tiff = start + 6;
  if (tiff + 8 > view.byteLength) return null;
  const order = view.getUint16(tiff);
  const le = order === 0x4949;
  if (!le && order !== 0x4d4d) return null;
  const u16 = (o: number) => view.getUint16(o, le);
  const u32 = (o: number) => view.getUint32(o, le);
  if (u16(tiff + 2) !== 42) return null;
  const ifd0 = tiff + u32(tiff + 4);
  const gpsPtr = pointerIfd(view, ifd0, 0x8825, u16, u32);
  if (gpsPtr == null) return null;
  return bacaGps(view, tiff, tiff + gpsPtr, u16, u32, le);
}

function pointerIfd(
  view: DataView,
  ifd: number,
  tag: number,
  u16: (o: number) => number,
  u32: (o: number) => number,
): number | null {
  if (ifd + 2 > view.byteLength) return null;
  const count = u16(ifd);
  for (let i = 0; i < count; i += 1) {
    const entry = ifd + 2 + i * 12;
    if (entry + 12 > view.byteLength) return null;
    if (u16(entry) === tag) return u32(entry + 8);
  }
  return null;
}

function bacaGps(
  view: DataView,
  tiff: number,
  gps: number,
  u16: (o: number) => number,
  u32: (o: number) => number,
  le: boolean,
): Titik | null {
  if (gps + 2 > view.byteLength) return null;
  const count = u16(gps);
  let lat: number | null = null;
  let lng: number | null = null;
  let latRef = "N";
  let lngRef = "E";
  for (let i = 0; i < count; i += 1) {
    const entry = gps + 2 + i * 12;
    if (entry + 12 > view.byteLength) break;
    const tag = u16(entry);
    const type = u16(entry);
    const n = u32(entry + 4);
    const val = u32(entry + 8);
    if (tag === 1 && type === 2) latRef = ascii(view, entry + 8, 2);
    if (tag === 3 && type === 2) lngRef = ascii(view, entry + 8, 2);
    if ((tag === 2 || tag === 4) && type === 5 && n === 3) {
      const off = tiff + val;
      const d = rasio(view, off, le);
      const m = rasio(view, off + 8, le);
      const s = rasio(view, off + 16, le);
      const deg = d + m / 60 + s / 3600;
      if (tag === 2) lat = deg;
      else lng = deg;
    }
  }
  if (lat == null || lng == null) return null;
  if (latRef === "S") lat = -lat;
  if (lngRef === "W") lng = -lng;
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return null;
  return { latitude: Math.round(lat * 1e6) / 1e6, longitude: Math.round(lng * 1e6) / 1e6 };
}

function rasio(view: DataView, offset: number, le: boolean): number {
  if (offset + 8 > view.byteLength) return 0;
  const den = view.getUint32(offset + 4, le);
  if (!den) return 0;
  return view.getUint32(offset, le) / den;
}

function ascii(view: DataView, offset: number, n: number): string {
  let out = "";
  for (let i = 0; i < n; i += 1) {
    if (offset + i >= view.byteLength) break;
    const c = view.getUint8(offset + i);
    if (c === 0) break;
    out += String.fromCharCode(c);
  }
  return out;
}
