import type {
  Ability,
  Audit,
  JenisKelamin,
  JenisMutasi,
  JenisSurat,
  KelompokUsia,
  Keluarga,
  KeluargaInput,
  Master,
  Penduduk,
  PendudukInput,
  Role,
  Surat,
} from "./types";

export const DESA = {
  nama: "Monongo",
  kecamatan: "Sukodadi",
  kabupaten: "Lamongan",
  provinsi: "Jawa Timur",
};

export const AGAMA = ["Islam", "Kristen", "Katolik", "Hindu", "Buddha", "Konghucu"] as const;

export const STATUS_KAWIN = ["Belum Kawin", "Kawin", "Cerai Hidup", "Cerai Mati"] as const;

export const KELOMPOK_USIA: KelompokUsia[] = [
  { id: "0-5", label: "0–5", min: 0, max: 5 },
  { id: "6-12", label: "6–12", min: 6, max: 12 },
  { id: "13-17", label: "13–17", min: 13, max: 17 },
  { id: "18-30", label: "18–30", min: 18, max: 30 },
  { id: "31-45", label: "31–45", min: 31, max: 45 },
  { id: "46-60", label: "46–60", min: 46, max: 60 },
  { id: "61+", label: "61+", min: 61, max: 120 },
];

export const CHART_COLORS = [
  "var(--color-brand)",
  "var(--color-brandsoft)",
  "var(--color-stone)",
  "var(--color-sand)",
  "var(--color-clay)",
] as const;

export const ROLE_LABEL: Record<Role, string> = {
  admin: "Admin",
  petugas: "Petugas",
  kepala_desa: "Kepala Desa",
};

export const MUTASI_LABEL: Record<JenisMutasi, string> = {
  lahir: "Kelahiran",
  meninggal: "Kematian",
  pindah_masuk: "Pindah masuk",
  pindah_keluar: "Pindah keluar",
};

export const SURAT_LABEL: Record<JenisSurat, string> = {
  domisili: "Surat Keterangan Domisili",
  usaha: "Surat Keterangan Usaha",
  tidak_mampu: "Surat Keterangan Tidak Mampu",
  kelahiran: "Surat Keterangan Kelahiran",
  kematian: "Surat Keterangan Kematian",
  pengantar: "Surat Pengantar",
};

const SURAT_KODE: Record<JenisSurat, string> = {
  domisili: "SKD",
  usaha: "SKU",
  tidak_mampu: "SKTM",
  kelahiran: "SKL",
  kematian: "SKK",
  pengantar: "SP",
};

const BULAN = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
];

const ROMAWI = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];

export const DEMO_AKUN = [
  { username: "admin", password: "monongo", peran: "Admin desa — kelola pengguna dan data penduduk" },
  { username: "petugas", password: "monongo", peran: "Petugas — input penduduk, keluarga, dan foto rumah" },
  { username: "kepala", password: "monongo", peran: "Kepala desa — melihat data penduduk" },
] as const;

export function can(role: Role, ability: Ability): boolean {
  if (role === "admin") return true;
  if (role === "petugas") return ability !== "user.write";
  return ability === "surat.write";
}

export function namaMaster(list: Master[], id: string): string {
  return list.find((item) => item.id === id)?.nama ?? "—";
}

export function umur(tanggalLahir: string, today = new Date()): number {
  const [y, m, d] = tanggalLahir.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return 0;
  let age = today.getFullYear() - y;
  const month = today.getMonth() + 1;
  if (month < m || (month === m && today.getDate() < d)) age -= 1;
  return age;
}

export function formatTanggal(iso: string): string {
  const [y, m, d] = iso.slice(0, 10).split("-");
  if (!y || !m || !d) return iso;
  return `${Number(d)} ${BULAN[Number(m) - 1] ?? ""} ${y}`;
}

export function formatWaktu(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function angka(n: number): string {
  return new Intl.NumberFormat("id-ID").format(n);
}

export function labelKelamin(jk: JenisKelamin): string {
  return jk === "L" ? "Laki-laki" : "Perempuan";
}

export function alamatKeluarga(k: Pick<Keluarga, "alamat" | "dusun" | "rt" | "rw">): string {
  return `${k.alamat}, RT ${k.rt}/RW ${k.rw}, Dusun ${k.dusun}, Desa ${DESA.nama}`;
}

export function formatNomorSurat(seq: number, jenis: JenisSurat, tanggal: string): string {
  const month = Number(tanggal.slice(5, 7)) - 1;
  const year = tanggal.slice(0, 4);
  return `${String(seq).padStart(3, "0")}/${SURAT_KODE[jenis]}/${ROMAWI[month] ?? "I"}/${year}`;
}

export function aktif(p: Penduduk): boolean {
  return p.statusHidup === "aktif";
}

export function validateKeluarga(
  input: KeluargaInput,
  keluarga: Keluarga[],
  ignoreNoKk?: string,
): string | null {
  if (!/^\d{16}$/.test(input.noKk.trim())) return "Nomor KK harus 16 digit angka.";
  if (input.kepalaKeluarga.trim().length < 3) return "Nama kepala keluarga belum lengkap.";
  if (input.alamat.trim().length < 3) return "Alamat belum diisi.";
  if (input.dusun.trim().length < 2) return "Dusun belum diisi.";
  if (!/^\d{1,3}$/.test(input.rt.trim()) || !/^\d{1,3}$/.test(input.rw.trim())) {
    return "RT dan RW diisi angka.";
  }
  if (keluarga.some((k) => k.noKk === input.noKk.trim() && k.noKk !== ignoreNoKk)) {
    return "Nomor KK ini sudah terdaftar.";
  }
  if (input.latitude != null && (input.latitude < -90 || input.latitude > 90)) {
    return "Lintang tidak valid.";
  }
  if (input.longitude != null && (input.longitude < -180 || input.longitude > 180)) {
    return "Bujur tidak valid.";
  }
  const listrik = input.noListrik.trim();
  if (listrik && !/^\d{6,20}$/.test(listrik)) return "Nomor pelanggan listrik diisi 6–20 digit, atau dikosongkan.";
  return null;
}

type ValidateCtx = {
  penduduk: Penduduk[];
  keluarga: Keluarga[];
  pekerjaan: Master[];
  pendidikan: Master[];
  statusKeluarga: Master[];
  ignoreNik?: string;
};

export function validatePenduduk(input: PendudukInput, ctx: ValidateCtx): string | null {
  const nik = input.nik.trim();
  if (!/^\d{16}$/.test(nik)) return "NIK harus 16 digit angka.";
  if (ctx.penduduk.some((p) => p.nik === nik && p.nik !== ctx.ignoreNik)) return "NIK sudah dipakai penduduk lain.";
  if (input.nama.trim().length < 3) return "Nama lengkap belum cukup.";
  if (input.jenisKelamin !== "L" && input.jenisKelamin !== "P") return "Jenis kelamin belum dipilih.";
  if (input.tempatLahir.trim().length < 2) return "Tempat lahir belum diisi.";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.tanggalLahir)) return "Tanggal lahir tidak valid.";
  if (input.tanggalLahir > new Date().toISOString().slice(0, 10)) return "Tanggal lahir tidak boleh di masa depan.";
  if (!AGAMA.includes(input.agama as (typeof AGAMA)[number])) return "Agama belum dipilih.";
  if (!STATUS_KAWIN.includes(input.statusPerkawinan as (typeof STATUS_KAWIN)[number])) {
    return "Status perkawinan belum dipilih.";
  }
  if (!ctx.pekerjaan.some((p) => p.id === input.pekerjaanId)) return "Pekerjaan belum dipilih.";
  if (!ctx.pendidikan.some((p) => p.id === input.pendidikanId)) return "Pendidikan belum dipilih.";
  if (!ctx.statusKeluarga.some((p) => p.id === input.statusId)) return "Status dalam keluarga belum dipilih.";
  const kk = ctx.keluarga.find((k) => k.noKk === input.noKk.trim());
  if (!kk) return "Nomor KK tidak ditemukan. Buat kartu keluarga terlebih dahulu.";
  const kepalaId = ctx.statusKeluarga.find((s) => s.nama === "Kepala Keluarga")?.id;
  if (kepalaId && input.statusId === kepalaId) {
    const lain = ctx.penduduk.find(
      (p) => p.noKk === kk.noKk && p.statusId === kepalaId && p.statusHidup === "aktif" && p.nik !== ctx.ignoreNik,
    );
    if (lain) return `Kartu keluarga ini sudah memiliki kepala keluarga: ${lain.nama}.`;
  }
  return null;
}

export function kelompokUsia(penduduk: Penduduk[], pita: KelompokUsia[] = KELOMPOK_USIA): { label: string; jumlah: number }[] {
  const hidup = penduduk.filter(aktif);
  return pita.map((k) => ({
    label: k.label,
    jumlah: hidup.filter((p) => {
      const u = umur(p.tanggalLahir);
      return u >= k.min && u <= k.max;
    }).length,
  }));
}

export function validasiKelompok(rows: KelompokUsia[]): string | null {
  if (!rows.length) return "Minimal satu kelompok umur.";
  const bersih = rows.map((row) => ({
    ...row,
    label: row.label.trim(),
    min: Number(row.min),
    max: Number(row.max),
  }));
  for (const row of bersih) {
    if (!row.label) return "Nama kelompok belum diisi.";
    if (!Number.isInteger(row.min) || !Number.isInteger(row.max) || row.min < 0 || row.max > 150 || row.min > row.max) {
      return `Rentang "${row.label || "kelompok"}" tidak valid.`;
    }
  }
  const urut = [...bersih].sort((a, b) => a.min - b.min);
  for (let i = 1; i < urut.length; i += 1) {
    if (urut[i].min <= urut[i - 1].max) return "Rentang umur tidak boleh saling tumpang tindih.";
  }
  return null;
}

export function hitungMaster(
  penduduk: Penduduk[],
  list: Master[],
  pick: (p: Penduduk) => string,
): { label: string; jumlah: number }[] {
  const hidup = penduduk.filter(aktif);
  return list
    .map((item) => ({
      label: item.nama,
      jumlah: hidup.filter((p) => pick(p) === item.id).length,
    }))
    .filter((row) => row.jumlah > 0)
    .sort((a, b) => b.jumlah - a.jumlah);
}

export function ringkas(rows: { label: string; jumlah: number }[], n = 6) {
  if (rows.length <= n) return rows;
  const head = rows.slice(0, n - 1);
  const rest = rows.slice(n - 1).reduce((sum, row) => sum + row.jumlah, 0);
  return [...head, { label: "Lainnya", jumlah: rest }];
}

export function hitungTeks(penduduk: Penduduk[], pick: (p: Penduduk) => string) {
  const map = new Map<string, number>();
  for (const p of penduduk.filter(aktif)) {
    const key = pick(p) || "—";
    map.set(key, (map.get(key) ?? 0) + 1);
  }
  return [...map.entries()]
    .map(([label, jumlah]) => ({ label, jumlah }))
    .sort((a, b) => b.jumlah - a.jumlah);
}

export function persen(bagian: number, total: number): string {
  if (!total) return "0%";
  return `${((bagian / total) * 100).toFixed(1).replace(".", ",")}%`;
}

const CSV_HEADERS = [
  "nik",
  "nama",
  "jenis_kelamin",
  "tempat_lahir",
  "tanggal_lahir",
  "agama",
  "status_perkawinan",
  "pekerjaan",
  "pendidikan",
  "status_keluarga",
  "no_kk",
  "nama_ayah",
  "nama_ibu",
] as const;

function csvEscape(value: string): string {
  if (/[",\n\r]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

export function pendudukToCsv(
  rows: Penduduk[],
  ctx: { pekerjaan: Master[]; pendidikan: Master[]; statusKeluarga: Master[] },
): string {
  const lines = [CSV_HEADERS.join(",")];
  for (const p of rows) {
    const cols = [
      p.nik,
      p.nama,
      p.jenisKelamin,
      p.tempatLahir,
      p.tanggalLahir,
      p.agama,
      p.statusPerkawinan,
      namaMaster(ctx.pekerjaan, p.pekerjaanId),
      namaMaster(ctx.pendidikan, p.pendidikanId),
      namaMaster(ctx.statusKeluarga, p.statusId),
      p.noKk,
      p.namaAyah,
      p.namaIbu,
    ];
    lines.push(cols.map(csvEscape).join(","));
  }
  return lines.join("\n");
}

export function templateCsv(): string {
  return [
    CSV_HEADERS.join(","),
    [
      "3524120101900099",
      "Nama Contoh",
      "L",
      "Lamongan",
      "1990-01-01",
      "Islam",
      "Kawin",
      "Petani",
      "SMA/SMK/Sederajat",
      "Kepala Keluarga",
      "3524120000001001",
      "Nama Ayah",
      "Nama Ibu",
    ].join(","),
  ].join("\n");
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = "";
  let quoted = false;
  const src = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < src.length; i += 1) {
    const c = src[i];
    if (quoted) {
      if (c === '"') {
        if (src[i + 1] === '"') {
          cur += '"';
          i += 1;
        } else quoted = false;
      } else cur += c;
    } else if (c === '"') quoted = true;
    else if (c === ",") {
      row.push(cur);
      cur = "";
    } else if (c === "\n") {
      row.push(cur);
      rows.push(row);
      row = [];
      cur = "";
    } else if (c !== "\r") cur += c;
  }
  if (cur.length || row.length) {
    row.push(cur);
    rows.push(row);
  }
  return rows.filter((r) => r.some((cell) => cell.trim() !== ""));
}

export type ImportIssue = { baris: number; pesan: string };

export function planImport(
  matrix: string[][],
  ctx: ValidateCtx,
): { ok: PendudukInput[]; issues: ImportIssue[] } {
  if (matrix.length < 2) return { ok: [], issues: [{ baris: 1, pesan: "Berkas kosong atau hanya berisi judul kolom." }] };
  const header = matrix[0].map((h) => h.trim().toLowerCase());
  const missing = CSV_HEADERS.filter((h) => !header.includes(h));
  if (missing.length) {
    return { ok: [], issues: [{ baris: 1, pesan: `Kolom wajib belum ada: ${missing.join(", ")}.` }] };
  }
  const idx = (name: string) => header.indexOf(name);
  const ok: PendudukInput[] = [];
  const issues: ImportIssue[] = [];
  const seen = new Set<string>();
  const penduduk = [...ctx.penduduk];

  matrix.slice(1).forEach((cols, index) => {
    const baris = index + 2;
    const cell = (name: string) => (cols[idx(name)] ?? "").trim();
    const jkRaw = cell("jenis_kelamin").toUpperCase();
    const jk: JenisKelamin | "" = jkRaw === "L" || jkRaw === "LAKI-LAKI" ? "L" : jkRaw === "P" || jkRaw === "PEREMPUAN" ? "P" : "";
    const pekerjaan = ctx.pekerjaan.find((p) => p.nama.toLowerCase() === cell("pekerjaan").toLowerCase());
    const pendidikan = ctx.pendidikan.find((p) => p.nama.toLowerCase() === cell("pendidikan").toLowerCase());
    const status = ctx.statusKeluarga.find((p) => p.nama.toLowerCase() === cell("status_keluarga").toLowerCase());
    const kk = ctx.keluarga.find((k) => k.noKk === cell("no_kk"));
    const input: PendudukInput = {
      nik: cell("nik"),
      nama: cell("nama"),
      jenisKelamin: (jk || "L") as JenisKelamin,
      tempatLahir: cell("tempat_lahir"),
      tanggalLahir: cell("tanggal_lahir"),
      agama: cell("agama"),
      statusPerkawinan: cell("status_perkawinan"),
      pekerjaanId: pekerjaan?.id ?? "",
      pendidikanId: pendidikan?.id ?? "",
      statusId: status?.id ?? "",
      noKk: cell("no_kk"),
      namaAyah: cell("nama_ayah"),
      namaIbu: cell("nama_ibu"),
      alamat: kk ? kk.alamat : "",
    };
    if (!jk) {
      issues.push({ baris, pesan: "Jenis kelamin harus L atau P." });
      return;
    }
    if (!pekerjaan) {
      issues.push({ baris, pesan: `Pekerjaan "${cell("pekerjaan")}" tidak ada di master data.` });
      return;
    }
    if (!pendidikan) {
      issues.push({ baris, pesan: `Pendidikan "${cell("pendidikan")}" tidak ada di master data.` });
      return;
    }
    if (!status) {
      issues.push({ baris, pesan: `Status keluarga "${cell("status_keluarga")}" tidak ada di master data.` });
      return;
    }
    if (seen.has(input.nik)) {
      issues.push({ baris, pesan: "NIK dobel di dalam berkas." });
      return;
    }
    const err = validatePenduduk(input, { ...ctx, penduduk });
    if (err) {
      issues.push({ baris, pesan: err });
      return;
    }
    seen.add(input.nik);
    penduduk.push({ ...input, id: "tmp", statusHidup: "aktif", createdAt: "" });
    ok.push(input);
  });
  return { ok, issues };
}

export function isiSurat(surat: Surat, penduduk: Penduduk | undefined, keluarga: Keluarga | undefined): string {
  const alamat = keluarga ? alamatKeluarga(keluarga) : penduduk?.alamat || "Desa Monongo";
  const nama = surat.nama;
  const nik = surat.nik;
  const perlu = surat.keperluan.trim();
  if (surat.jenis === "domisili") {
    return `Yang bertanda tangan di bawah ini Kepala Desa ${DESA.nama}, Kecamatan ${DESA.kecamatan}, Kabupaten ${DESA.kabupaten}, menerangkan bahwa ${nama}, NIK ${nik}, adalah penduduk yang benar berdomisili di ${alamat}, Kecamatan ${DESA.kecamatan}, Kabupaten ${DESA.kabupaten}, Provinsi ${DESA.provinsi}. Surat keterangan ini dibuat untuk keperluan ${perlu}.`;
  }
  if (surat.jenis === "usaha") {
    return `Yang bertanda tangan di bawah ini Kepala Desa ${DESA.nama} menerangkan bahwa ${nama}, NIK ${nik}, penduduk ${alamat}, benar memiliki usaha sebagaimana dimaksud dalam keperluan: ${perlu}. Surat ini bukan izin usaha komersial dari instansi teknis, melainkan keterangan domisili usaha dari desa.`;
  }
  if (surat.jenis === "tidak_mampu") {
    return `Yang bertanda tangan di bawah ini Kepala Desa ${DESA.nama} menerangkan bahwa ${nama}, NIK ${nik}, penduduk ${alamat}, menurut catatan desa termasuk keluarga tidak mampu. Surat keterangan ini diterbitkan untuk keperluan ${perlu}.`;
  }
  if (surat.jenis === "kelahiran") {
    return `Yang bertanda tangan di bawah ini Kepala Desa ${DESA.nama} menerangkan bahwa ${nama}, NIK ${nik}, tercatat sebagai penduduk ${alamat}. Surat keterangan kelahiran ini diterbitkan untuk keperluan ${perlu}.`;
  }
  if (surat.jenis === "kematian") {
    return `Yang bertanda tangan di bawah ini Kepala Desa ${DESA.nama} menerangkan bahwa ${nama}, NIK ${nik}, penduduk ${alamat}, telah dicatat meninggal dunia dalam register mutasi desa. Surat ini diterbitkan untuk keperluan ${perlu}.`;
  }
  return `Yang bertanda tangan di bawah ini Kepala Desa ${DESA.nama} menerangkan bahwa ${nama}, NIK ${nik}, penduduk ${alamat}, adalah warga Desa ${DESA.nama}. Surat pengantar ini diterbitkan untuk keperluan ${perlu}.`;
}

export function downloadText(filename: string, text: string, mime: string) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function bulanIni(iso: string, today = new Date()): boolean {
  const [y, m] = iso.slice(0, 10).split("-");
  return Number(y) === today.getFullYear() && Number(m) === today.getMonth() + 1;
}

export function jejakBaru(actor: string, aksi: string, entitas: string, detail: string): Audit {
  return {
    id: crypto.randomUUID(),
    waktu: new Date().toISOString(),
    actor,
    aksi,
    entitas,
    detail,
  };
}
