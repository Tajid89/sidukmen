export type Role = "admin" | "petugas" | "kepala_desa";

export type User = {
  id: string;
  username: string;
  password: string;
  nama: string;
  email: string;
  noHp: string;
  alamat: string;
  role: Role;
};

export type Master = { id: string; nama: string };

export type KelompokUsia = { id: string; label: string; min: number; max: number };

export type Keluarga = {
  id: string;
  noKk: string;
  kepalaKeluarga: string;
  alamat: string;
  dusun: string;
  rt: string;
  rw: string;
  latitude: number | null;
  longitude: number | null;
  noListrik: string;
  fotoKk: string | null;
  fotoDepan: string | null;
  fotoDalam: string | null;
  fotoKamarMandi: string | null;
  fotoLokasi: string | null;
  createdAt: string;
};

export type JenisKelamin = "L" | "P";
export type StatusHidup = "aktif" | "meninggal" | "pindah";

export type Penduduk = {
  id: string;
  nik: string;
  nama: string;
  jenisKelamin: JenisKelamin;
  tempatLahir: string;
  tanggalLahir: string;
  agama: string;
  statusPerkawinan: string;
  pekerjaanId: string;
  pendidikanId: string;
  alamat: string;
  noKk: string;
  statusId: string;
  namaAyah: string;
  namaIbu: string;
  statusHidup: StatusHidup;
  createdAt: string;
};

export type JenisMutasi = "lahir" | "meninggal" | "pindah_masuk" | "pindah_keluar";

export type Mutasi = {
  id: string;
  jenis: JenisMutasi;
  nik: string;
  nama: string;
  tanggal: string;
  keterangan: string;
  noKk: string;
  actor: string;
  createdAt: string;
};

export type JenisSurat =
  | "domisili"
  | "usaha"
  | "tidak_mampu"
  | "kelahiran"
  | "kematian"
  | "pengantar";

export type Surat = {
  id: string;
  nomor: string;
  jenis: JenisSurat;
  nik: string;
  nama: string;
  keperluan: string;
  tanggal: string;
  actor: string;
  createdAt: string;
};

export type Audit = {
  id: string;
  waktu: string;
  actor: string;
  aksi: string;
  entitas: string;
  detail: string;
};

export type Session = { userId: string };

export type PendudukInput = {
  nik: string;
  nama: string;
  jenisKelamin: JenisKelamin;
  tempatLahir: string;
  tanggalLahir: string;
  agama: string;
  statusPerkawinan: string;
  pekerjaanId: string;
  pendidikanId: string;
  alamat: string;
  noKk: string;
  statusId: string;
  namaAyah: string;
  namaIbu: string;
};

export type KeluargaInput = {
  noKk: string;
  kepalaKeluarga: string;
  alamat: string;
  dusun: string;
  rt: string;
  rw: string;
  latitude: number | null;
  longitude: number | null;
  noListrik: string;
  fotoKk: string | null;
  fotoDepan: string | null;
  fotoDalam: string | null;
  fotoKamarMandi: string | null;
  fotoLokasi: string | null;
};

export type Ability =
  | "penduduk.write"
  | "keluarga.write"
  | "mutasi.write"
  | "surat.write"
  | "master.write"
  | "user.write"
  | "backup.restore";
