import type { Audit, Keluarga, KelompokUsia, Master, Mutasi, Penduduk, Surat, User } from "./types";
import { KELOMPOK_USIA } from "./logic";

export const PEKERJAAN: Master[] = [
  { id: "pk-petani", nama: "Petani" },
  { id: "pk-dagang", nama: "Pedagang" },
  { id: "pk-pns", nama: "PNS" },
  { id: "pk-tni", nama: "TNI/Polri" },
  { id: "pk-guru", nama: "Guru" },
  { id: "pk-perawat", nama: "Perawat" },
  { id: "pk-swasta", nama: "Karyawan Swasta" },
  { id: "pk-buruh", nama: "Buruh" },
  { id: "pk-pensiun", nama: "Pensiunan" },
  { id: "pk-mahasiswa", nama: "Mahasiswa" },
  { id: "pk-pelajar", nama: "Pelajar" },
  { id: "pk-irt", nama: "Ibu Rumah Tangga" },
  { id: "pk-tidak", nama: "Tidak Bekerja" },
  { id: "pk-lain", nama: "Lainnya" },
];

export const PENDIDIKAN: Master[] = [
  { id: "pd-tidak", nama: "Tidak Sekolah" },
  { id: "pd-sd", nama: "SD/Sederajat" },
  { id: "pd-smp", nama: "SMP/Sederajat" },
  { id: "pd-sma", nama: "SMA/SMK/Sederajat" },
  { id: "pd-d3", nama: "Diploma III" },
  { id: "pd-s1", nama: "Diploma IV/S1" },
  { id: "pd-s2", nama: "S2" },
  { id: "pd-s3", nama: "S3" },
];

export const STATUS_KELUARGA: Master[] = [
  { id: "st-kk", nama: "Kepala Keluarga" },
  { id: "st-istri", nama: "Istri" },
  { id: "st-anak", nama: "Anak" },
  { id: "st-menantu", nama: "Menantu" },
  { id: "st-cucu", nama: "Cucu" },
  { id: "st-ortu", nama: "Orang Tua" },
  { id: "st-mertua", nama: "Mertua" },
  { id: "st-famili", nama: "Famili Lain" },
  { id: "st-pembantu", nama: "Pembantu" },
  { id: "st-lain", nama: "Lainnya" },
];

const T = "2026-01-12T02:00:00.000Z";

function kk(
  id: string,
  noKk: string,
  kepala: string,
  dusun: string,
  rt: string,
  rw: string,
  alamat: string,
  lat: number,
  lng: number,
  noListrik = "",
): Keluarga {
  return {
    id,
    noKk,
    kepalaKeluarga: kepala,
    alamat,
    dusun,
    rt,
    rw,
    latitude: lat,
    longitude: lng,
    noListrik,
    fotoKk: null,
    fotoDepan: null,
    fotoDalam: null,
    fotoKamarMandi: null,
    fotoLokasi: null,
    createdAt: T,
  };
}

export const KELUARGA_AWAL: Keluarga[] = [
  kk("kk1", "3524120000001001", "Sarman", "Monongo", "01", "01", "Kampung Kulon", -7.1092, 112.3314, "541100220011"),
  kk("kk2", "3524120000001002", "Sarmin", "Monongo", "02", "01", "Kampung Wetan", -7.1084, 112.3326, "541100220028"),
  kk("kk3", "3524120000001003", "Arman", "Krajan", "01", "02", "Jl. Balai Desa", -7.1128, 112.336, "541100220035"),
  kk("kk4", "3524120000001004", "Sutrisno", "Krajan", "02", "02", "Gang Melati", -7.1136, 112.3371, "541100220042"),
  kk("kk5", "3524120000001005", "Ahmad Fauzi", "Sumberrejo", "01", "03", "Blok Sawah Lor", -7.1064, 112.3275, "541100330017"),
  kk("kk6", "3524120000001006", "Joko Santoso", "Sumberrejo", "02", "03", "Blok Sawah Kidul", -7.1055, 112.3284, "541100330024"),
  kk("kk7", "3524120000001007", "Sutini", "Monongo", "03", "01", "Kampung Kauman", -7.1101, 112.3302, "541100220059"),
  kk("kk8", "3524120000001008", "Eko Prasetyo", "Krajan", "03", "02", "Gang Kenanga", -7.1142, 112.3352, "541100220066"),
];

function w(
  id: string,
  nik: string,
  nama: string,
  jk: "L" | "P",
  lahir: string,
  tempat: string,
  agama: string,
  kawin: string,
  kerja: string,
  didik: string,
  noKk: string,
  status: string,
  ayah: string,
  ibu: string,
  hidup: Penduduk["statusHidup"] = "aktif",
): Penduduk {
  const keluarga = KELUARGA_AWAL.find((k) => k.noKk === noKk);
  return {
    id,
    nik,
    nama,
    jenisKelamin: jk,
    tempatLahir: tempat,
    tanggalLahir: lahir,
    agama,
    statusPerkawinan: kawin,
    pekerjaanId: kerja,
    pendidikanId: didik,
    alamat: keluarga?.alamat ?? "",
    noKk,
    statusId: status,
    namaAyah: ayah,
    namaIbu: ibu,
    statusHidup: hidup,
    createdAt: T,
  };
}

export const PENDUDUK_AWAL: Penduduk[] = [
  w("p1", "3524121403780001", "Sarman", "L", "1978-03-14", "Lamongan", "Islam", "Kawin", "pk-petani", "pd-sma", "3524120000001001", "st-kk", "Karman", "Tuminah"),
  w("p2", "3524126107820002", "Siti Aminah", "P", "1982-07-21", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-smp", "3524120000001001", "st-istri", "Darmo", "Painem"),
  w("p3", "3524120211080003", "Andi Pratama", "L", "2008-11-02", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sma", "3524120000001001", "st-anak", "Sarman", "Siti Aminah"),
  w("p4", "3524125804120004", "Rina Aulia", "P", "2012-04-18", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-smp", "3524120000001001", "st-anak", "Sarman", "Siti Aminah"),
  w("p5", "3524120909160005", "Bagas Saputra", "L", "2016-09-09", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001001", "st-anak", "Sarman", "Siti Aminah"),
  w("p6", "3524123001750006", "Sarmin", "L", "1975-01-30", "Lamongan", "Islam", "Kawin", "pk-dagang", "pd-sma", "3524120000001002", "st-kk", "Sarju", "Tinah"),
  w("p7", "3524124512790007", "Murni", "P", "1979-12-05", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sd", "3524120000001002", "st-istri", "Karto", "Siyem"),
  w("p8", "3524126206040008", "Dewi Lestari", "P", "2004-06-22", "Lamongan", "Islam", "Belum Kawin", "pk-mahasiswa", "pd-sma", "3524120000001002", "st-anak", "Sarmin", "Murni"),
  w("p9", "3524121105880009", "Arman", "L", "1988-05-11", "Surabaya", "Islam", "Kawin", "pk-swasta", "pd-sma", "3524120000001003", "st-kk", "Rahman", "Ginem"),
  w("p10", "3524126802900010", "Lestari", "P", "1990-02-28", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sma", "3524120000001003", "st-istri", "Sukardi", "Waginem"),
  w("p11", "3524125408190011", "Nisa Amalia", "P", "2019-08-14", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001003", "st-anak", "Arman", "Lestari"),
  w("p12", "3524122001230012", "Rafa Ardian", "L", "2023-01-20", "Lamongan", "Islam", "Belum Kawin", "pk-tidak", "pd-tidak", "3524120000001003", "st-anak", "Arman", "Lestari"),
  w("p13", "3524120810520013", "Sutrisno", "L", "1952-10-08", "Lamongan", "Islam", "Kawin", "pk-pensiun", "pd-sma", "3524120000001004", "st-kk", "Rekso Diharjo", "Sutiyah"),
  w("p14", "3524125903550014", "Paini", "P", "1955-03-19", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sd", "3524120000001004", "st-istri", "Darmin", "Kasemi"),
  w("p15", "3524121102380015", "Rekso Diharjo", "L", "1938-02-11", "Lamongan", "Islam", "Kawin", "pk-tidak", "pd-tidak", "3524120000001004", "st-ortu", "Kartodikromo", "Minem", "meninggal"),
  w("p16", "3524120209840016", "Ahmad Fauzi", "L", "1984-09-02", "Lamongan", "Islam", "Kawin", "pk-pns", "pd-s1", "3524120000001005", "st-kk", "Hadi", "Rumini"),
  w("p17", "3524126711860017", "Yuni Kartika", "P", "1986-11-27", "Gresik", "Islam", "Kawin", "pk-guru", "pd-s1", "3524120000001005", "st-istri", "Suprapto", "Endang"),
  w("p18", "3524120605140018", "Farhan Aziz", "L", "2014-05-06", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001005", "st-anak", "Ahmad Fauzi", "Yuni Kartika"),
  w("p19", "3524127012170019", "Aisyah Nur", "P", "2017-12-30", "Lamongan", "Islam", "Belum Kawin", "pk-pelajar", "pd-sd", "3524120000001005", "st-anak", "Ahmad Fauzi", "Yuni Kartika"),
  w("p20", "3524121504920020", "Joko Santoso", "L", "1992-04-15", "Lamongan", "Islam", "Kawin", "pk-buruh", "pd-smp", "3524120000001006", "st-kk", "Santoso", "Parti"),
  w("p21", "3524124908940021", "Wati", "P", "1994-08-09", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-smp", "3524120000001006", "st-istri", "Slamet", "Tumi"),
  w("p22", "3524120202210022", "Dimas Putra", "L", "2021-02-02", "Lamongan", "Islam", "Belum Kawin", "pk-tidak", "pd-tidak", "3524120000001006", "st-anak", "Joko Santoso", "Wati"),
  w("p23", "3524120303960023", "Budi Santoso", "L", "1996-03-03", "Lamongan", "Islam", "Belum Kawin", "pk-buruh", "pd-smp", "3524120000001006", "st-famili", "Santoso", "Parti", "pindah"),
  w("p24", "3524125206480024", "Sutini", "P", "1948-06-12", "Lamongan", "Islam", "Cerai Mati", "pk-tidak", "pd-tidak", "3524120000001007", "st-kk", "Kasan", "Sipon"),
  w("p25", "3524120707980025", "Eko Prasetyo", "L", "1998-07-07", "Lamongan", "Islam", "Kawin", "pk-petani", "pd-sma", "3524120000001008", "st-kk", "Prasetyo", "Sulastri"),
  w("p26", "3524126501000026", "Nur Halimah", "P", "2000-01-25", "Lamongan", "Islam", "Kawin", "pk-irt", "pd-sma", "3524120000001008", "st-istri", "Halim", "Musringah"),
  w("p27", "3524121209260027", "Ahmad Raihan", "L", "2026-09-12", "Lamongan", "Islam", "Belum Kawin", "pk-tidak", "pd-tidak", "3524120000001008", "st-anak", "Eko Prasetyo", "Nur Halimah"),
];

export const MUTASI_AWAL: Mutasi[] = [
  {
    id: "m1",
    jenis: "meninggal",
    nik: "3524121102380015",
    nama: "Rekso Diharjo",
    tanggal: "2026-06-15",
    keterangan: "Meninggal di rumah, Dusun Krajan.",
    noKk: "3524120000001004",
    actor: "Tajid",
    createdAt: "2026-06-15T04:00:00.000Z",
  },
  {
    id: "m2",
    jenis: "pindah_keluar",
    nik: "3524120303960023",
    nama: "Budi Santoso",
    tanggal: "2026-08-02",
    keterangan: "Pindah ke Desa Sukodadi karena kerja.",
    noKk: "3524120000001006",
    actor: "Tajid",
    createdAt: "2026-08-02T04:00:00.000Z",
  },
  {
    id: "m3",
    jenis: "lahir",
    nik: "3524121209260027",
    nama: "Ahmad Raihan",
    tanggal: "2026-09-12",
    keterangan: "Lahir di Puskesmas Sukodadi. Anak dari Eko Prasetyo dan Nur Halimah.",
    noKk: "3524120000001008",
    actor: "Tajid",
    createdAt: "2026-09-12T03:30:00.000Z",
  },
];

export const SURAT_AWAL: Surat[] = [
  {
    id: "s1",
    nomor: "001/SKD/IX/2026",
    jenis: "domisili",
    nik: "3524121403780001",
    nama: "Sarman",
    keperluan: "pengurusan kepesertaan BPJS Kesehatan",
    tanggal: "2026-09-04",
    actor: "Kepala Desa Monongo",
    createdAt: "2026-09-04T02:00:00.000Z",
  },
  {
    id: "s2",
    nomor: "002/SKTM/IX/2026",
    jenis: "tidak_mampu",
    nik: "3524121504920020",
    nama: "Joko Santoso",
    keperluan: "pengajuan keringanan biaya sekolah anak",
    tanggal: "2026-09-18",
    actor: "Kepala Desa Monongo",
    createdAt: "2026-09-18T02:10:00.000Z",
  },
];

export const USERS_AWAL: User[] = [
  {
    id: "u-admin",
    username: "admin",
    password: "monongo",
    nama: "Admin Desa",
    email: "admin@monongo.desa.id",
    noHp: "083846776155",
    alamat: "Balai Desa Monongo",
    role: "admin",
  },
  {
    id: "u-petugas",
    username: "petugas",
    password: "monongo",
    nama: "Tajid",
    email: "tajid@monongo.desa.id",
    noHp: "083846776155",
    alamat: "Dusun Monongo, Sukodadi",
    role: "petugas",
  },
  {
    id: "u-kepala",
    username: "kepala",
    password: "monongo",
    nama: "Kepala Desa Monongo",
    email: "kepala@monongo.desa.id",
    noHp: "081234567890",
    alamat: "Balai Desa Monongo",
    role: "kepala_desa",
  },
];

export const AUDIT_AWAL: Audit[] = [
  {
    id: "a1",
    waktu: "2026-09-18T02:10:00.000Z",
    actor: "Kepala Desa Monongo",
    aksi: "Terbit",
    entitas: "Surat",
    detail: "002/SKTM/IX/2026 atas nama Joko Santoso",
  },
  {
    id: "a2",
    waktu: "2026-09-12T03:30:00.000Z",
    actor: "Tajid",
    aksi: "Catat",
    entitas: "Mutasi",
    detail: "Kelahiran Ahmad Raihan",
  },
  {
    id: "a3",
    waktu: "2026-08-02T04:00:00.000Z",
    actor: "Tajid",
    aksi: "Catat",
    entitas: "Mutasi",
    detail: "Pindah keluar Budi Santoso",
  },
];

export type DataSlice = {
  users: User[];
  pekerjaan: Master[];
  pendidikan: Master[];
  statusKeluarga: Master[];
  keluarga: Keluarga[];
  penduduk: Penduduk[];
  mutasi: Mutasi[];
  surat: Surat[];
  audit: Audit[];
  suratSeq: number;
  kelompokUsia: KelompokUsia[];
};

export function dataContoh(): DataSlice {
  return {
    users: USERS_AWAL.map((u) => ({ ...u })),
    pekerjaan: PEKERJAAN.map((x) => ({ ...x })),
    pendidikan: PENDIDIKAN.map((x) => ({ ...x })),
    statusKeluarga: STATUS_KELUARGA.map((x) => ({ ...x })),
    keluarga: KELUARGA_AWAL.map((x) => ({ ...x })),
    penduduk: PENDUDUK_AWAL.map((x) => ({ ...x })),
    mutasi: MUTASI_AWAL.map((x) => ({ ...x })),
    surat: SURAT_AWAL.map((x) => ({ ...x })),
    audit: AUDIT_AWAL.map((x) => ({ ...x })),
    suratSeq: 2,
    kelompokUsia: KELOMPOK_USIA.map((x) => ({ ...x })),
  };
}

export function lengkapi(raw: Partial<DataSlice> | null | undefined): DataSlice {
  const dasar = dataContoh();
  if (!raw || !Array.isArray(raw.penduduk) || !Array.isArray(raw.users)) return dasar;
  return {
    users: raw.users.length ? raw.users : dasar.users,
    pekerjaan: raw.pekerjaan ?? dasar.pekerjaan,
    pendidikan: raw.pendidikan ?? dasar.pendidikan,
    statusKeluarga: raw.statusKeluarga ?? dasar.statusKeluarga,
    keluarga: (raw.keluarga ?? []).map((k) => ({
      ...k,
      latitude: k.latitude ?? null,
      longitude: k.longitude ?? null,
      noListrik: k.noListrik ?? "",
      fotoKk: k.fotoKk ?? null,
      fotoDepan: k.fotoDepan ?? null,
      fotoDalam: k.fotoDalam ?? null,
      fotoKamarMandi: k.fotoKamarMandi ?? null,
      fotoLokasi: k.fotoLokasi ?? null,
    })),
    penduduk: raw.penduduk,
    mutasi: raw.mutasi ?? [],
    surat: raw.surat ?? [],
    audit: raw.audit ?? [],
    suratSeq: typeof raw.suratSeq === "number" ? raw.suratSeq : 1,
    kelompokUsia: Array.isArray(raw.kelompokUsia) && raw.kelompokUsia.length ? raw.kelompokUsia : dasar.kelompokUsia,
  };
}
