import { createServerFn } from "@tanstack/react-start";
import type { DataSlice } from "./seed";

export type DokumenServer = { payload: DataSlice; revisi: number };

export const tarikSiduk = createServerFn({ method: "GET" }).handler(async (): Promise<DokumenServer> => {
  const { getSql } = await import("@/lib/db");
  const { dataContoh } = await import("./seed");
  const sql = await getSql();
  const ada = await sql<{ payload: DataSlice; revisi: number }>`
    select payload, revisi from siduk_dokumen where id = 'utama'
  `;
  if (ada[0]) return { payload: ada[0].payload, revisi: Number(ada[0].revisi) };
  const payload = dataContoh();
  await sql`
    insert into siduk_dokumen (id, payload, revisi)
    values ('utama', ${JSON.stringify(payload)}::jsonb, 1)
    on conflict (id) do nothing
  `;
  const lagi = await sql<{ payload: DataSlice; revisi: number }>`
    select payload, revisi from siduk_dokumen where id = 'utama'
  `;
  return { payload: lagi[0]?.payload ?? payload, revisi: Number(lagi[0]?.revisi ?? 1) };
});

export const simpanSiduk = createServerFn({ method: "POST" })
  .validator((input: { payload: DataSlice; revisi: number }) => {
    if (!input?.payload || typeof input.revisi !== "number") {
      throw new Error("Data tidak lengkap.");
    }
    return input;
  })
  .handler(async ({ data }): Promise<{ ok: true; revisi: number } | { ok: false; payload: DataSlice; revisi: number }> => {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const json = JSON.stringify(data.payload);
    const updated = await sql<{ revisi: number }>`
      update siduk_dokumen
      set payload = ${json}::jsonb, revisi = revisi + 1, updated_at = now()
      where id = 'utama' and revisi = ${data.revisi}
      returning revisi
    `;
    if (updated[0]) return { ok: true, revisi: Number(updated[0].revisi) };
    const current = await sql<{ payload: DataSlice; revisi: number }>`
      select payload, revisi from siduk_dokumen where id = 'utama'
    `;
    if (!current[0]) {
      await sql`
        insert into siduk_dokumen (id, payload, revisi)
        values ('utama', ${json}::jsonb, 1)
      `;
      return { ok: true, revisi: 1 };
    }
    return { ok: false, payload: current[0].payload, revisi: Number(current[0].revisi) };
  });
