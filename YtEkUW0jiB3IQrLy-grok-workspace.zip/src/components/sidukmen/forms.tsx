import { useState } from "react";
import { AGAMA, STATUS_KAWIN } from "@/lib/sidukmen/logic";
import { useSiduk } from "@/lib/sidukmen/store";
import type { KeluargaInput, PendudukInput } from "@/lib/sidukmen/types";
import { Btn, Field, Notice, control } from "./bits";
import { FotoBidang, SLOT_FOTO } from "./foto-bidang";
import { PanelGeotag } from "./lokasi";

export function PendudukForm({
  initial,
  submitLabel,
  onSubmit,
  onCancel,
}: {
  initial?: Partial<PendudukInput>;
  submitLabel: string;
  onSubmit: (input: PendudukInput) => string | null;
  onCancel: () => void;
}) {
  const keluarga = useSiduk((s) => s.keluarga);
  const pekerjaan = useSiduk((s) => s.pekerjaan);
  const pendidikan = useSiduk((s) => s.pendidikan);
  const statusKeluarga = useSiduk((s) => s.statusKeluarga);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<PendudukInput>({
    nik: initial?.nik ?? "",
    nama: initial?.nama ?? "",
    jenisKelamin: initial?.jenisKelamin ?? "L",
    tempatLahir: initial?.tempatLahir ?? "Lamongan",
    tanggalLahir: initial?.tanggalLahir ?? "",
    agama: initial?.agama ?? "Islam",
    statusPerkawinan: initial?.statusPerkawinan ?? "Belum Kawin",
    pekerjaanId: initial?.pekerjaanId ?? pekerjaan[0]?.id ?? "",
    pendidikanId: initial?.pendidikanId ?? pendidikan[0]?.id ?? "",
    alamat: initial?.alamat ?? "",
    noKk: initial?.noKk ?? "",
    statusId: initial?.statusId ?? statusKeluarga[0]?.id ?? "",
    namaAyah: initial?.namaAyah ?? "",
    namaIbu: initial?.namaIbu ?? "",
  });

  const set = (patch: Partial<PendudukInput>) => setForm((prev) => ({ ...prev, ...patch }));

  return (
    <form
      className="space-y-5"
      onSubmit={(event) => {
        event.preventDefault();
        const kk = keluarga.find((k) => k.noKk === form.noKk);
        const message = onSubmit({ ...form, alamat: kk?.alamat ?? form.alamat });
        setError(message);
      }}
    >
      {error ? <Notice>{error}</Notice> : null}
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Nomor KK" hint="Pilih kartu keluarga yang sudah terdaftar.">
          <select className={control} value={form.noKk} onChange={(e) => set({ noKk: e.target.value })} required>
            <option value="">Pilih KK</option>
            {keluarga.map((k) => (
              <option key={k.noKk} value={k.noKk}>
                {k.noKk} — {k.kepalaKeluarga}
              </option>
            ))}
          </select>
        </Field>
        <Field label="NIK" hint="16 digit. Kode wilayah contoh Lamongan diawali 3524.">
          <input className={control} inputMode="numeric" maxLength={16} value={form.nik} onChange={(e) => set({ nik: e.target.value.replace(/\D/g, "") })} required />
        </Field>
        <Field label="Nama lengkap">
          <input className={control} value={form.nama} onChange={(e) => set({ nama: e.target.value })} required />
        </Field>
        <Field label="Jenis kelamin">
          <select className={control} value={form.jenisKelamin} onChange={(e) => set({ jenisKelamin: e.target.value as "L" | "P" })}>
            <option value="L">Laki-laki</option>
            <option value="P">Perempuan</option>
          </select>
        </Field>
        <Field label="Tempat lahir">
          <input className={control} value={form.tempatLahir} onChange={(e) => set({ tempatLahir: e.target.value })} required />
        </Field>
        <Field label="Tanggal lahir">
          <input className={control} type="date" value={form.tanggalLahir} onChange={(e) => set({ tanggalLahir: e.target.value })} required />
        </Field>
        <Field label="Agama">
          <select className={control} value={form.agama} onChange={(e) => set({ agama: e.target.value })}>
            {AGAMA.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </Field>
        <Field label="Status perkawinan">
          <select className={control} value={form.statusPerkawinan} onChange={(e) => set({ statusPerkawinan: e.target.value })}>
            {STATUS_KAWIN.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </Field>
        <Field label="Pekerjaan">
          <select className={control} value={form.pekerjaanId} onChange={(e) => set({ pekerjaanId: e.target.value })}>
            {pekerjaan.map((item) => (
              <option key={item.id} value={item.id}>
                {item.nama}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Pendidikan terakhir">
          <select className={control} value={form.pendidikanId} onChange={(e) => set({ pendidikanId: e.target.value })}>
            {pendidikan.map((item) => (
              <option key={item.id} value={item.id}>
                {item.nama}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Status dalam keluarga">
          <select className={control} value={form.statusId} onChange={(e) => set({ statusId: e.target.value })}>
            {statusKeluarga.map((item) => (
              <option key={item.id} value={item.id}>
                {item.nama}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Nama ayah">
          <input className={control} value={form.namaAyah} onChange={(e) => set({ namaAyah: e.target.value })} />
        </Field>
        <Field label="Nama ibu">
          <input className={control} value={form.namaIbu} onChange={(e) => set({ namaIbu: e.target.value })} />
        </Field>
      </div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Btn type="submit">{submitLabel}</Btn>
        <Btn type="button" variant="ghost" onClick={onCancel}>
          Batal
        </Btn>
      </div>
    </form>
  );
}

export function KeluargaForm({
  initial,
  submitLabel,
  onSubmit,
  onCancel,
}: {
  initial?: Partial<KeluargaInput>;
  submitLabel: string;
  onSubmit: (input: KeluargaInput) => string | null;
  onCancel: () => void;
}) {
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<KeluargaInput>({
    noKk: initial?.noKk ?? "",
    kepalaKeluarga: initial?.kepalaKeluarga ?? "",
    alamat: initial?.alamat ?? "",
    dusun: initial?.dusun ?? "Monongo",
    rt: initial?.rt ?? "01",
    rw: initial?.rw ?? "01",
    latitude: initial?.latitude ?? null,
    longitude: initial?.longitude ?? null,
    noListrik: initial?.noListrik ?? "",
    fotoKk: initial?.fotoKk ?? null,
    fotoDepan: initial?.fotoDepan ?? null,
    fotoDalam: initial?.fotoDalam ?? null,
    fotoKamarMandi: initial?.fotoKamarMandi ?? null,
    fotoLokasi: initial?.fotoLokasi ?? null,
  });
  const set = (patch: Partial<KeluargaInput>) => setForm((prev) => ({ ...prev, ...patch }));

  return (
    <form
      className="space-y-5"
      onSubmit={(event) => {
        event.preventDefault();
        setError(onSubmit(form));
      }}
    >
      {error ? <Notice>{error}</Notice> : null}
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Nomor KK" hint="16 digit angka.">
          <input className={control} inputMode="numeric" maxLength={16} value={form.noKk} onChange={(e) => set({ noKk: e.target.value.replace(/\D/g, "") })} required />
        </Field>
        <Field label="Kepala keluarga">
          <input className={control} value={form.kepalaKeluarga} onChange={(e) => set({ kepalaKeluarga: e.target.value })} required />
        </Field>
        <Field label="Dusun">
          <input className={control} value={form.dusun} onChange={(e) => set({ dusun: e.target.value })} required />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="RT">
            <input className={control} value={form.rt} onChange={(e) => set({ rt: e.target.value })} required />
          </Field>
          <Field label="RW">
            <input className={control} value={form.rw} onChange={(e) => set({ rw: e.target.value })} required />
          </Field>
        </div>
        <Field label="Alamat" hint="Nama kampung atau gang, tanpa mengulang dusun.">
          <input className={control} value={form.alamat} onChange={(e) => set({ alamat: e.target.value })} required />
        </Field>
        <Field label="Nomor pelanggan listrik" hint="ID pelanggan PLN. Kosongkan jika belum ada sambungan.">
          <input
            className={control}
            inputMode="numeric"
            maxLength={20}
            value={form.noListrik}
            onChange={(e) => set({ noListrik: e.target.value.replace(/\D/g, "") })}
          />
        </Field>
        <Field label="Lintang" hint="Kosongkan jika belum diukur.">
          <input
            className={control}
            inputMode="decimal"
            value={form.latitude ?? ""}
            onChange={(e) => set({ latitude: e.target.value === "" ? null : Number(e.target.value) })}
          />
        </Field>
        <Field label="Bujur">
          <input
            className={control}
            inputMode="decimal"
            value={form.longitude ?? ""}
            onChange={(e) => set({ longitude: e.target.value === "" ? null : Number(e.target.value) })}
          />
        </Field>
      </div>
      <PanelGeotag
        latitude={form.latitude}
        longitude={form.longitude}
        pesanSukses="Koordinat terisi. Tekan simpan agar tercatat."
        onSimpan={(titik) => {
          set(titik);
          return null;
        }}
      />
      <div className="grid gap-3 sm:grid-cols-2">
        {SLOT_FOTO.map((slot) => (
          <FotoBidang
            key={slot.key}
            label={slot.label}
            hint={slot.hint}
            geotag={slot.geotag}
            src={form[slot.key]}
            onChange={(dataUrl, titik) =>
              set({
                [slot.key]: dataUrl,
                ...(slot.geotag && titik ? { latitude: titik.latitude, longitude: titik.longitude } : {}),
              })
            }
          />
        ))}
      </div>
      {form.latitude != null && form.longitude != null ? (
        <p className="text-sm text-stone tabular-nums">
          Koordinat rumah: {form.latitude}, {form.longitude}
        </p>
      ) : null}
      <Btn type="button" variant="ghost" onClick={() => set({ latitude: -7.1098, longitude: 112.333 })}>
        Isi titik perkiraan Desa Monongo
      </Btn>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Btn type="submit">{submitLabel}</Btn>
        <Btn type="button" variant="ghost" onClick={onCancel}>
          Batal
        </Btn>
      </div>
    </form>
  );
}
