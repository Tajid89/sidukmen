import { useRef, useState } from "react";
import { Camera, ImagePlus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { bacaGpsExif, kompresGambar, lokasiPerangkat, type Titik } from "@/lib/sidukmen/foto";
import type { KeluargaInput } from "@/lib/sidukmen/types";
import { Btn, Modal } from "./bits";

export const SLOT_FOTO: { key: keyof Pick<KeluargaInput, "fotoKk" | "fotoDepan" | "fotoDalam" | "fotoKamarMandi" | "fotoLokasi">; label: string; hint: string; geotag?: boolean }[] = [
  { key: "fotoKk", label: "Foto KK", hint: "Halaman kartu keluarga, usahakan tulisan terbaca." },
  { key: "fotoDepan", label: "Depan rumah", hint: "Tampak muka rumah dari jalan." },
  { key: "fotoDalam", label: "Dalam rumah", hint: "Ruang utama di dalam rumah." },
  { key: "fotoKamarMandi", label: "Kamar mandi", hint: "Kondisi kamar mandi." },
  { key: "fotoLokasi", label: "Foto lokasi", hint: "Ambil di depan rumah. Koordinat dibaca dari foto, atau dari GPS perangkat.", geotag: true },
];

export function FotoBidang({
  label,
  hint,
  src,
  geotag,
  disabled,
  onChange,
}: {
  label: string;
  hint: string;
  src: string | null;
  geotag?: boolean;
  disabled?: boolean;
  onChange: (dataUrl: string | null, titik: Titik | null) => void;
}) {
  const kamera = useRef<HTMLInputElement>(null);
  const berkas = useRef<HTMLInputElement>(null);
  const [sibuk, setSibuk] = useState(false);
  const [lihat, setLihat] = useState(false);

  async function ambil(file: File | undefined) {
    if (!file) return;
    setSibuk(true);
    try {
      const dataUrl = await kompresGambar(file);
      let titik: Titik | null = null;
      if (geotag) {
        titik = (await bacaGpsExif(file)) ?? (await lokasiPerangkat());
        if (!titik) toast.message("Foto tersimpan, koordinat belum terbaca. Izinkan lokasi, atau isi lintang dan bujur.");
      }
      onChange(dataUrl, titik);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Gambar gagal diproses.");
    } finally {
      setSibuk(false);
    }
  }

  return (
    <div className="rounded-xl border border-line bg-paper p-3">
      <p className="text-sm font-semibold">{label}</p>
      <p className="mt-0.5 text-xs leading-5 text-stone">{hint}</p>
      {src ? (
        <button type="button" className="mt-3 block w-full" onClick={() => setLihat(true)} aria-label={`Lihat ${label}`}>
          <img src={src} alt={label} className="h-40 w-full rounded-lg object-cover" />
        </button>
      ) : (
        <div className="mt-3 grid h-40 place-items-center rounded-lg border border-dashed border-line text-sm text-stone">
          Belum ada foto
        </div>
      )}
      {disabled ? null : (
        <div className="mt-3 flex flex-wrap gap-2">
          <Btn type="button" variant="ghost" disabled={sibuk} onClick={() => kamera.current?.click()}>
            <Camera className="size-4" />
            {sibuk ? "Memproses…" : "Kamera"}
          </Btn>
          <Btn type="button" variant="ghost" disabled={sibuk} onClick={() => berkas.current?.click()}>
            <ImagePlus className="size-4" />
            Berkas
          </Btn>
          {src ? (
            <Btn type="button" variant="ghost" disabled={sibuk} onClick={() => onChange(null, null)}>
              <Trash2 className="size-4" />
              Hapus
            </Btn>
          ) : null}
        </div>
      )}
      <input
        ref={kamera}
        className="hidden"
        type="file"
        accept="image/*"
        capture="environment"
        onChange={(event) => {
          void ambil(event.target.files?.[0]);
          event.target.value = "";
        }}
      />
      <input
        ref={berkas}
        className="hidden"
        type="file"
        accept="image/*"
        onChange={(event) => {
          void ambil(event.target.files?.[0]);
          event.target.value = "";
        }}
      />
      <Modal open={lihat && !!src} title={label} onClose={() => setLihat(false)}>
        {src ? <img src={src} alt={label} className="max-h-[70vh] w-full object-contain" /> : null}
      </Modal>
    </div>
  );
}
