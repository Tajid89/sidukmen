import { Link } from "@tanstack/react-router";

export function PetaTitik({
  titik,
}: {
  titik: { id: string; nama: string; lat: number; lng: number; meta: string }[];
}) {
  if (titik.length === 0) {
    return <p className="text-sm text-stone">Belum ada kartu keluarga yang punya koordinat.</p>;
  }
  const lats = titik.map((t) => t.lat);
  const lngs = titik.map((t) => t.lng);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);
  const padLat = Math.max((maxLat - minLat) * 0.18, 0.0012);
  const padLng = Math.max((maxLng - minLng) * 0.18, 0.0012);
  const x = (lng: number) => ((lng - (minLng - padLng)) / (maxLng - minLng + padLng * 2)) * 100;
  const y = (lat: number) => ((maxLat + padLat - lat) / (maxLat - minLat + padLat * 2)) * 100;

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_16rem]">
      <div className="relative h-72 overflow-hidden rounded-lg border border-line bg-paper">
        <div className="pointer-events-none absolute inset-0" aria-hidden="true">
          {Array.from({ length: 4 }, (_, i) => (
            <div key={`h${i}`} className="absolute right-0 left-0 border-t border-line" style={{ top: `${(i + 1) * 20}%` }} />
          ))}
          {Array.from({ length: 5 }, (_, i) => (
            <div key={`v${i}`} className="absolute top-0 bottom-0 border-l border-line" style={{ left: `${(i + 1) * 16}%` }} />
          ))}
        </div>
        {titik.map((item, index) => (
          <Link
            key={item.id}
            to="/keluarga/$noKk"
            params={{ noKk: item.id }}
            className="absolute z-10 grid size-11 -translate-x-1/2 -translate-y-1/2 place-items-center"
            style={{ left: `${x(item.lng)}%`, top: `${y(item.lat)}%` }}
            title={`${item.nama}, Dusun ${item.meta}`}
            aria-label={`${item.nama}, Dusun ${item.meta}`}
          >
            <span className="grid size-6 place-items-center rounded-full bg-brand text-[11px] font-semibold text-paper">{index + 1}</span>
          </Link>
        ))}
      </div>
      <ol className="max-h-72 space-y-1 overflow-auto text-sm">
        {titik.map((item, index) => (
          <li key={item.id}>
            <Link to="/keluarga/$noKk" params={{ noKk: item.id }} className="flex items-baseline gap-2 rounded-md px-1 py-1 hover:bg-paper">
              <span className="w-5 font-semibold text-brand tabular-nums">{index + 1}</span>
              <span>
                <span className="font-semibold">{item.nama}</span>
                <span className="block text-xs text-stone">Dusun {item.meta}</span>
              </span>
            </Link>
          </li>
        ))}
      </ol>
    </div>
  );
}
