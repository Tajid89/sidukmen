import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  ArrowLeftRight,
  BarChart3,
  CircleUser,
  Database,
  History,
  House,
  LayoutDashboard,
  LogOut,
  Menu,
  Search,
  UserCog,
  Users,
  X,
} from "lucide-react";
import { DESA, ROLE_LABEL, can } from "@/lib/sidukmen/logic";
import { useSiduk, type SidukState } from "@/lib/sidukmen/store";
import type { Ability, User } from "@/lib/sidukmen/types";

const NAV: { to: "/dasbor" | "/penduduk" | "/keluarga" | "/mutasi" | "/laporan" | "/master" | "/pengguna" | "/jejak" | "/profil"; label: string; icon: typeof Users; ability?: Ability; exact?: boolean }[] = [
  { to: "/dasbor", label: "Dasbor", icon: LayoutDashboard, exact: true },
  { to: "/penduduk", label: "Penduduk", icon: Users },
  { to: "/keluarga", label: "Keluarga", icon: House },
  { to: "/mutasi", label: "Mutasi", icon: ArrowLeftRight },
  { to: "/laporan", label: "Laporan", icon: BarChart3 },
  { to: "/master", label: "Master data", icon: Database, ability: "master.write" },
  { to: "/pengguna", label: "Pengguna", icon: UserCog, ability: "user.write" },
  { to: "/jejak", label: "Jejak perubahan", icon: History },
  { to: "/profil", label: "Profil", icon: CircleUser },
];

export function Shell({ title, user, action, children }: { title: string; user: User; action?: ReactNode; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const penduduk = useSiduk((s) => s.penduduk);
  const logout = useSiduk((s) => s.logout);
  const navigate = useNavigate();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const hits = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    return penduduk
      .filter((p) => p.nama.toLowerCase().includes(q) || p.nik.includes(q))
      .slice(0, 6);
  }, [penduduk, query]);

  const items = NAV.filter((item) => !item.ability || can(user.role, item.ability));

  return (
    <div className="min-h-screen md:grid md:grid-cols-[16.5rem_minmax(0,1fr)]">
      <aside className="no-print hidden border-r border-line bg-sheet text-ink md:flex md:flex-col">
        <Brand />
        <Nav items={items} pathname={pathname} />
        <Account user={user} onLogout={() => logout()} />
      </aside>
      {open ? (
        <div className="no-print fixed inset-0 z-40 md:hidden">
          <button className="absolute inset-0 bg-ink/40" aria-label="Tutup menu" onClick={() => setOpen(false)} />
          <div className="relative flex h-full w-[18rem] max-w-[86vw] flex-col border-r border-line bg-sheet text-ink">
            <div className="flex items-center justify-between pr-3">
              <Brand />
              <button type="button" className="grid size-11 place-items-center" onClick={() => setOpen(false)} aria-label="Tutup">
                <X className="size-5" />
              </button>
            </div>
            <Nav items={items} pathname={pathname} />
            <Account user={user} onLogout={() => logout()} />
          </div>
        </div>
      ) : null}
      <div className="min-w-0">
        <header className="no-print sticky top-0 z-30 border-b border-line bg-paper/95 px-4 py-3 backdrop-blur md:px-8">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="grid size-11 place-items-center rounded-lg border border-line bg-sheet md:hidden"
              onClick={() => setOpen(true)}
              aria-label="Buka menu"
            >
              <Menu className="size-5" />
            </button>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold tracking-wide text-stone uppercase">Desa {DESA.nama}</p>
              <h1 className="truncate font-display text-2xl text-ink">{title}</h1>
            </div>
            {action ? <div className="hidden sm:block">{action}</div> : null}
          </div>
          <div className="relative mt-3">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-stone" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Cari nama atau NIK"
              className="h-11 w-full rounded-lg border border-line bg-sheet pr-3 pl-10 text-base outline-none focus:border-brand"
              aria-label="Cari penduduk"
            />
            {query.trim().length >= 2 ? (
              <div className="absolute right-0 left-0 z-20 mt-1 overflow-hidden rounded-lg border border-line bg-sheet shadow-sm">
                {hits.length === 0 ? (
                  <p className="px-3 py-3 text-sm text-stone">Tidak ada penduduk yang cocok.</p>
                ) : (
                  hits.map((p) => (
                    <button
                      key={p.nik}
                      type="button"
                      className="block w-full px-3 py-3 text-left hover:bg-paper"
                      onClick={() => {
                        setQuery("");
                        navigate({ to: "/penduduk/$nik", params: { nik: p.nik } });
                      }}
                    >
                      <span className="block text-sm font-semibold">{p.nama}</span>
                      <span className="text-xs text-stone tabular-nums">{p.nik}</span>
                    </button>
                  ))
                )}
              </div>
            ) : null}
          </div>
          {action ? <div className="mt-3 sm:hidden">{action}</div> : null}
        </header>
        <main className="px-4 py-5 md:px-8 md:py-7">{children}</main>
      </div>
    </div>
  );
}

function Brand() {
  return (
    <div className="px-5 py-6">
      <p className="font-display text-xl font-semibold tracking-tight">SIDUKMEN</p>
      <p className="mt-1 text-sm text-stone">Kependudukan Desa {DESA.nama}</p>
    </div>
  );
}

function Nav({
  items,
  pathname,
}: {
  items: typeof NAV;
  pathname: string;
}) {
  return (
    <nav className="flex-1 space-y-1 overflow-auto px-3">
      {items.map((item) => {
        const active = item.exact ? pathname === item.to : pathname === item.to || pathname.startsWith(`${item.to}/`);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            className={`flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-semibold ${active ? "bg-brand text-white" : "text-ink hover:bg-paper"}`}
          >
            <Icon className="size-4 shrink-0" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

function Account({ user, onLogout }: { user: User; onLogout: () => void }) {
  return (
    <div className="border-t border-line px-4 py-4">
      <p className="truncate text-sm font-semibold">{user.nama}</p>
      <p className="text-xs text-stone">{ROLE_LABEL[user.role]}</p>
      <button type="button" className="mt-3 flex min-h-11 items-center gap-2 text-sm font-semibold" onClick={onLogout}>
        <LogOut className="size-4" />
        Keluar
      </button>
    </div>
  );
}

export function requireAbility(user: User, ability: Ability, state?: SidukState) {
  void state;
  return can(user.role, ability);
}
