import { useState } from "react";
import { MapPin } from "lucide-react";
import { toast } from "sonner";
import { ambilLokasi, type Titik } from "@/lib/sidukmen/foto";
import { Btn } from "./bits";

export function PanelGeotag({
  latitude,
  longitude,
  disabled,
  pesanSukses,
  onSimpan,
}: {
  latitude: number | null;
  longitude: number | null;
  disabled?: boolean;
  pesanSukses: string;
  onSimpan: (titik: Titik) => string | null;
}) {
  const [sibuk, setSibuk] = useState(false);
  const [akurasi, setAkurasi] = useState<number | null>(null);
  const siap = latitude != null && longitude != null;
  const peta = siap ? `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=18/${latitude}/${longitude}` : null;

  async function ambil() {
    setSibuk(true);
    const hasil = await ambilLokasi();
    setSibuk(false);
    if (!hasil.ok) {
      toast.error(hasil.pesan);
      return;
    }
    const err = onSimpan({ latitude: hasil.latitude, longitude: hasil.longitude });
    if (err) {
      toast.error(err);
      return;
    }
    setAkurasi(hasil.accuracy);
    toast.success(pesanSukses);
  }

  return (
    <section className="rounded-xl border border-line bg-sheet p-4">
      <h2 className="font-display text-xl">Geotagging</h2>
      <p className="mt-1 max-w-2xl text-sm text-stone">
        Ambil titik rumah dari GPS. Latitude dan longitude tersimpan pada kartu keluarga ini.
      </p>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-lg bg-paper px-3 py-3">
          <p className="text-xs font-semibold tracking-wide text-stone">Latitude</p>
          <p className="mt-1 font-display text-2xl tabular-nums">{siap ? latitude : "—"}</p>
          <p className="text-xs text-stone">Lintang</p>
        </div>
        <div className="rounded-lg bg-paper px-3 py-3">
          <p className="text-xs font-semibold tracking-wide text-stone">Longitude</p>
          <p className="mt-1 font-display text-2xl tabular-nums">{siap ? longitude : "—"}</p>
          <p className="text-xs text-stone">Bujur</p>
        </div>
      </div>
      {akurasi != null ? <p className="mt-3 text-sm text-stone">Akurasi perkiraan ±{akurasi} meter.</p> : null}
      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        {disabled ? null : (
          <Btn type="button" disabled={sibuk} onClick={() => void ambil()}>
            <MapPin className="size-4" />
            {sibuk ? "Mencari sinyal…" : "Ambil lokasi"}
          </Btn>
        )}
        {peta ? (
          <a className="inline-flex h-11 items-center justify-center rounded-lg border border-line bg-sheet px-4 text-sm font-semibold" href={peta} target="_blank" rel="noreferrer">
            Lihat titik di peta
          </a>
        ) : null}
      </div>
    </section>
  );
}
