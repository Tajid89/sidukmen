import { useEffect, useState, type ReactNode } from "react";
import { Outlet, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { DESA } from "@/lib/sidukmen/logic";
import { simpanSiduk, tarikSiduk } from "@/lib/sidukmen/remote";
import { lengkapi, type DataSlice } from "@/lib/sidukmen/seed";
import { bacaSesi, tulisSesi, useSiduk, useUser, type SidukState } from "@/lib/sidukmen/store";

function potong(state: SidukState): DataSlice {
  return {
    users: state.users,
    pekerjaan: state.pekerjaan,
    pendidikan: state.pendidikan,
    statusKeluarga: state.statusKeluarga,
    keluarga: state.keluarga,
    penduduk: state.penduduk,
    mutasi: state.mutasi,
    surat: state.surat,
    audit: state.audit,
    suratSeq: state.suratSeq,
    kelompokUsia: state.kelompokUsia,
  };
}

function bedaData(a: SidukState, b: SidukState): boolean {
  return (
    a.users !== b.users ||
    a.pekerjaan !== b.pekerjaan ||
    a.pendidikan !== b.pendidikan ||
    a.statusKeluarga !== b.statusKeluarga ||
    a.keluarga !== b.keluarga ||
    a.penduduk !== b.penduduk ||
    a.mutasi !== b.mutasi ||
    a.surat !== b.surat ||
    a.audit !== b.audit ||
    a.suratSeq !== b.suratSeq ||
    a.kelompokUsia !== b.kelompokUsia
  );
}

export function ClientGate({ children }: { children?: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [gagal, setGagal] = useState<string | null>(null);

  useEffect(() => {
    let batal = false;
    let revisi = 0;
    let diam = true;
    let sedang = false;
    let antri = false;
    let timer = 0;

    async function dorong() {
      if (sedang) {
        antri = true;
        return;
      }
      sedang = true;
      const payload = potong(useSiduk.getState());
      const punya = revisi;
      try {
        const hasil = await simpanSiduk({ data: { payload, revisi: punya } });
        if (batal) return;
        if (hasil.ok) {
          revisi = hasil.revisi;
        } else {
          revisi = hasil.revisi;
          const sesi = useSiduk.getState().session;
          diam = true;
          useSiduk.setState({ ...lengkapi(hasil.payload), session: sesi });
          diam = false;
          toast.message("Data di server lebih baru. Tampilan diselaraskan.");
        }
      } catch {
        if (!batal) toast.error("Gagal menyimpan ke database server.");
      } finally {
        sedang = false;
        if (antri && !batal) {
          antri = false;
          void dorong();
        }
      }
    }

    const lepas = useSiduk.subscribe((state, prev) => {
      if (diam || !bedaData(state, prev)) return;
      window.clearTimeout(timer);
      timer = window.setTimeout(() => void dorong(), 350);
    });

    tarikSiduk()
      .then((dokumen) => {
        if (batal) return;
        revisi = dokumen.revisi;
        const data = lengkapi(dokumen.payload);
        const sesi = bacaSesi();
        const session = sesi && data.users.some((user) => user.id === sesi.userId) ? sesi : null;
        if (!session) tulisSesi(null);
        diam = true;
        useSiduk.setState({ ...data, session });
        diam = false;
        setReady(true);
      })
      .catch(() => {
        if (!batal) setGagal("Database server belum siap. Muat ulang halaman.");
      });

    return () => {
      batal = true;
      lepas();
      window.clearTimeout(timer);
    };
  }, []);

  if (gagal) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center">
        <p className="font-display text-3xl text-brand">SIDUKMEN</p>
        <p className="max-w-sm text-sm text-stone">{gagal}</p>
      </div>
    );
  }
  if (!ready) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center">
        <p className="font-display text-3xl text-brand">SIDUKMEN</p>
        <p className="text-sm text-stone">Menghubungkan database Desa {DESA.nama}…</p>
      </div>
    );
  }
  return children ?? <Outlet />;
}

export function useSessionUser() {
  const user = useUser();
  const navigate = useNavigate();
  useEffect(() => {
    if (!user) navigate({ to: "/" });
  }, [user, navigate]);
  return user;
}
