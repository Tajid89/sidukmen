import { useEffect, type ButtonHTMLAttributes, type ReactNode } from "react";

export const control =
  "h-11 w-full rounded-lg border border-line bg-sheet px-3 text-base text-ink outline-none placeholder:text-sand focus:border-brand";

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-ink">{label}</span>
      {children}
      {hint ? <span className="mt-1 block text-xs leading-5 text-stone">{hint}</span> : null}
    </label>
  );
}

const VARIANTS = {
  primary: "bg-brand text-paper hover:bg-brandsoft",
  ghost: "border border-line bg-sheet text-ink hover:border-brand",
  danger: "bg-clay text-paper",
  quiet: "h-auto bg-transparent px-0 text-brand underline-offset-2 hover:underline",
} as const;

export function Btn({
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof VARIANTS }) {
  return (
    <button
      className={`inline-flex h-11 items-center justify-center gap-2 rounded-lg px-4 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50 ${VARIANTS[variant]} ${className}`}
      {...props}
    />
  );
}

export function Badge({
  tone = "stone",
  children,
}: {
  tone?: "stone" | "brand" | "clay" | "sand";
  children: ReactNode;
}) {
  const toneClass = {
    stone: "bg-paper text-stone",
    brand: "bg-brand text-paper",
    clay: "bg-clay text-paper",
    sand: "bg-sand text-ink",
  }[tone];
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${toneClass}`}>{children}</span>
  );
}

export function Modal({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="no-print fixed inset-0 z-50 flex items-end justify-center bg-ink/45 p-0 sm:items-center sm:p-4" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[92vh] w-full overflow-auto rounded-t-2xl border border-line bg-sheet p-5 sm:max-w-lg sm:rounded-2xl"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-4">
          <h2 className="font-display text-xl text-ink">{title}</h2>
          <button type="button" className="text-sm font-semibold text-stone" onClick={onClose}>
            Tutup
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Empty({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-dashed border-line bg-sheet px-4 py-10 text-center">
      <p className="font-display text-lg text-ink">{title}</p>
      <p className="mx-auto mt-1 max-w-md text-sm text-stone">{body}</p>
    </div>
  );
}

export function Stat({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <article className="rounded-xl border border-line bg-sheet px-4 py-4">
      <p className="text-xs font-semibold tracking-wide text-stone uppercase">{label}</p>
      <p className="mt-2 font-display text-3xl text-ink tabular-nums">{value}</p>
      {note ? <p className="mt-1 text-sm text-stone">{note}</p> : null}
    </article>
  );
}

export function Panel({ title, action, children }: { title: string; action?: ReactNode; children: ReactNode }) {
  return (
    <section className="rounded-xl border border-line bg-sheet">
      <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
        <h2 className="font-display text-lg text-ink">{title}</h2>
        {action}
      </header>
      <div className="p-4">{children}</div>
    </section>
  );
}

export function Notice({ children }: { children: ReactNode }) {
  return <p className="rounded-lg border border-line bg-paper px-3 py-2 text-sm text-clay">{children}</p>;
}
