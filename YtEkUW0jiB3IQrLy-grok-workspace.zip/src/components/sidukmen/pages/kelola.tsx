import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { useSessionUser } from "@/components/sidukmen/gate";
import { Badge, Btn, Empty, Field, Modal, Notice, Panel, Stat, control } from "@/components/sidukmen/bits";
import { Shell } from "@/components/sidukmen/shell";
import {
  DESA,
  MUTASI_LABEL,
  ROLE_LABEL,
  aktif,
  alamatKeluarga,
  angka,
  can,
  downloadText,
  formatTanggal,
  formatWaktu,
  hitungMaster,
  hitungTeks,
  kelompokUsia,
  persen,
  umur,
} from "@/lib/sidukmen/logic";
import { useSiduk } from "@/lib/sidukmen/store";
import type { DataSlice } from "@/lib/sidukmen/seed";
import type { KelompokUsia, Role, User } from "@/lib/sidukmen/types";

function Baris({ label, jumlah, total }: { label: string; jumlah: number; total: number }) {
  return (
    <li className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-3 border-b border-line py-2 text-sm">
      <span className="truncate">{label}</span>
      <span className="w-12 text-right font-semibold tabular-nums">{jumlah}</span>
      <span className="w-14 text-right text-stone tabular-nums">{persen(jumlah, total)}</span>
    </li>
  );
}

export function LaporanPage() {
  const user = useSessionUser();
  const penduduk = useSiduk((s) => s.penduduk);
  const keluarga = useSiduk((s) => s.keluarga);
  const pekerjaan = useSiduk((s) => s.pekerjaan);
  const pendidikan = useSiduk((s) => s.pendidikan);
  const statusKeluarga = useSiduk((s) => s.statusKeluarga);
  const mutasi = useSiduk((s) => s.mutasi);
  const pita = useSiduk((s) => s.kelompokUsia);
  if (!user) return null;
  const hidup = penduduk.filter(aktif);
  const laki = hidup.filter((p) => p.jenisKelamin === "L").length;
  const kerja = hitungMaster(penduduk, pekerjaan, (p) => p.pekerjaanId);
  const didik = hitungMaster(penduduk, pendidikan, (p) => p.pendidikanId);
  const status = hitungMaster(penduduk, statusKeluarga, (p) => p.statusId);
  const agama = hitungTeks(penduduk, (p) => p.agama);
  const kawin = hitungTeks(penduduk, (p) => p.statusPerkawinan);
  const usia = kelompokUsia(penduduk, pita);
  const kepalaId = statusKeluarga.find((item) => item.nama === "Kepala Keluarga")?.id;
  const kkPerempuan = hidup
    .filter((orang) => orang.jenisKelamin === "P" && kepalaId && orang.statusId === kepalaId)
    .map((orang) => ({ orang, kk: keluarga.find((item) => item.noKk === orang.noKk) }))
    .sort((a, b) => a.orang.nama.localeCompare(b.orang.nama, "id"));

  return (
    <Shell
      title="Laporan"
      user={user}
      action={
        <Btn onClick={() => window.print()}>Cetak</Btn>
      }
    >
      <article className="print-sheet space-y-4">
        <header className="rounded-xl border border-line bg-sheet px-4 py-4">
          <p className="text-xs font-semibold tracking-wide text-stone uppercase">Pemerintah Desa {DESA.nama}</p>
          <h2 className="font-display text-2xl">Laporan kependudukan</h2>
          <p className="text-sm text-stone">
            Kecamatan {DESA.kecamatan}, Kabupaten {DESA.kabupaten}. Dihitung dari penduduk aktif.
          </p>
        </header>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Stat label="Penduduk aktif" value={angka(hidup.length)} note={`${angka(laki)} laki-laki · ${angka(hidup.length - laki)} perempuan`} />
          <Stat label="Keluarga" value={angka(keluarga.length)} note="kartu keluarga" />
          <Stat label="KK perempuan" value={angka(kkPerempuan.length)} note="kepala keluarga" />
          <Stat label="Mutasi tercatat" value={angka(mutasi.length)} note="semua jenis" />
        </div>
        <Panel title="Perempuan sebagai kepala keluarga">
          <p className="mb-3 text-sm text-stone">
            Penduduk perempuan yang statusnya Kepala Keluarga. {angka(kkPerempuan.length)} dari {angka(keluarga.length)} kartu keluarga.
          </p>
          {kkPerempuan.length === 0 ? (
            <p className="text-sm text-stone">Belum ada perempuan yang tercatat sebagai kepala keluarga.</p>
          ) : (
            <ul className="divide-y divide-line">
              {kkPerempuan.map(({ orang, kk }) => (
                <li key={orang.nik}>
                  <Link to="/penduduk/$nik" params={{ nik: orang.nik }} className="block py-3 hover:text-brand">
                    <span className="block font-semibold">{orang.nama}</span>
                    <span className="mt-0.5 block text-sm text-stone">
                      NIK {orang.nik} · {umur(orang.tanggalLahir)} tahun · {orang.statusPerkawinan}
                    </span>
                    <span className="block text-sm text-stone">{kk ? alamatKeluarga(kk) : `No. KK ${orang.noKk}`}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Jenis kelamin">
            <ul>
              <Baris label="Laki-laki" jumlah={laki} total={hidup.length} />
              <Baris label="Perempuan" jumlah={hidup.length - laki} total={hidup.length} />
            </ul>
          </Panel>
          <Panel title="Kelompok usia">
            <ul>
              {usia.map((row) => (
                <Baris key={row.label} label={row.label} jumlah={row.jumlah} total={hidup.length} />
              ))}
            </ul>
          </Panel>
          <Panel title="Pekerjaan">
            <ul>
              {kerja.map((row) => (
                <Baris key={row.label} label={row.label} jumlah={row.jumlah} total={hidup.length} />
              ))}
            </ul>
          </Panel>
          <Panel title="Pendidikan">
            <ul>
              {didik.map((row) => (
                <Baris key={row.label} label={row.label} jumlah={row.jumlah} total={hidup.length} />
              ))}
            </ul>
          </Panel>
          <Panel title="Agama">
            <ul>
              {agama.map((row) => (
                <Baris key={row.label} label={row.label} jumlah={row.jumlah} total={hidup.length} />
              ))}
            </ul>
          </Panel>
          <Panel title="Perkawinan">
            <ul>
              {kawin.map((row) => (
                <Baris key={row.label} label={row.label} jumlah={row.jumlah} total={hidup.length} />
              ))}
            </ul>
          </Panel>
          <Panel title="Status dalam keluarga">
            <ul>
              {status.map((row) => (
                <Baris key={row.label} label={row.label} jumlah={row.jumlah} total={hidup.length} />
              ))}
            </ul>
          </Panel>
          <Panel title="Mutasi">
            <ul>
              {(Object.keys(MUTASI_LABEL) as (keyof typeof MUTASI_LABEL)[]).map((key) => (
                <Baris key={key} label={MUTASI_LABEL[key]} jumlah={mutasi.filter((m) => m.jenis === key).length} total={mutasi.length} />
              ))}
            </ul>
          </Panel>
        </div>
      </article>
    </Shell>
  );
}

const MASTER = [
  { kind: "pekerjaan" as const, title: "Pekerjaan" },
  { kind: "pendidikan" as const, title: "Pendidikan terakhir" },
  { kind: "statusKeluarga" as const, title: "Status dalam keluarga" },
];

export function MasterPage() {
  const user = useSessionUser();
  const pekerjaan = useSiduk((s) => s.pekerjaan);
  const pendidikan = useSiduk((s) => s.pendidikan);
  const statusKeluarga = useSiduk((s) => s.statusKeluarga);
  const addMaster = useSiduk((s) => s.addMaster);
  const renameMaster = useSiduk((s) => s.renameMaster);
  const deleteMaster = useSiduk((s) => s.deleteMaster);
  const lists = { pekerjaan, pendidikan, statusKeluarga };
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [edit, setEdit] = useState<{ kind: (typeof MASTER)[number]["kind"]; id: string; nama: string } | null>(null);
  if (!user) return null;
  if (!can(user.role, "master.write")) {
    return (
      <Shell title="Master data" user={user}>
        <Notice>Hanya admin dan petugas yang mengubah master data.</Notice>
      </Shell>
    );
  }

  return (
    <Shell title="Master data" user={user}>
      <div className="grid gap-4 xl:grid-cols-3">
        {MASTER.map((group) => (
          <Panel key={group.kind} title={group.title}>
            <form
              className="mb-3 flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                const err = addMaster(group.kind, draft[group.kind] ?? "");
                if (err) toast.error(err);
                else {
                  toast.success("Master ditambahkan");
                  setDraft((prev) => ({ ...prev, [group.kind]: "" }));
                }
              }}
            >
              <input
                className={control}
                placeholder="Nama baru"
                value={draft[group.kind] ?? ""}
                onChange={(e) => setDraft((prev) => ({ ...prev, [group.kind]: e.target.value }))}
                aria-label={`Tambah ${group.title}`}
              />
              <Btn type="submit">Tambah</Btn>
            </form>
            <ul className="divide-y divide-line">
              {lists[group.kind].map((item) => (
                <li key={item.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                  <span>{item.nama}</span>
                  <span className="flex gap-3">
                    <button type="button" className="font-semibold text-brand" onClick={() => setEdit({ kind: group.kind, id: item.id, nama: item.nama })}>
                      Ubah
                    </button>
                    <button
                      type="button"
                      className="font-semibold text-clay"
                      onClick={() => {
                        const err = deleteMaster(group.kind, item.id);
                        if (err) toast.error(err);
                        else toast.success("Dihapus");
                      }}
                    >
                      Hapus
                    </button>
                  </span>
                </li>
              ))}
            </ul>
          </Panel>
        ))}
      </div>
      <RentangUmur />
      <Modal
        open={!!edit}
        title="Ubah nama"
        onClose={() => setEdit(null)}
      >
        {edit ? (
          <form
            className="space-y-4"
            onSubmit={(event) => {
              event.preventDefault();
              const err = renameMaster(edit.kind, edit.id, edit.nama);
              if (err) toast.error(err);
              else {
                toast.success("Nama diperbarui");
                setEdit(null);
              }
            }}
          >
            <Field label="Nama">
              <input className={control} value={edit.nama} onChange={(e) => setEdit({ ...edit, nama: e.target.value })} required />
            </Field>
            <Btn type="submit">Simpan</Btn>
          </form>
        ) : null}
      </Modal>
    </Shell>
  );
}

function RentangUmur() {
  const tersimpan = useSiduk((s) => s.kelompokUsia);
  const simpanKelompok = useSiduk((s) => s.simpanKelompok);
  const [rows, setRows] = useState<KelompokUsia[]>(tersimpan);

  useEffect(() => {
    setRows(tersimpan);
  }, [tersimpan]);

  function setBaris(id: string, patch: Partial<KelompokUsia>) {
    setRows((prev) => prev.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  }

  return (
    <Panel title="Kelompok umur">
      <p className="mb-3 text-sm text-stone">Sesuaikan nama dan rentang tahun. Kelompok tidak boleh saling tumpang tindih. Dasbor dan laporan mengikuti pengaturan ini.</p>
      <ul className="space-y-2">
        {rows.map((row) => (
          <li key={row.id} className="grid gap-2 sm:grid-cols-[minmax(0,1.4fr)_5rem_5rem_auto]">
            <input className={control} aria-label="Nama kelompok" value={row.label} onChange={(e) => setBaris(row.id, { label: e.target.value })} />
            <input
              className={control}
              aria-label="Umur minimum"
              inputMode="numeric"
              value={row.min}
              onChange={(e) => setBaris(row.id, { min: Number(e.target.value.replace(/\D/g, "") || 0) })}
            />
            <input
              className={control}
              aria-label="Umur maksimum"
              inputMode="numeric"
              value={row.max}
              onChange={(e) => setBaris(row.id, { max: Number(e.target.value.replace(/\D/g, "") || 0) })}
            />
            <Btn
              type="button"
              variant="ghost"
              disabled={rows.length < 2}
              onClick={() => setRows((prev) => prev.filter((item) => item.id !== row.id))}
            >
              Hapus
            </Btn>
          </li>
        ))}
      </ul>
      <div className="mt-3 flex flex-col gap-2 sm:flex-row">
        <Btn
          type="button"
          variant="ghost"
          onClick={() => setRows((prev) => [...prev, { id: crypto.randomUUID(), label: "", min: 0, max: 0 }])}
        >
          Tambah rentang
        </Btn>
        <Btn
          type="button"
          onClick={() => {
            const err = simpanKelompok(rows);
            if (err) toast.error(err);
            else toast.success("Kelompok umur disimpan");
          }}
        >
          Simpan rentang
        </Btn>
      </div>
    </Panel>
  );
}

const EMPTY_USER = {
  username: "",
  password: "",
  nama: "",
  email: "",
  noHp: "",
  alamat: "",
  role: "petugas" as Role,
};

export function PenggunaPage() {
  const user = useSessionUser();
  const users = useSiduk((s) => s.users);
  const addUser = useSiduk((s) => s.addUser);
  const updateUser = useSiduk((s) => s.updateUser);
  const deleteUser = useSiduk((s) => s.deleteUser);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_USER);
  const [error, setError] = useState<string | null>(null);
  if (!user) return null;
  if (!can(user.role, "user.write")) {
    return (
      <Shell title="Pengguna" user={user}>
        <Notice>Hanya admin yang mengelola pengguna.</Notice>
      </Shell>
    );
  }

  function bukaBaru() {
    setEditId(null);
    setForm(EMPTY_USER);
    setError(null);
    setOpen(true);
  }

  function bukaUbah(row: User) {
    setEditId(row.id);
    setForm({ ...row, password: "" });
    setError(null);
    setOpen(true);
  }

  return (
    <Shell title="Pengguna" user={user} action={<Btn onClick={bukaBaru}>Tambah</Btn>}>
      <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet">
        {users.map((row) => (
          <li key={row.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="font-semibold">{row.nama}</p>
              <p className="text-sm text-stone">
                {row.username} · {row.email || "tanpa surel"}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Badge tone="brand">{ROLE_LABEL[row.role]}</Badge>
              <button type="button" className="text-sm font-semibold text-brand" onClick={() => bukaUbah(row)}>
                Ubah
              </button>
              <button
                type="button"
                className="text-sm font-semibold text-clay"
                onClick={() => {
                  const err = deleteUser(row.id);
                  if (err) toast.error(err);
                  else toast.success("Pengguna dihapus");
                }}
              >
                Hapus
              </button>
            </div>
          </li>
        ))}
      </ul>
      <Modal open={open} title={editId ? "Ubah pengguna" : "Pengguna baru"} onClose={() => setOpen(false)}>
        <form
          className="space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            const err = editId
              ? updateUser(editId, form)
              : addUser(form);
            setError(err);
            if (!err) {
              toast.success(editId ? "Pengguna diperbarui" : "Pengguna ditambahkan");
              setOpen(false);
            }
          }}
        >
          {error ? <Notice>{error}</Notice> : null}
          <Field label="Nama pengguna">
            <input className={control} value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} required />
          </Field>
          <Field label="Nama lengkap">
            <input className={control} value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} required />
          </Field>
          <Field label={editId ? "Kata sandi baru" : "Kata sandi"} hint={editId ? "Kosongkan jika tidak diganti." : "Minimal 6 karakter."}>
            <input className={control} type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required={!editId} />
          </Field>
          <Field label="Surel">
            <input className={control} type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label="Nomor HP">
            <input className={control} value={form.noHp} onChange={(e) => setForm({ ...form, noHp: e.target.value })} />
          </Field>
          <Field label="Alamat">
            <input className={control} value={form.alamat} onChange={(e) => setForm({ ...form, alamat: e.target.value })} />
          </Field>
          <Field label="Peran">
            <select className={control} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Role })}>
              <option value="admin">Admin</option>
              <option value="petugas">Petugas</option>
              <option value="kepala_desa">Kepala desa</option>
            </select>
          </Field>
          <Btn type="submit">Simpan</Btn>
        </form>
      </Modal>
    </Shell>
  );
}

export function JejakPage() {
  const user = useSessionUser();
  const audit = useSiduk((s) => s.audit);
  const [q, setQ] = useState("");
  const rows = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return audit;
    return audit.filter((item) =>
      `${item.aksi} ${item.entitas} ${item.detail} ${item.actor}`.toLowerCase().includes(query),
    );
  }, [audit, q]);
  if (!user) return null;
  return (
    <Shell title="Jejak perubahan" user={user}>
      <p className="mb-4 max-w-2xl text-sm text-stone">
        Catatan siapa mengubah penduduk, keluarga, mutasi, dan pengguna. Disimpan bersama data desa di peramban ini.
      </p>
      <input className={`${control} mb-4 max-w-md`} placeholder="Cari aksi atau nama" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Saring jejak" />
      {rows.length === 0 ? (
        <Empty title="Jejak kosong" body="Perubahan berikutnya akan tercatat di sini." />
      ) : (
        <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet">
          {rows.map((item) => (
            <li key={item.id} className="px-4 py-3">
              <p className="text-sm font-semibold">
                {item.aksi} · {item.entitas}
              </p>
              <p className="text-sm">{item.detail}</p>
              <p className="text-xs text-stone">
                {item.actor} · {formatWaktu(item.waktu)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </Shell>
  );
}

function ambilSlice(state: {
  users: DataSlice["users"];
  pekerjaan: DataSlice["pekerjaan"];
  pendidikan: DataSlice["pendidikan"];
  statusKeluarga: DataSlice["statusKeluarga"];
  keluarga: DataSlice["keluarga"];
  penduduk: DataSlice["penduduk"];
  mutasi: DataSlice["mutasi"];
  surat: DataSlice["surat"];
  audit: DataSlice["audit"];
  suratSeq: number;
  kelompokUsia: DataSlice["kelompokUsia"];
}): DataSlice {
  return {
    users: state.users,
    pekerjaan: state.pekerjaan,
    pendidikan: state.pendidikan,
    statusKeluarga: state.statusKeluarga,
    keluarga: state.keluarga,
    penduduk: state.penduduk,
    mutasi: state.mutasi,
    surat: state.surat,
    audit: state.audit,
    suratSeq: state.suratSeq,
    kelompokUsia: state.kelompokUsia,
  };
}

function parseCadangan(text: string): DataSlice | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object") return null;
  const raw = parsed as Partial<DataSlice>;
  if (!Array.isArray(raw.users) || !Array.isArray(raw.penduduk) || !Array.isArray(raw.keluarga)) return null;
  if (!Array.isArray(raw.pekerjaan) || !Array.isArray(raw.pendidikan) || !Array.isArray(raw.statusKeluarga)) return null;
  if (!raw.users.every((u) => u && typeof u.username === "string" && typeof u.role === "string")) return null;
  if (!raw.penduduk.every((p) => p && typeof p.nik === "string")) return null;
  return {
    users: raw.users,
    pekerjaan: raw.pekerjaan,
    pendidikan: raw.pendidikan,
    statusKeluarga: raw.statusKeluarga,
    keluarga: raw.keluarga,
    penduduk: raw.penduduk,
    mutasi: Array.isArray(raw.mutasi) ? raw.mutasi : [],
    surat: Array.isArray(raw.surat) ? raw.surat : [],
    audit: Array.isArray(raw.audit) ? raw.audit : [],
    suratSeq: typeof raw.suratSeq === "number" ? raw.suratSeq : 0,
    kelompokUsia: Array.isArray(raw.kelompokUsia) && raw.kelompokUsia.length ? raw.kelompokUsia : [],
  };
}

export function CadanganPage() {
  const user = useSessionUser();
  const state = useSiduk((s) => ambilSlice(s));
  const restore = useSiduk((s) => s.restore);
  const resetContoh = useSiduk((s) => s.resetContoh);
  const [konfirmasi, setKonfirmasi] = useState(false);
  if (!user) return null;
  const boleh = can(user.role, "backup.restore");

  return (
    <Shell title="Cadangan" user={user}>
      <div className="grid max-w-3xl gap-4">
        <Panel title="Unduh data">
          <p className="mb-3 text-sm text-stone">
            Satu berkas JSON berisi penduduk, keluarga, foto, mutasi, pengguna, dan jejak. Simpan sebelum mengganti peramban.
          </p>
          <Btn
            onClick={() =>
              downloadText(
                `sidukmen-${new Date().toISOString().slice(0, 10)}.json`,
                JSON.stringify(state, null, 2),
                "application/json",
              )
            }
          >
            Unduh cadangan
          </Btn>
        </Panel>
        <Panel title="Pulihkan">
          {!boleh ? <Notice>Hanya admin yang dapat menimpa data desa.</Notice> : null}
          {boleh ? (
            <>
              <p className="mb-3 text-sm text-stone">Berkas cadangan mengganti seluruh data yang sedang terbuka.</p>
              <input
                type="file"
                accept="application/json,.json"
                className="block text-sm"
                onChange={async (event) => {
                  const file = event.target.files?.[0];
                  event.target.value = "";
                  if (!file) return;
                  const data = parseCadangan(await file.text());
                  if (!data) {
                    toast.error("Berkas bukan cadangan Sidukmen.");
                    return;
                  }
                  const err = restore(data);
                  if (err) toast.error(err);
                  else toast.success("Data desa dipulihkan");
                }}
              />
              <Btn variant="danger" className="mt-4" onClick={() => setKonfirmasi(true)}>
                Muat ulang data contoh
              </Btn>
            </>
          ) : null}
        </Panel>
        <Panel title="Isi cadangan saat ini">
          <p className="text-sm text-stone">
            {state.penduduk.length} penduduk, {state.keluarga.length} keluarga, {state.mutasi.length} mutasi, {state.users.length} pengguna.
          </p>
        </Panel>
      </div>
      <Modal open={konfirmasi} title="Muat ulang data contoh?" onClose={() => setKonfirmasi(false)}>
        <p className="mb-4 text-sm text-stone">Perubahan yang belum diunduh akan hilang. Unduh cadangan lebih dulu jika masih diperlukan.</p>
        <div className="flex gap-2">
          <Btn
            variant="danger"
            onClick={() => {
              const err = resetContoh();
              if (err) toast.error(err);
              else {
                toast.success("Data contoh dimuat");
                setKonfirmasi(false);
              }
            }}
          >
            Muat ulang
          </Btn>
          <Btn variant="ghost" onClick={() => setKonfirmasi(false)}>
            Batal
          </Btn>
        </div>
      </Modal>
    </Shell>
  );
}

export function ProfilPage() {
  const user = useSessionUser();
  const updateProfile = useSiduk((s) => s.updateProfile);
  const changePassword = useSiduk((s) => s.changePassword);
  const [nama, setNama] = useState(user?.nama ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [noHp, setNoHp] = useState(user?.noHp ?? "");
  const [alamat, setAlamat] = useState(user?.alamat ?? "");
  const [lama, setLama] = useState("");
  const [baru, setBaru] = useState("");
  if (!user) return null;

  return (
    <Shell title="Profil" user={user}>
      <div className="grid max-w-3xl gap-4 lg:grid-cols-2">
        <Panel title="Data petugas">
          <p className="mb-3 text-sm text-stone">
            {ROLE_LABEL[user.role]} · {user.username}
          </p>
          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              const err = updateProfile({ nama, email, noHp, alamat });
              if (err) toast.error(err);
              else toast.success("Profil disimpan");
            }}
          >
            <Field label="Nama">
              <input className={control} value={nama} onChange={(e) => setNama(e.target.value)} required />
            </Field>
            <Field label="Surel">
              <input className={control} type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </Field>
            <Field label="Nomor HP">
              <input className={control} value={noHp} onChange={(e) => setNoHp(e.target.value)} />
            </Field>
            <Field label="Alamat">
              <input className={control} value={alamat} onChange={(e) => setAlamat(e.target.value)} />
            </Field>
            <Btn type="submit">Simpan profil</Btn>
          </form>
        </Panel>
        <Panel title="Kata sandi">
          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              const err = changePassword(lama, baru);
              if (err) toast.error(err);
              else {
                toast.success("Kata sandi diperbarui");
                setLama("");
                setBaru("");
              }
            }}
          >
            <Field label="Kata sandi lama">
              <input className={control} type="password" value={lama} onChange={(e) => setLama(e.target.value)} required />
            </Field>
            <Field label="Kata sandi baru">
              <input className={control} type="password" value={baru} onChange={(e) => setBaru(e.target.value)} required />
            </Field>
            <Btn type="submit">Ganti sandi</Btn>
          </form>
        </Panel>
      </div>
    </Shell>
  );
}
