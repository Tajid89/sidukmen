import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useSessionUser } from "@/components/sidukmen/gate";
import { Badge, Btn, Empty, Modal, Notice, control } from "@/components/sidukmen/bits";
import { FotoBidang, SLOT_FOTO } from "@/components/sidukmen/foto-bidang";
import { KeluargaForm } from "@/components/sidukmen/forms";
import { PanelGeotag } from "@/components/sidukmen/lokasi";
import { Shell } from "@/components/sidukmen/shell";
import { aktif, alamatKeluarga, can, labelKelamin, umur } from "@/lib/sidukmen/logic";
import { useSiduk } from "@/lib/sidukmen/store";
import type { Keluarga, KeluargaInput } from "@/lib/sidukmen/types";

export function KeluargaListPage() {
  const user = useSessionUser();
  const keluarga = useSiduk((s) => s.keluarga);
  const penduduk = useSiduk((s) => s.penduduk);
  const [q, setQ] = useState("");
  const [dusun, setDusun] = useState("");
  const dusunList = useMemo(() => [...new Set(keluarga.map((k) => k.dusun))], [keluarga]);
  const rows = useMemo(() => {
    const query = q.trim().toLowerCase();
    return keluarga.filter((k) => {
      if (dusun && k.dusun !== dusun) return false;
      if (!query) return true;
      return k.noKk.includes(query) || k.kepalaKeluarga.toLowerCase().includes(query) || k.alamat.toLowerCase().includes(query) || k.noListrik.includes(query);
    });
  }, [keluarga, q, dusun]);
  if (!user) return null;
  const boleh = can(user.role, "keluarga.write");

  return (
    <Shell
      title="Data keluarga"
      user={user}
      action={
        boleh ? (
          <Link to="/keluarga/baru" className="inline-flex h-11 items-center rounded-lg bg-brand px-4 text-sm font-semibold text-paper">
            Tambah KK
          </Link>
        ) : undefined
      }
    >
      <div className="mb-4 grid gap-2 sm:grid-cols-2">
        <input className={control} placeholder="No. KK, kepala keluarga, alamat, atau ID listrik" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Cari keluarga" />
        <select className={control} value={dusun} onChange={(e) => setDusun(e.target.value)} aria-label="Dusun">
          <option value="">Semua dusun</option>
          {dusunList.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
      </div>
      {rows.length === 0 ? (
        <Empty title="Tidak ada keluarga" body="Tambah kartu keluarga sebelum mengisi anggota." />
      ) : (
        <ul className="grid gap-3 lg:grid-cols-2">
          {rows.map((k) => {
            const anggota = penduduk.filter((p) => p.noKk === k.noKk);
            const aktifCount = anggota.filter(aktif).length;
            return (
              <li key={k.noKk}>
                <Link to="/keluarga/$noKk" params={{ noKk: k.noKk }} className="block rounded-xl border border-line bg-sheet p-4 hover:border-brand">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-xl">{k.kepalaKeluarga}</p>
                      <p className="text-sm text-stone tabular-nums">{k.noKk}</p>
                    </div>
                    <Badge tone="brand">{aktifCount} jiwa</Badge>
                  </div>
                  <p className="mt-3 text-sm text-stone">
                    Dusun {k.dusun} · RT {k.rt}/RW {k.rw}
                  </p>
                  <p className="text-sm">{k.alamat}</p>
                  {k.noListrik ? <p className="mt-1 text-sm text-stone tabular-nums">Listrik {k.noListrik}</p> : null}
                  <p className="mt-2 text-xs font-semibold text-stone">{jumlahFoto(k)}/5 foto</p>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </Shell>
  );
}

export function KeluargaBaruPage() {
  const user = useSessionUser();
  const addKeluarga = useSiduk((s) => s.addKeluarga);
  const navigate = useNavigate();
  if (!user) return null;
  if (!can(user.role, "keluarga.write")) {
    return (
      <Shell title="Tambah keluarga" user={user}>
        <Notice>Peran Anda tidak dapat menambah kartu keluarga.</Notice>
      </Shell>
    );
  }
  return (
    <Shell title="Tambah keluarga" user={user}>
      <div className="max-w-3xl rounded-xl border border-line bg-sheet p-4 md:p-6">
        <KeluargaForm
          submitLabel="Simpan KK"
          onCancel={() => navigate({ to: "/keluarga" })}
          onSubmit={(input) => {
            const err = addKeluarga(input);
            if (!err) {
              toast.success("Kartu keluarga disimpan");
              navigate({ to: "/keluarga/$noKk", params: { noKk: input.noKk.trim() } });
            }
            return err;
          }}
        />
      </div>
    </Shell>
  );
}

export function KeluargaDetailPage({ noKk }: { noKk: string }) {
  const user = useSessionUser();
  const keluarga = useSiduk((s) => s.keluarga);
  const penduduk = useSiduk((s) => s.penduduk);
  const statusKeluarga = useSiduk((s) => s.statusKeluarga);
  const updateKeluarga = useSiduk((s) => s.updateKeluarga);
  const deleteKeluarga = useSiduk((s) => s.deleteKeluarga);
  const navigate = useNavigate();
  const [edit, setEdit] = useState(false);
  const [hapus, setHapus] = useState(false);
  if (!user) return null;
  const kk = keluarga.find((k) => k.noKk === noKk);
  if (!kk) {
    return (
      <Shell title="Keluarga" user={user}>
        <Empty title="KK tidak ditemukan" body="Nomor ini tidak ada dalam data." />
      </Shell>
    );
  }
  const anggota = penduduk.filter((p) => p.noKk === kk.noKk);
  const boleh = can(user.role, "keluarga.write");

  return (
    <Shell title={kk.kepalaKeluarga} user={user}>
      {edit ? (
        <div className="max-w-3xl rounded-xl border border-line bg-sheet p-4 md:p-6">
          <KeluargaForm
            initial={keInput(kk)}
            submitLabel="Simpan perubahan"
            onCancel={() => setEdit(false)}
            onSubmit={(input) => {
              const err = updateKeluarga(kk.noKk, input);
              if (!err) {
                toast.success("Keluarga diperbarui");
                setEdit(false);
                if (input.noKk.trim() !== kk.noKk) navigate({ to: "/keluarga/$noKk", params: { noKk: input.noKk.trim() } });
              }
              return err;
            }}
          />
        </div>
      ) : (
        <>
          <div className="rounded-xl border border-line bg-sheet p-4">
            <p className="text-sm text-stone tabular-nums">No. KK {kk.noKk}</p>
            <p className="mt-2">{alamatKeluarga(kk)}</p>
            <p className="mt-1 text-sm text-stone tabular-nums">Nomor pelanggan listrik: {kk.noListrik || "belum diisi"}</p>
            {boleh ? (
              <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                <Btn onClick={() => setEdit(true)}>Ubah KK</Btn>
                <Btn variant="danger" onClick={() => setHapus(true)}>
                  Hapus KK
                </Btn>
              </div>
            ) : null}
          </div>
          <div className="mt-5">
            <PanelGeotag
              latitude={kk.latitude}
              longitude={kk.longitude}
              disabled={!boleh}
              pesanSukses="Latitude dan longitude tersimpan."
              onSimpan={(titik) => updateKeluarga(kk.noKk, { ...keInput(kk), ...titik })}
            />
          </div>
          <section className="mt-5">
            <h2 className="font-display text-xl">Dokumentasi rumah</h2>
            <p className="mt-1 mb-3 max-w-2xl text-sm text-stone">
              Foto KK, tampak rumah, kamar mandi, dan lokasi. Di ponsel, Kamera membuka kamera langsung. Berkas memilih gambar yang sudah ada.
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              {SLOT_FOTO.map((slot) => (
                <FotoBidang
                  key={slot.key}
                  label={slot.label}
                  hint={slot.hint}
                  geotag={slot.geotag}
                  disabled={!boleh}
                  src={kk[slot.key] ?? null}
                  onChange={(dataUrl, titik) => {
                    const err = updateKeluarga(kk.noKk, {
                      ...keInput(kk),
                      [slot.key]: dataUrl,
                      ...(slot.geotag && titik ? { latitude: titik.latitude, longitude: titik.longitude } : {}),
                    });
                    if (err) toast.error(err);
                    else toast.success(dataUrl ? `${slot.label} disimpan` : `${slot.label} dihapus`);
                  }}
                />
              ))}
            </div>
          </section>
          <div className="mt-5 flex items-center justify-between gap-3">
            <h2 className="font-display text-xl">Anggota</h2>
            {can(user.role, "penduduk.write") ? (
              <Link to="/penduduk/baru" search={{ kk: kk.noKk }} className="text-sm font-semibold text-brand">
                Tambah anggota
              </Link>
            ) : null}
          </div>
          <ul className="mt-3 divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet">
            {anggota.length === 0 ? (
              <li className="px-4 py-6 text-sm text-stone">Belum ada anggota pada KK ini.</li>
            ) : (
              anggota.map((p) => (
                <li key={p.nik}>
                  <Link to="/penduduk/$nik" params={{ nik: p.nik }} className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-paper">
                    <span>
                      <span className="block font-semibold">{p.nama}</span>
                      <span className="text-sm text-stone">
                        {statusKeluarga.find((s) => s.id === p.statusId)?.nama} · {labelKelamin(p.jenisKelamin)} · {umur(p.tanggalLahir)} th
                      </span>
                    </span>
                    <Badge tone={p.statusHidup === "aktif" ? "brand" : "sand"}>{p.statusHidup}</Badge>
                  </Link>
                </li>
              ))
            )}
          </ul>
        </>
      )}
      <Modal open={hapus} title="Hapus kartu keluarga?" onClose={() => setHapus(false)}>
        <p className="mb-4 text-sm text-stone">KK hanya bisa dihapus jika sudah tidak punya anggota.</p>
        <Btn
          variant="danger"
          onClick={() => {
            const err = deleteKeluarga(kk.noKk);
            if (err) toast.error(err);
            else {
              toast.success("Kartu keluarga dihapus");
              navigate({ to: "/keluarga" });
            }
          }}
        >
          Hapus
        </Btn>
      </Modal>
    </Shell>
  );
}

function jumlahFoto(k: Keluarga): number {
  return SLOT_FOTO.filter((slot) => k[slot.key]).length;
}

function keInput(k: Keluarga): KeluargaInput {
  return {
    noKk: k.noKk,
    kepalaKeluarga: k.kepalaKeluarga,
    alamat: k.alamat,
    dusun: k.dusun,
    rt: k.rt,
    rw: k.rw,
    latitude: k.latitude,
    longitude: k.longitude,
    noListrik: k.noListrik ?? "",
    fotoKk: k.fotoKk ?? null,
    fotoDepan: k.fotoDepan ?? null,
    fotoDalam: k.fotoDalam ?? null,
    fotoKamarMandi: k.fotoKamarMandi ?? null,
    fotoLokasi: k.fotoLokasi ?? null,
  };
}
