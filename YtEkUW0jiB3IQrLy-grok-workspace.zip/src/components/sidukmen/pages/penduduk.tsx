import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useSessionUser } from "@/components/sidukmen/gate";
import { Badge, Btn, Empty, Modal, Notice, control } from "@/components/sidukmen/bits";
import { PendudukForm } from "@/components/sidukmen/forms";
import { Shell } from "@/components/sidukmen/shell";
import {
  aktif,
  alamatKeluarga,
  can,
  formatTanggal,
  labelKelamin,
  namaMaster,
  pendudukToCsv,
  planImport,
  parseCsv,
  templateCsv,
  umur,
  downloadText,
  MUTASI_LABEL,
} from "@/lib/sidukmen/logic";
import { useSiduk } from "@/lib/sidukmen/store";
import type { Penduduk } from "@/lib/sidukmen/types";

export function PendudukListPage() {
  const user = useSessionUser();
  const penduduk = useSiduk((s) => s.penduduk);
  const keluarga = useSiduk((s) => s.keluarga);
  const pekerjaan = useSiduk((s) => s.pekerjaan);
  const pendidikan = useSiduk((s) => s.pendidikan);
  const statusKeluarga = useSiduk((s) => s.statusKeluarga);
  const importPenduduk = useSiduk((s) => s.importPenduduk);
  const [q, setQ] = useState("");
  const [jk, setJk] = useState("");
  const [dusun, setDusun] = useState("");
  const [hidup, setHidup] = useState("aktif");
  const [kerja, setKerja] = useState("");
  const [page, setPage] = useState(1);
  const [importOpen, setImportOpen] = useState(false);
  const [preview, setPreview] = useState<{ ok: number; issues: { baris: number; pesan: string }[]; rows: Parameters<typeof importPenduduk>[0] } | null>(null);
  const dusunList = [...new Set(keluarga.map((k) => k.dusun))];
  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return penduduk
      .filter((p) => {
        const kk = keluarga.find((k) => k.noKk === p.noKk);
        if (query && !p.nama.toLowerCase().includes(query) && !p.nik.includes(query)) return false;
        if (jk && p.jenisKelamin !== jk) return false;
        if (hidup === "aktif" && !aktif(p)) return false;
        if (hidup === "nonaktif" && aktif(p)) return false;
        if (kerja && p.pekerjaanId !== kerja) return false;
        if (dusun && kk?.dusun !== dusun) return false;
        return true;
      })
      .sort((a, b) => a.nama.localeCompare(b.nama, "id"));
  }, [penduduk, keluarga, q, jk, hidup, kerja, dusun]);
  if (!user) return null;
  const boleh = can(user.role, "penduduk.write");

  const size = 10;
  const pages = Math.max(1, Math.ceil(filtered.length / size));
  const current = Math.min(page, pages);
  const view = filtered.slice((current - 1) * size, current * size);

  return (
    <Shell
      title="Data penduduk"
      user={user}
      action={
        boleh ? (
          <div className="flex gap-2">
            <Btn variant="ghost" onClick={() => setImportOpen(true)}>
              Impor
            </Btn>
            <Link to="/penduduk/baru" search={{ kk: "" }} className="inline-flex h-11 items-center rounded-lg bg-brand px-4 text-sm font-semibold text-paper">
              Tambah
            </Link>
          </div>
        ) : undefined
      }
    >
      {!boleh ? <p className="mb-4 text-sm text-stone">Anda masuk sebagai kepala desa. Data dapat dilihat, perubahan dilakukan petugas.</p> : null}
      <div className="mb-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
        <input className={control} placeholder="Nama atau NIK" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} aria-label="Saring nama" />
        <select className={control} value={jk} onChange={(e) => { setJk(e.target.value); setPage(1); }} aria-label="Jenis kelamin">
          <option value="">Semua kelamin</option>
          <option value="L">Laki-laki</option>
          <option value="P">Perempuan</option>
        </select>
        <select className={control} value={dusun} onChange={(e) => { setDusun(e.target.value); setPage(1); }} aria-label="Dusun">
          <option value="">Semua dusun</option>
          {dusunList.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
        <select className={control} value={kerja} onChange={(e) => { setKerja(e.target.value); setPage(1); }} aria-label="Pekerjaan">
          <option value="">Semua pekerjaan</option>
          {pekerjaan.map((item) => (
            <option key={item.id} value={item.id}>{item.nama}</option>
          ))}
        </select>
        <select className={control} value={hidup} onChange={(e) => { setHidup(e.target.value); setPage(1); }} aria-label="Status kependudukan">
          <option value="aktif">Penduduk aktif</option>
          <option value="nonaktif">Meninggal / pindah</option>
          <option value="">Semua status</option>
        </select>
      </div>
      <div className="mb-3 flex items-center justify-between gap-3 text-sm text-stone">
        <span>{filtered.length} jiwa</span>
        <button
          type="button"
          className="font-semibold text-brand"
          onClick={() =>
            downloadText(
              "penduduk-sidukmen.csv",
              pendudukToCsv(filtered, { pekerjaan, pendidikan, statusKeluarga }),
              "text/csv;charset=utf-8",
            )
          }
        >
          Unduh CSV
        </button>
      </div>
      {view.length === 0 ? (
        <Empty title="Tidak ada penduduk" body="Ubah saringan, atau tambah data baru." />
      ) : (
        <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line bg-sheet">
          {view.map((p) => {
            const kk = keluarga.find((k) => k.noKk === p.noKk);
            return (
              <li key={p.nik}>
                <Link to="/penduduk/$nik" params={{ nik: p.nik }} className="flex flex-col gap-1 px-4 py-3 hover:bg-paper sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="font-semibold">{p.nama}</p>
                    <p className="text-sm text-stone tabular-nums">
                      {p.nik} · {labelKelamin(p.jenisKelamin)} · {umur(p.tanggalLahir)} th
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-sm text-stone">
                    <span>{namaMaster(pekerjaan, p.pekerjaanId)}</span>
                    <span>{kk?.dusun ?? "—"}</span>
                    <StatusBadge orang={p} />
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
      {pages > 1 ? (
        <div className="mt-4 flex items-center justify-between">
          <Btn variant="ghost" disabled={current <= 1} onClick={() => setPage((n) => Math.max(1, n - 1))}>
            Sebelumnya
          </Btn>
          <span className="text-sm text-stone tabular-nums">
            {current} / {pages}
          </span>
          <Btn variant="ghost" disabled={current >= pages} onClick={() => setPage((n) => n + 1)}>
            Berikutnya
          </Btn>
        </div>
      ) : null}

      <Modal open={importOpen} title="Impor CSV" onClose={() => { setImportOpen(false); setPreview(null); }}>
        <p className="mb-3 text-sm text-stone">
          Baris yang gagal dilewati. Kartu keluarga harus sudah ada. Unduh contoh kolom bila perlu.
        </p>
        <Btn
          variant="ghost"
          onClick={() => downloadText("contoh-penduduk.csv", templateCsv(), "text/csv;charset=utf-8")}
        >
          Unduh contoh
        </Btn>
        <input
          className="mt-3 block w-full text-sm"
          type="file"
          accept=".csv,text/csv"
          onChange={async (event) => {
            const file = event.target.files?.[0];
            if (!file) return;
            const text = await file.text();
            const plan = planImport(parseCsv(text), {
              penduduk,
              keluarga,
              pekerjaan,
              pendidikan,
              statusKeluarga,
            });
            setPreview({ ok: plan.ok.length, issues: plan.issues.slice(0, 8), rows: plan.ok });
          }}
        />
        {preview ? (
          <div className="mt-4 space-y-2 text-sm">
            <p>{preview.ok} baris siap disimpan.</p>
            {preview.issues.map((issue) => (
              <p key={`${issue.baris}-${issue.pesan}`} className="text-clay">
                Baris {issue.baris}: {issue.pesan}
              </p>
            ))}
            <Btn
              disabled={!preview.ok}
              onClick={() => {
                const err = importPenduduk(preview.rows);
                if (err) toast.error(err);
                else {
                  toast.success(`${preview.ok} penduduk ditambahkan`);
                  setImportOpen(false);
                  setPreview(null);
                }
              }}
            >
              Simpan yang sah
            </Btn>
          </div>
        ) : null}
      </Modal>
    </Shell>
  );
}

function StatusBadge({ orang }: { orang: Penduduk }) {
  if (orang.statusHidup === "aktif") return <Badge tone="brand">Aktif</Badge>;
  if (orang.statusHidup === "meninggal") return <Badge tone="clay">Meninggal</Badge>;
  return <Badge tone="sand">Pindah</Badge>;
}

export function PendudukBaruPage({ noKk = "" }: { noKk?: string }) {
  const user = useSessionUser();
  const addPenduduk = useSiduk((s) => s.addPenduduk);
  const navigate = useNavigate();
  if (!user) return null;
  if (!can(user.role, "penduduk.write")) {
    return (
      <Shell title="Tambah penduduk" user={user}>
        <Notice>Peran Anda tidak dapat menambah penduduk.</Notice>
      </Shell>
    );
  }
  return (
    <Shell title="Tambah penduduk" user={user}>
      <div className="max-w-4xl rounded-xl border border-line bg-sheet p-4 md:p-6">
        <PendudukForm
          initial={{ noKk }}
          submitLabel="Simpan penduduk"
          onCancel={() => navigate({ to: "/penduduk" })}
          onSubmit={(input) => {
            const err = addPenduduk(input);
            if (!err) {
              toast.success("Penduduk disimpan");
              navigate({ to: "/penduduk/$nik", params: { nik: input.nik.trim() } });
            }
            return err;
          }}
        />
      </div>
    </Shell>
  );
}

export function PendudukDetailPage({ nik }: { nik: string }) {
  const user = useSessionUser();
  const penduduk = useSiduk((s) => s.penduduk);
  const keluarga = useSiduk((s) => s.keluarga);
  const pekerjaan = useSiduk((s) => s.pekerjaan);
  const pendidikan = useSiduk((s) => s.pendidikan);
  const statusKeluarga = useSiduk((s) => s.statusKeluarga);
  const mutasi = useSiduk((s) => s.mutasi);
  const updatePenduduk = useSiduk((s) => s.updatePenduduk);
  const deletePenduduk = useSiduk((s) => s.deletePenduduk);
  const aktifkan = useSiduk((s) => s.aktifkan);
  const navigate = useNavigate();
  const [edit, setEdit] = useState(false);
  const [hapus, setHapus] = useState(false);
  if (!user) return null;
  const orang = penduduk.find((p) => p.nik === nik);
  if (!orang) {
    return (
      <Shell title="Penduduk" user={user}>
        <Empty title="Tidak ditemukan" body="NIK ini tidak ada di data desa." />
      </Shell>
    );
  }
  const kk = keluarga.find((k) => k.noKk === orang.noKk);
  const boleh = can(user.role, "penduduk.write");
  const bolehMutasi = can(user.role, "mutasi.write");
  const riwayat = mutasi.filter((m) => m.nik === orang.nik);
  const rows: [string, string][] = [
    ["NIK", orang.nik],
    ["Jenis kelamin", labelKelamin(orang.jenisKelamin)],
    ["Tempat, tanggal lahir", `${orang.tempatLahir}, ${formatTanggal(orang.tanggalLahir)} (${umur(orang.tanggalLahir)} tahun)`],
    ["Agama", orang.agama],
    ["Perkawinan", orang.statusPerkawinan],
    ["Pekerjaan", namaMaster(pekerjaan, orang.pekerjaanId)],
    ["Pendidikan", namaMaster(pendidikan, orang.pendidikanId)],
    ["Status keluarga", namaMaster(statusKeluarga, orang.statusId)],
    ["Ayah", orang.namaAyah || "—"],
    ["Ibu", orang.namaIbu || "—"],
    ["Alamat", kk ? alamatKeluarga(kk) : orang.alamat],
  ];

  return (
    <Shell title={orang.nama} user={user}>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <StatusBadge orang={orang} />
        <Badge>{labelKelamin(orang.jenisKelamin)}</Badge>
        {kk ? (
          <Link to="/keluarga/$noKk" params={{ noKk: kk.noKk }} className="text-sm font-semibold text-brand">
            KK {kk.kepalaKeluarga}
          </Link>
        ) : null}
      </div>
      {edit ? (
        <div className="max-w-4xl rounded-xl border border-line bg-sheet p-4 md:p-6">
          <PendudukForm
            initial={orang}
            submitLabel="Simpan perubahan"
            onCancel={() => setEdit(false)}
            onSubmit={(input) => {
              const err = updatePenduduk(orang.nik, input);
              if (!err) {
                toast.success("Perubahan disimpan");
                setEdit(false);
                if (input.nik.trim() !== orang.nik) navigate({ to: "/penduduk/$nik", params: { nik: input.nik.trim() } });
              }
              return err;
            }}
          />
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]">
          <dl className="divide-y divide-line rounded-xl border border-line bg-sheet">
            {rows.map(([label, value]) => (
              <div key={label} className="grid gap-1 px-4 py-3 sm:grid-cols-[12rem_1fr]">
                <dt className="text-sm text-stone">{label}</dt>
                <dd className="font-medium">{value}</dd>
              </div>
            ))}
          </dl>
          <div className="space-y-2">
            {boleh ? <Btn className="w-full" onClick={() => setEdit(true)}>Ubah data</Btn> : null}
            {bolehMutasi && orang.statusHidup === "aktif" ? (
              <Link to="/mutasi" search={{ nik: orang.nik, jenis: "meninggal" }} className="inline-flex h-11 w-full items-center justify-center rounded-lg border border-line bg-sheet text-sm font-semibold">
                Catat mutasi
              </Link>
            ) : null}
            {bolehMutasi && orang.statusHidup !== "aktif" ? (
              <Btn variant="ghost" className="w-full" onClick={() => {
                const err = aktifkan(orang.nik);
                if (err) toast.error(err);
                else toast.success("Status dikembalikan menjadi aktif");
              }}>
                Kembalikan aktif
              </Btn>
            ) : null}
            {boleh ? (
              <Btn variant="danger" className="w-full" onClick={() => setHapus(true)}>
                Hapus
              </Btn>
            ) : null}
          </div>
        </div>
      )}
      {riwayat.length ? (
        <section className="mt-6">
          <h2 className="mb-2 font-display text-xl">Riwayat mutasi</h2>
          <ul className="space-y-2">
            {riwayat.map((item) => (
              <li key={item.id} className="rounded-lg border border-line bg-sheet px-4 py-3 text-sm">
                <p className="font-semibold">{MUTASI_LABEL[item.jenis]} · {formatTanggal(item.tanggal)}</p>
                <p className="text-stone">{item.keterangan}</p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
      <Modal open={hapus} title="Hapus penduduk?" onClose={() => setHapus(false)}>
        <p className="mb-4 text-sm text-stone">
          {orang.nama} akan dihapus dari daftar. Riwayat mutasi yang sudah tercatat tetap menyimpan nama.
        </p>
        <div className="flex gap-2">
          <Btn
            variant="danger"
            onClick={() => {
              const err = deletePenduduk(orang.nik);
              if (err) toast.error(err);
              else {
                toast.success("Penduduk dihapus");
                navigate({ to: "/penduduk" });
              }
            }}
          >
            Hapus
          </Btn>
          <Btn variant="ghost" onClick={() => setHapus(false)}>
            Batal
          </Btn>
        </div>
      </Modal>
    </Shell>
  );
}
