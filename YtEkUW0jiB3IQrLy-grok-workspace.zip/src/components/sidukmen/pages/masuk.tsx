import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { DESA, DEMO_AKUN, ROLE_LABEL } from "@/lib/sidukmen/logic";
import { useSiduk, useUser } from "@/lib/sidukmen/store";
import { Btn, Field, Notice, control } from "@/components/sidukmen/bits";

export function MasukPage() {
  const user = useUser();
  const login = useSiduk((s) => s.login);
  const navigate = useNavigate();
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("monongo");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) navigate({ to: "/dasbor" });
  }, [user, navigate]);

  if (user) return null;

  function masuk(nama: string, sandi: string) {
    const err = login(nama, sandi);
    setError(err);
    if (!err) navigate({ to: "/dasbor" });
  }

  return (
    <main className="grid min-h-screen lg:grid-cols-[22rem_minmax(0,1fr)]">
      <section className="flex flex-col justify-between bg-brand px-6 py-8 text-paper lg:px-8 lg:py-10">
        <div>
          <p className="text-xs font-semibold tracking-[0.18em] text-white/70 uppercase">Kabupaten {DESA.kabupaten}</p>
          <h1 className="mt-3 font-display text-4xl font-semibold leading-tight">SIDUKMEN</h1>
          <p className="mt-3 max-w-xs text-sm leading-6 text-white/75">
            Sistem data kependudukan Desa {DESA.nama}, Kecamatan {DESA.kecamatan}. Penduduk, kartu keluarga, dan dokumentasi rumah dalam satu meja.
          </p>
        </div>
        <p className="mt-10 text-sm text-white/75">Data desa tersimpan di database server, dipakai bersama oleh perangkat yang masuk.</p>
      </section>
      <section className="flex items-center px-4 py-10 sm:px-8">
        <div className="mx-auto w-full max-w-md">
          <h2 className="font-display text-3xl text-ink">Masuk</h2>
          <p className="mt-2 text-sm text-stone">Pilih peran contoh, atau isi nama pengguna sendiri.</p>
          <div className="mt-5 grid gap-2">
            {DEMO_AKUN.map((akun) => (
              <button
                key={akun.username}
                type="button"
                className="rounded-xl border border-line bg-sheet px-4 py-3 text-left hover:border-brand"
                onClick={() => {
                  setUsername(akun.username);
                  setPassword(akun.password);
                  masuk(akun.username, akun.password);
                }}
              >
                <span className="block text-sm font-semibold">{akun.username}</span>
                <span className="text-sm text-stone">{akun.peran}</span>
              </button>
            ))}
          </div>
          <form
            className="mt-6 space-y-4"
            onSubmit={(event) => {
              event.preventDefault();
              masuk(username, password);
            }}
          >
            {error ? <Notice>{error}</Notice> : null}
            <Field label="Nama pengguna">
              <input className={control} value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required />
            </Field>
            <Field label="Kata sandi" hint="Akun contoh memakai sandi monongo.">
              <input className={control} type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
            </Field>
            <Btn type="submit" className="w-full">
              Masuk ke desa
            </Btn>
          </form>
          <p className="mt-4 text-xs text-stone">Peran: {Object.values(ROLE_LABEL).join(", ")}.</p>
        </div>
      </section>
    </main>
  );
}
