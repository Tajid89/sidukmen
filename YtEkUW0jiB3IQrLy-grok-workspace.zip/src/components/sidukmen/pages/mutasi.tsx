import { useState } from "react";
import { toast } from "sonner";
import { useSessionUser } from "@/components/sidukmen/gate";
import { Btn, Field, Notice, Panel, control } from "@/components/sidukmen/bits";
import { Shell } from "@/components/sidukmen/shell";
import { AGAMA, MUTASI_LABEL, STATUS_KAWIN, can, formatTanggal } from "@/lib/sidukmen/logic";
import { useSiduk } from "@/lib/sidukmen/store";
import type { JenisMutasi } from "@/lib/sidukmen/types";

export function MutasiPage({ presetNik = "", presetJenis = "" }: { presetNik?: string; presetJenis?: string }) {
  const user = useSessionUser();
  const penduduk = useSiduk((s) => s.penduduk);
  const keluarga = useSiduk((s) => s.keluarga);
  const pekerjaan = useSiduk((s) => s.pekerjaan);
  const pendidikan = useSiduk((s) => s.pendidikan);
  const statusKeluarga = useSiduk((s) => s.statusKeluarga);
  const mutasi = useSiduk((s) => s.mutasi);
  const catatMeninggal = useSiduk((s) => s.catatMeninggal);
  const catatPindahKeluar = useSiduk((s) => s.catatPindahKeluar);
  const catatLahir = useSiduk((s) => s.catatLahir);
  const catatPindahMasuk = useSiduk((s) => s.catatPindahMasuk);
  const [jenis, setJenis] = useState<JenisMutasi>((presetJenis as JenisMutasi) || "lahir");
  const [nik, setNik] = useState(presetNik);
  const [tanggal, setTanggal] = useState(new Date().toISOString().slice(0, 10));
  const [keterangan, setKeterangan] = useState("");
  const [noKk, setNoKk] = useState("");
  const [nama, setNama] = useState("");
  const [jk, setJk] = useState<"L" | "P">("L");
  const [tempat, setTempat] = useState("Lamongan");
  const [ayah, setAyah] = useState("");
  const [ibu, setIbu] = useState("");
  const [lahir, setLahir] = useState("1990-01-01");
  const [agama, setAgama] = useState("Islam");
  const [kawin, setKawin] = useState("Kawin");
  const [pekerjaanId, setPekerjaanId] = useState(pekerjaan[0]?.id ?? "");
  const [pendidikanId, setPendidikanId] = useState(pendidikan[0]?.id ?? "");
  const [statusId, setStatusId] = useState(statusKeluarga.find((s) => s.nama === "Famili Lain")?.id ?? statusKeluarga[0]?.id ?? "");
  const [error, setError] = useState<string | null>(null);
  if (!user) return null;
  const boleh = can(user.role, "mutasi.write");
  const aktifList = penduduk.filter((p) => p.statusHidup === "aktif");

  function pilihKk(value: string) {
    setNoKk(value);
    const kk = keluarga.find((k) => k.noKk === value);
    const anggota = penduduk.filter((p) => p.noKk === value && p.statusHidup === "aktif");
    const kepala = anggota.find((p) => p.nama === kk?.kepalaKeluarga);
    const istri = anggota.find((p) => p.jenisKelamin === "P" && p.statusPerkawinan === "Kawin");
    if (kepala?.jenisKelamin === "L") setAyah(kepala.nama);
    if (istri) setIbu(istri.nama);
  }

  return (
    <Shell title="Mutasi penduduk" user={user}>
      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <Panel title="Catat kejadian">
          {!boleh ? <Notice>Kepala desa dapat melihat riwayat. Pencatatan dilakukan petugas.</Notice> : null}
          {boleh ? (
            <form
              className="mt-4 space-y-4"
              onSubmit={(event) => {
                event.preventDefault();
                let err: string | null = "Jenis mutasi tidak dikenal.";
                if (jenis === "meninggal") err = catatMeninggal(nik, tanggal, keterangan);
                if (jenis === "pindah_keluar") err = catatPindahKeluar(nik, tanggal, keterangan);
                if (jenis === "lahir") {
                  err = catatLahir({
                    noKk,
                    nik,
                    nama,
                    jenisKelamin: jk,
                    tanggal,
                    tempatLahir: tempat,
                    namaAyah: ayah,
                    namaIbu: ibu,
                    keterangan,
                  });
                }
                if (jenis === "pindah_masuk") {
                  err = catatPindahMasuk({
                    nik,
                    nama,
                    jenisKelamin: jk,
                    tempatLahir: tempat,
                    tanggalLahir: lahir,
                    agama,
                    statusPerkawinan: kawin,
                    pekerjaanId,
                    pendidikanId,
                    statusId,
                    noKk,
                    alamat: "",
                    namaAyah: ayah,
                    namaIbu: ibu,
                    tanggal,
                    keterangan,
                  });
                }
                setError(err);
                if (!err) {
                  toast.success("Mutasi dicatat");
                  setKeterangan("");
                  setNama("");
                  setNik("");
                }
              }}
            >
              {error ? <Notice>{error}</Notice> : null}
              <Field label="Jenis">
                <select className={control} value={jenis} onChange={(e) => setJenis(e.target.value as JenisMutasi)}>
                  {(Object.keys(MUTASI_LABEL) as JenisMutasi[]).map((key) => (
                    <option key={key} value={key}>
                      {MUTASI_LABEL[key]}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Tanggal kejadian">
                <input className={control} type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)} required />
              </Field>
              {jenis === "meninggal" || jenis === "pindah_keluar" ? (
                <Field label="Penduduk">
                  <select className={control} value={nik} onChange={(e) => setNik(e.target.value)} required>
                    <option value="">Pilih penduduk aktif</option>
                    {aktifList.map((p) => (
                      <option key={p.nik} value={p.nik}>
                        {p.nama} — {p.nik}
                      </option>
                    ))}
                  </select>
                </Field>
              ) : (
                <>
                  <Field label="Kartu keluarga">
                    <select className={control} value={noKk} onChange={(e) => pilihKk(e.target.value)} required>
                      <option value="">Pilih KK</option>
                      {keluarga.map((k) => (
                        <option key={k.noKk} value={k.noKk}>
                          {k.noKk} — {k.kepalaKeluarga}
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="NIK" hint={jenis === "lahir" ? "Isi NIK dari akta. Nomor sementara 16 digit boleh, lalu ubah di data penduduk." : "NIK penduduk yang masuk."}>
                    <input className={control} inputMode="numeric" maxLength={16} value={nik} onChange={(e) => setNik(e.target.value.replace(/\D/g, ""))} required />
                  </Field>
                  <Field label="Nama">
                    <input className={control} value={nama} onChange={(e) => setNama(e.target.value)} required />
                  </Field>
                  <Field label="Jenis kelamin">
                    <select className={control} value={jk} onChange={(e) => setJk(e.target.value as "L" | "P")}>
                      <option value="L">Laki-laki</option>
                      <option value="P">Perempuan</option>
                    </select>
                  </Field>
                  <Field label="Tempat lahir">
                    <input className={control} value={tempat} onChange={(e) => setTempat(e.target.value)} />
                  </Field>
                  {jenis === "pindah_masuk" ? (
                    <>
                      <Field label="Tanggal lahir">
                        <input className={control} type="date" value={lahir} onChange={(e) => setLahir(e.target.value)} required />
                      </Field>
                      <Field label="Agama">
                        <select className={control} value={agama} onChange={(e) => setAgama(e.target.value)}>
                          {AGAMA.map((item) => (
                            <option key={item}>{item}</option>
                          ))}
                        </select>
                      </Field>
                      <Field label="Status perkawinan">
                        <select className={control} value={kawin} onChange={(e) => setKawin(e.target.value)}>
                          {STATUS_KAWIN.map((item) => (
                            <option key={item}>{item}</option>
                          ))}
                        </select>
                      </Field>
                      <Field label="Pekerjaan">
                        <select className={control} value={pekerjaanId} onChange={(e) => setPekerjaanId(e.target.value)}>
                          {pekerjaan.map((item) => (
                            <option key={item.id} value={item.id}>{item.nama}</option>
                          ))}
                        </select>
                      </Field>
                      <Field label="Pendidikan">
                        <select className={control} value={pendidikanId} onChange={(e) => setPendidikanId(e.target.value)}>
                          {pendidikan.map((item) => (
                            <option key={item.id} value={item.id}>{item.nama}</option>
                          ))}
                        </select>
                      </Field>
                      <Field label="Status dalam keluarga">
                        <select className={control} value={statusId} onChange={(e) => setStatusId(e.target.value)}>
                          {statusKeluarga.map((item) => (
                            <option key={item.id} value={item.id}>{item.nama}</option>
                          ))}
                        </select>
                      </Field>
                    </>
                  ) : null}
                  <Field label="Nama ayah">
                    <input className={control} value={ayah} onChange={(e) => setAyah(e.target.value)} />
                  </Field>
                  <Field label="Nama ibu">
                    <input className={control} value={ibu} onChange={(e) => setIbu(e.target.value)} />
                  </Field>
                </>
              )}
              <Field label="Keterangan">
                <textarea className={`${control} h-24 py-2`} value={keterangan} onChange={(e) => setKeterangan(e.target.value)} required />
              </Field>
              <Btn type="submit">Simpan mutasi</Btn>
            </form>
          ) : null}
        </Panel>
        <Panel title="Riwayat">
          <ul className="max-h-[40rem] space-y-3 overflow-auto">
            {mutasi.map((item) => (
              <li key={item.id} className="border-b border-line pb-3 text-sm">
                <p className="font-semibold">{MUTASI_LABEL[item.jenis]}</p>
                <p>{item.nama}</p>
                <p className="text-stone">
                  {formatTanggal(item.tanggal)} · {item.actor}
                </p>
                <p className="text-stone">{item.keterangan}</p>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </Shell>
  );
}
