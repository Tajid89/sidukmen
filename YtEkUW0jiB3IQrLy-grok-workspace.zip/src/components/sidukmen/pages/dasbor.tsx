import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useSessionUser } from "@/components/sidukmen/gate";
import { Panel, Stat } from "@/components/sidukmen/bits";
import { PetaTitik } from "@/components/sidukmen/peta";
import { Shell } from "@/components/sidukmen/shell";
import {
  CHART_COLORS,
  MUTASI_LABEL,
  angka,
  bulanIni,
  formatTanggal,
  hitungMaster,
  hitungTeks,
  kelompokUsia,
  ringkas,
  umur,
  aktif,
} from "@/lib/sidukmen/logic";
import { useSiduk } from "@/lib/sidukmen/store";

function Tip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: { value?: number }[];
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md border border-line bg-sheet px-3 py-2 text-sm text-ink">
      <p className="text-stone">{label}</p>
      <p className="font-semibold tabular-nums">{angka(payload[0]?.value ?? 0)} jiwa</p>
    </div>
  );
}

export function DasborPage() {
  const user = useSessionUser();
  const penduduk = useSiduk((s) => s.penduduk);
  const keluarga = useSiduk((s) => s.keluarga);
  const pekerjaan = useSiduk((s) => s.pekerjaan);
  const pendidikan = useSiduk((s) => s.pendidikan);
  const mutasi = useSiduk((s) => s.mutasi);
  const audit = useSiduk((s) => s.audit);
  const pita = useSiduk((s) => s.kelompokUsia);
  if (!user) return null;

  const hidup = penduduk.filter(aktif);
  const laki = hidup.filter((p) => p.jenisKelamin === "L").length;
  const perempuan = hidup.length - laki;
  const muda = pita[0];
  const tua = pita[pita.length - 1];
  const dalam = (band: { min: number; max: number } | undefined) =>
    band ? hidup.filter((p) => {
      const u = umur(p.tanggalLahir);
      return u >= band.min && u <= band.max;
    }).length : 0;
  const kerja = ringkas(hitungMaster(penduduk, pekerjaan, (p) => p.pekerjaanId));
  const didik = hitungMaster(penduduk, pendidikan, (p) => p.pendidikanId);
  const usia = kelompokUsia(penduduk, pita);
  const dusunMap = new Map<string, { kk: number; jiwa: number }>();
  for (const kk of keluarga) {
    const row = dusunMap.get(kk.dusun) ?? { kk: 0, jiwa: 0 };
    row.kk += 1;
    row.jiwa += hidup.filter((p) => p.noKk === kk.noKk).length;
    dusunMap.set(kk.dusun, row);
  }

  return (
    <Shell title="Dasbor" user={user}>
      <p className="mb-5 max-w-2xl text-sm text-stone">
        Ringkasan penduduk aktif. Yang meninggal atau pindah tetap tersimpan di riwayat, tetapi tidak dihitung di sini.
      </p>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Penduduk aktif" value={angka(hidup.length)} note="jiwa" />
        <Stat label="Keluarga" value={angka(keluarga.length)} note="kartu keluarga" />
        <Stat label="Laki-laki" value={angka(laki)} note={perempuan ? `${angka(perempuan)} perempuan` : "perempuan 0"} />
        <Stat label="Perempuan" value={angka(perempuan)} note="jiwa" />
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label={muda ? muda.label : "Kelompok muda"} value={angka(dalam(muda))} note={muda ? `${muda.min}–${muda.max} tahun` : "atur di master"} />
        <Stat
          label={tua && tua !== muda ? tua.label : "Kelompok lain"}
          value={angka(tua && tua !== muda ? dalam(tua) : 0)}
          note={tua && tua !== muda ? `${tua.min}–${tua.max} tahun` : "tambah rentang di master"}
        />
        <Stat label="Mutasi bulan ini" value={angka(mutasi.filter((m) => bulanIni(m.tanggal)).length)} note="kejadian" />
        <Stat
          label="KK berfoto"
          value={angka(keluarga.filter((k) => k.fotoDepan || k.fotoKk || k.fotoLokasi || k.fotoDalam || k.fotoKamarMandi).length)}
          note={`dari ${angka(keluarga.length)} keluarga`}
        />
      </div>

      <div className="mt-6 grid gap-4 xl:grid-cols-3">
        <Panel title="Pekerjaan">
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={kerja} dataKey="jumlah" nameKey="label" innerRadius={48} outerRadius={78} stroke="transparent">
                  {kerja.map((row, index) => (
                    <Cell key={row.label} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<Tip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <ul className="mt-2 space-y-1 text-sm">
            {kerja.map((row, index) => (
              <li key={row.label} className="flex items-center gap-2">
                <span className="size-2.5 rounded-full" style={{ background: CHART_COLORS[index % CHART_COLORS.length] }} />
                <span className="truncate text-stone">{row.label}</span>
                <span className="ml-auto font-semibold tabular-nums">{row.jumlah}</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Pendidikan">
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={didik} layout="vertical" margin={{ left: 8, right: 8 }}>
                <CartesianGrid stroke="var(--color-line)" horizontal={false} />
                <XAxis type="number" allowDecimals={false} tick={{ fill: "var(--color-stone)", fontSize: 12 }} />
                <YAxis type="category" dataKey="label" width={108} tick={{ fill: "var(--color-stone)", fontSize: 11 }} />
                <Tooltip content={<Tip />} />
                <Bar dataKey="jumlah" fill="var(--color-brand)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
        <Panel title="Kelompok usia">
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={usia}>
                <CartesianGrid stroke="var(--color-line)" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "var(--color-stone)", fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fill: "var(--color-stone)", fontSize: 12 }} />
                <Tooltip content={<Tip />} />
                <Bar dataKey="jumlah" fill="var(--color-brandsoft)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel title="Sebaran dusun">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-stone">
                <th className="py-2 font-semibold">Dusun</th>
                <th className="py-2 font-semibold">KK</th>
                <th className="py-2 text-right font-semibold">Jiwa</th>
              </tr>
            </thead>
            <tbody>
              {[...dusunMap.entries()].map(([dusun, row]) => (
                <tr key={dusun} className="border-t border-line">
                  <td className="py-2.5">{dusun}</td>
                  <td className="tabular-nums">{row.kk}</td>
                  <td className="text-right font-semibold tabular-nums">{row.jiwa}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
        <Panel title="Agama">
          <ul className="space-y-2 text-sm">
            {hitungTeks(penduduk, (p) => p.agama).map((row) => (
              <li key={row.label} className="flex items-center justify-between gap-3 border-b border-line py-2">
                <span>{row.label}</span>
                <span className="font-semibold tabular-nums">{row.jumlah}</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Mutasi terbaru">
          <ul className="space-y-3">
            {mutasi.slice(0, 5).map((item) => (
              <li key={item.id} className="border-b border-line pb-3 last:border-0">
                <p className="text-sm font-semibold">{item.nama}</p>
                <p className="text-sm text-stone">
                  {MUTASI_LABEL[item.jenis]} · {formatTanggal(item.tanggal)}
                </p>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
      <div className="mt-4">
        <Panel title="Peta rumah">
          <p className="mb-3 text-sm text-stone">Titik mengikuti koordinat kartu keluarga. Sentuh nama untuk membuka KK.</p>
          <PetaTitik
            titik={keluarga
              .filter((k) => k.latitude != null && k.longitude != null)
              .map((k) => ({
                id: k.noKk,
                nama: k.kepalaKeluarga,
                lat: k.latitude as number,
                lng: k.longitude as number,
                meta: k.dusun,
              }))}
          />
        </Panel>
      </div>
      <div className="mt-4">
        <Panel title="Jejak terakhir">
          <ul className="space-y-2 text-sm">
            {audit.slice(0, 5).map((item) => (
              <li key={item.id} className="flex flex-col gap-0.5 border-b border-line py-2 sm:flex-row sm:items-baseline sm:justify-between">
                <span>
                  <span className="font-semibold">{item.aksi}</span> {item.entitas.toLowerCase()} — {item.detail}
                </span>
                <span className="text-stone">{item.actor}</span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </Shell>
  );
}
